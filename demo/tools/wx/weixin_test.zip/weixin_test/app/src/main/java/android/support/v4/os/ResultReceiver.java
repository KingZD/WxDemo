package android.support.v4.os;

import android.os.Bundle;
import android.os.Handler;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class ResultReceiver implements Parcelable {
    public static final Creator<ResultReceiver> CREATOR = new ResultReceiver$1();
    public final Handler mHandler = null;
    public final boolean vO = false;
    public a vP;

    class a extends a$a {
        final /* synthetic */ ResultReceiver vQ;

        a(ResultReceiver resultReceiver) {
            this.vQ = resultReceiver;
        }

        public final void send(int i, Bundle bundle) {
            if (this.vQ.mHandler != null) {
                this.vQ.mHandler.post(new ResultReceiver$b(this.vQ, i, bundle));
            } else {
                this.vQ.onReceiveResult(i, bundle);
            }
        }
    }

    public void onReceiveResult(int i, Bundle bundle) {
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        synchronized (this) {
            if (this.vP == null) {
                this.vP = new a(this);
            }
            parcel.writeStrongBinder(this.vP.asBinder());
        }
    }

    ResultReceiver(Parcel parcel) {
        this.vP = a$a.b(parcel.readStrongBinder());
    }
}
