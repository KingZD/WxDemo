package android.support.v4.app;

import android.os.Parcel;
import android.os.Parcelable.Creator;

class FragmentTabHost$SavedState$1 implements Creator<FragmentTabHost$SavedState> {
    FragmentTabHost$SavedState$1() {
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        return new FragmentTabHost$SavedState(parcel, (byte) 0);
    }

    public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
        return new FragmentTabHost$SavedState[i];
    }
}
