package android.support.design.widget;

import android.support.v4.view.ap;
import android.support.v4.view.t;
import android.view.View;

class CollapsingToolbarLayout$1 implements t {
    final /* synthetic */ CollapsingToolbarLayout hl;

    CollapsingToolbarLayout$1(CollapsingToolbarLayout collapsingToolbarLayout) {
        this.hl = collapsingToolbarLayout;
    }

    public final ap a(View view, ap apVar) {
        return CollapsingToolbarLayout.a(this.hl, apVar);
    }
}
