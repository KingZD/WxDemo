package android.support.v4.content;

import android.content.Context;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public class c<D> {
    Context mContext;
    public int mId;
    public boolean oX = false;
    public b<D> tM;
    public a<D> tN;
    public boolean tO = false;
    public boolean tP = true;
    public boolean tQ = false;
    public boolean tR = false;

    public interface a<D> {
    }

    public interface b<D> {
        void b(c<D> cVar, D d);
    }

    public c(Context context) {
        this.mContext = context.getApplicationContext();
    }

    public final void deliverResult(D d) {
        if (this.tM != null) {
            this.tM.b(this, d);
        }
    }

    public final void a(b<D> bVar) {
        if (this.tM == null) {
            throw new IllegalStateException("No listener register");
        } else if (this.tM != bVar) {
            throw new IllegalArgumentException("Attempting to unregister the wrong listener");
        } else {
            this.tM = null;
        }
    }

    public final void a(a<D> aVar) {
        if (this.tN == null) {
            throw new IllegalStateException("No listener register");
        } else if (this.tN != aVar) {
            throw new IllegalArgumentException("Attempting to unregister the wrong listener");
        } else {
            this.tN = null;
        }
    }

    public void onStartLoading() {
    }

    public void onStopLoading() {
    }

    public void onReset() {
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder(64);
        android.support.v4.e.c.a(this, stringBuilder);
        stringBuilder.append(" id=");
        stringBuilder.append(this.mId);
        stringBuilder.append("}");
        return stringBuilder.toString();
    }

    public void dump(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        printWriter.print(str);
        printWriter.print("mId=");
        printWriter.print(this.mId);
        printWriter.print(" mListener=");
        printWriter.println(this.tM);
        if (this.oX || this.tQ || this.tR) {
            printWriter.print(str);
            printWriter.print("mStarted=");
            printWriter.print(this.oX);
            printWriter.print(" mContentChanged=");
            printWriter.print(this.tQ);
            printWriter.print(" mProcessingChange=");
            printWriter.println(this.tR);
        }
        if (this.tO || this.tP) {
            printWriter.print(str);
            printWriter.print("mAbandoned=");
            printWriter.print(this.tO);
            printWriter.print(" mReset=");
            printWriter.println(this.tP);
        }
    }
}
