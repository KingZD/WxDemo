package android.support.v4.view;

import android.view.WindowInsets;

final class aq extends ap {
    final WindowInsets Ae;

    aq(WindowInsets windowInsets) {
        this.Ae = windowInsets;
    }

    public final int getSystemWindowInsetLeft() {
        return this.Ae.getSystemWindowInsetLeft();
    }

    public final int getSystemWindowInsetTop() {
        return this.Ae.getSystemWindowInsetTop();
    }

    public final int getSystemWindowInsetRight() {
        return this.Ae.getSystemWindowInsetRight();
    }

    public final int getSystemWindowInsetBottom() {
        return this.Ae.getSystemWindowInsetBottom();
    }

    public final boolean isConsumed() {
        return this.Ae.isConsumed();
    }

    public final ap cm() {
        return new aq(this.Ae.consumeSystemWindowInsets());
    }

    public final ap e(int i, int i2, int i3, int i4) {
        return new aq(this.Ae.replaceSystemWindowInsets(i, i2, i3, i4));
    }
}
