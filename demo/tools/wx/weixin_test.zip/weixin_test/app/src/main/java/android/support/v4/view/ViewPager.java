package android.support.v4.view;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.v4.os.b;
import android.support.v4.widget.i;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.View.BaseSavedState;
import android.view.View.MeasureSpec;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.Interpolator;
import android.widget.Scroller;
import com.tencent.mm.plugin.gif.MMGIFException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import org.xwalk.core.R$styleable;

public class ViewPager extends ViewGroup {
    private static final int[] yK = new int[]{16842931};
    private static final Comparator<ViewPager$b> yM = new Comparator<ViewPager$b>() {
        public final /* bridge */ /* synthetic */ int compare(Object obj, Object obj2) {
            return ((ViewPager$b) obj).position - ((ViewPager$b) obj2).position;
        }
    };
    private static final Interpolator yN = new ViewPager$2();
    private static final ViewPager$i zG = new ViewPager$i();
    private final ArrayList<ViewPager$b> eB = new ArrayList();
    private final Rect eK = new Rect();
    private VelocityTracker fF;
    private int fG = -1;
    private boolean iW;
    private int iY;
    private boolean mInLayout;
    private int yL;
    private final ViewPager$b yO = new ViewPager$b();
    public u yP;
    public int yQ;
    private int yR = -1;
    private Parcelable yS = null;
    private ClassLoader yT = null;
    private Scroller yU;
    private boolean yV;
    private ViewPager$g yW;
    private int yX;
    private Drawable yY;
    private int yZ;
    private float ya;
    private float yb;
    private int yt = 0;
    public ViewPager$e zA;
    private ViewPager$e zB;
    ViewPager$d zC;
    private ViewPager$f zD;
    private int zE;
    private ArrayList<View> zF;
    private final Runnable zH = new Runnable(this) {
        final /* synthetic */ ViewPager zI;

        {
            this.zI = r1;
        }

        public final void run() {
            this.zI.ah(0);
            this.zI.populate();
        }
    };
    private int za;
    private float zb = -3.4028235E38f;
    private float zc = Float.MAX_VALUE;
    private int zd;
    private int ze;
    private boolean zf;
    private boolean zg;
    public int zh = 1;
    private boolean zi;
    private int zj;
    private int zk;
    private float zl;
    private float zm;
    private int zn;
    private int zo;
    private int zp;
    private int zq;
    private boolean zr;
    private i zt;
    private i zu;
    private boolean zv = true;
    private boolean zw = false;
    private boolean zx;
    private int zy;
    public List<ViewPager$e> zz;

    public static class SavedState extends BaseSavedState {
        public static final Creator<SavedState> CREATOR = b.a(new ViewPager$SavedState$1());
        int position;
        Parcelable zP;
        ClassLoader zQ;

        public SavedState(Parcelable parcelable) {
            super(parcelable);
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.position);
            parcel.writeParcelable(this.zP, i);
        }

        public String toString() {
            return "FragmentPager.SavedState{" + Integer.toHexString(System.identityHashCode(this)) + " position=" + this.position + "}";
        }

        SavedState(Parcel parcel, ClassLoader classLoader) {
            super(parcel);
            if (classLoader == null) {
                classLoader = getClass().getClassLoader();
            }
            this.position = parcel.readInt();
            this.zP = parcel.readParcelable(classLoader);
            this.zQ = classLoader;
        }
    }

    public ViewPager(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setWillNotDraw(false);
        setDescendantFocusability(262144);
        setFocusable(true);
        Context context2 = getContext();
        this.yU = new Scroller(context2, yN);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context2);
        float f = context2.getResources().getDisplayMetrics().density;
        this.iY = ae.a(viewConfiguration);
        this.zn = (int) (400.0f * f);
        this.zo = viewConfiguration.getScaledMaximumFlingVelocity();
        this.zt = new i(context2);
        this.zu = new i(context2);
        this.zp = (int) (25.0f * f);
        this.zq = (int) (2.0f * f);
        this.zj = (int) (16.0f * f);
        z.a(this, new ViewPager$c(this));
        if (z.F(this) == 0) {
            z.i(this, 1);
        }
        z.b(this, new ViewPager$4(this));
    }

    protected void onDetachedFromWindow() {
        removeCallbacks(this.zH);
        if (!(this.yU == null || this.yU.isFinished())) {
            this.yU.abortAnimation();
        }
        super.onDetachedFromWindow();
    }

    private void ah(int i) {
        int i2 = 0;
        if (this.yt != i) {
            this.yt = i;
            if (this.zD != null) {
                int i3 = i != 0 ? 1 : 0;
                int childCount = getChildCount();
                for (int i4 = 0; i4 < childCount; i4++) {
                    z.a(getChildAt(i4), i3 != 0 ? 2 : 0, null);
                }
            }
            if (this.zA != null) {
                this.zA.ag(i);
            }
            if (this.zz != null) {
                int size = this.zz.size();
                while (i2 < size) {
                    ViewPager$e viewPager$e = (ViewPager$e) this.zz.get(i2);
                    if (viewPager$e != null) {
                        viewPager$e.ag(i);
                    }
                    i2++;
                }
            }
            if (this.zB != null) {
                this.zB.ag(i);
            }
        }
    }

    public final void a(u uVar) {
        if (this.yP != null) {
            int i;
            this.yP.a(null);
            for (i = 0; i < this.eB.size(); i++) {
                ViewPager$b viewPager$b = (ViewPager$b) this.eB.get(i);
                this.yP.a(this, viewPager$b.position, viewPager$b.object);
            }
            this.yP.bi();
            this.eB.clear();
            i = 0;
            while (i < getChildCount()) {
                if (!((ViewPager$LayoutParams) getChildAt(i).getLayoutParams()).zM) {
                    removeViewAt(i);
                    i--;
                }
                i++;
            }
            this.yQ = 0;
            scrollTo(0, 0);
        }
        u uVar2 = this.yP;
        this.yP = uVar;
        this.yL = 0;
        if (this.yP != null) {
            if (this.yW == null) {
                this.yW = new ViewPager$g(this, (byte) 0);
            }
            this.yP.a(this.yW);
            this.zg = false;
            boolean z = this.zv;
            this.zv = true;
            this.yL = this.yP.getCount();
            if (this.yR >= 0) {
                this.yP.a(this.yS, this.yT);
                a(this.yR, false, true);
                this.yR = -1;
                this.yS = null;
                this.yT = null;
            } else if (z) {
                requestLayout();
            } else {
                populate();
            }
        }
        if (this.zC != null && uVar2 != uVar) {
            this.zC.b(uVar2, uVar);
        }
    }

    private int cb() {
        return (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight();
    }

    public final void ai(int i) {
        boolean z;
        this.zg = false;
        if (this.zv) {
            z = false;
        } else {
            z = true;
        }
        a(i, z, false);
    }

    public final void k(int i, boolean z) {
        this.zg = false;
        a(i, z, false);
    }

    private void a(int i, boolean z, boolean z2) {
        a(i, z, z2, 0);
    }

    private void a(int i, boolean z, boolean z2, int i2) {
        boolean z3 = false;
        if (this.yP == null || this.yP.getCount() <= 0) {
            setScrollingCacheEnabled(false);
        } else if (z2 || this.yQ != i || this.eB.size() == 0) {
            if (i < 0) {
                i = 0;
            } else if (i >= this.yP.getCount()) {
                i = this.yP.getCount() - 1;
            }
            int i3 = this.zh;
            if (i > this.yQ + i3 || i < this.yQ - i3) {
                for (int i4 = 0; i4 < this.eB.size(); i4++) {
                    ((ViewPager$b) this.eB.get(i4)).zJ = true;
                }
            }
            if (this.yQ != i) {
                z3 = true;
            }
            if (this.zv) {
                this.yQ = i;
                if (z3) {
                    am(i);
                }
                requestLayout();
                return;
            }
            aj(i);
            a(i, z, i2, z3);
        } else {
            setScrollingCacheEnabled(false);
        }
    }

    private void a(int i, boolean z, int i2, boolean z2) {
        int cb;
        ViewPager$b ak = ak(i);
        if (ak != null) {
            cb = (int) (((float) cb()) * Math.max(this.zb, Math.min(ak.zL, this.zc)));
        } else {
            cb = 0;
        }
        if (z) {
            if (getChildCount() == 0) {
                setScrollingCacheEnabled(false);
            } else {
                int currX;
                int i3;
                Object obj = (this.yU == null || this.yU.isFinished()) ? null : 1;
                if (obj != null) {
                    currX = this.yV ? this.yU.getCurrX() : this.yU.getStartX();
                    this.yU.abortAnimation();
                    setScrollingCacheEnabled(false);
                    i3 = currX;
                } else {
                    i3 = getScrollX();
                }
                int scrollY = getScrollY();
                cb -= i3;
                int i4 = 0 - scrollY;
                if (cb == 0 && i4 == 0) {
                    y(false);
                    populate();
                    ah(0);
                } else {
                    setScrollingCacheEnabled(true);
                    ah(2);
                    currX = cb();
                    int i5 = currX / 2;
                    float sin = (((float) i5) * ((float) Math.sin((double) ((float) (((double) (Math.min(1.0f, (1.0f * ((float) Math.abs(cb))) / ((float) currX)) - 0.5f)) * 0.4712389167638204d))))) + ((float) i5);
                    int abs = Math.abs(i2);
                    i5 = Math.min(abs > 0 ? Math.round(1000.0f * Math.abs(sin / ((float) abs))) * 4 : (int) (((((float) Math.abs(cb)) / ((((float) currX) * 1.0f) + ((float) this.yX))) + 1.0f) * 100.0f), 600);
                    this.yV = false;
                    this.yU.startScroll(i3, scrollY, cb, i4, i5);
                    z.E(this);
                }
            }
            if (z2) {
                am(i);
                return;
            }
            return;
        }
        if (z2) {
            am(i);
        }
        y(false);
        scrollTo(cb, 0);
        al(cb);
    }

    protected int getChildDrawingOrder(int i, int i2) {
        if (this.zE == 2) {
            i2 = (i - 1) - i2;
        }
        return ((ViewPager$LayoutParams) ((View) this.zF.get(i2)).getLayoutParams()).zO;
    }

    final ViewPager$e a(ViewPager$e viewPager$e) {
        ViewPager$e viewPager$e2 = this.zB;
        this.zB = viewPager$e;
        return viewPager$e2;
    }

    protected boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.yY;
    }

    protected void drawableStateChanged() {
        super.drawableStateChanged();
        Drawable drawable = this.yY;
        if (drawable != null && drawable.isStateful()) {
            drawable.setState(getDrawableState());
        }
    }

    private ViewPager$b q(int i, int i2) {
        ViewPager$b viewPager$b = new ViewPager$b();
        viewPager$b.position = i;
        viewPager$b.object = this.yP.b(this, i);
        viewPager$b.zK = 1.0f;
        if (i2 < 0 || i2 >= this.eB.size()) {
            this.eB.add(viewPager$b);
        } else {
            this.eB.add(i2, viewPager$b);
        }
        return viewPager$b;
    }

    final void cc() {
        int count = this.yP.getCount();
        this.yL = count;
        boolean z = this.eB.size() < (this.zh * 2) + 1 && this.eB.size() < count;
        boolean z2 = false;
        int i = this.yQ;
        boolean z3 = z;
        int i2 = 0;
        while (i2 < this.eB.size()) {
            int i3;
            boolean z4;
            int max;
            boolean z5;
            ViewPager$b viewPager$b = (ViewPager$b) this.eB.get(i2);
            int k = this.yP.k(viewPager$b.object);
            if (k != -1) {
                if (k == -2) {
                    this.eB.remove(i2);
                    i2--;
                    if (!z2) {
                        z2 = true;
                    }
                    this.yP.a(this, viewPager$b.position, viewPager$b.object);
                    if (this.yQ == viewPager$b.position) {
                        i3 = i2;
                        z4 = z2;
                        max = Math.max(0, Math.min(this.yQ, count - 1));
                        z5 = true;
                    } else {
                        i3 = i2;
                        z4 = z2;
                        max = i;
                        z5 = true;
                    }
                } else if (viewPager$b.position != k) {
                    if (viewPager$b.position == this.yQ) {
                        i = k;
                    }
                    viewPager$b.position = k;
                    i3 = i2;
                    z4 = z2;
                    max = i;
                    z5 = true;
                }
                z3 = z5;
                i = max;
                z2 = z4;
                i2 = i3 + 1;
            }
            i3 = i2;
            z4 = z2;
            max = i;
            z5 = z3;
            z3 = z5;
            i = max;
            z2 = z4;
            i2 = i3 + 1;
        }
        if (z2) {
            this.yP.bi();
        }
        Collections.sort(this.eB, yM);
        if (z3) {
            max = getChildCount();
            for (i2 = 0; i2 < max; i2++) {
                ViewPager$LayoutParams viewPager$LayoutParams = (ViewPager$LayoutParams) getChildAt(i2).getLayoutParams();
                if (!viewPager$LayoutParams.zM) {
                    viewPager$LayoutParams.zK = 0.0f;
                }
            }
            a(i, false, true);
            requestLayout();
        }
    }

    public final void populate() {
        aj(this.yQ);
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void aj(int r18) {
        /*
        r17 = this;
        r2 = 0;
        r0 = r17;
        r3 = r0.yQ;
        r0 = r18;
        if (r3 == r0) goto L_0x030c;
    L_0x0009:
        r0 = r17;
        r2 = r0.yQ;
        r0 = r17;
        r2 = r0.ak(r2);
        r0 = r18;
        r1 = r17;
        r1.yQ = r0;
        r3 = r2;
    L_0x001a:
        r0 = r17;
        r2 = r0.yP;
        if (r2 != 0) goto L_0x0024;
    L_0x0020:
        r17.cd();
    L_0x0023:
        return;
    L_0x0024:
        r0 = r17;
        r2 = r0.zg;
        if (r2 == 0) goto L_0x002e;
    L_0x002a:
        r17.cd();
        goto L_0x0023;
    L_0x002e:
        r2 = r17.getWindowToken();
        if (r2 == 0) goto L_0x0023;
    L_0x0034:
        r0 = r17;
        r2 = r0.zh;
        r4 = 0;
        r0 = r17;
        r5 = r0.yQ;
        r5 = r5 - r2;
        r10 = java.lang.Math.max(r4, r5);
        r0 = r17;
        r4 = r0.yP;
        r11 = r4.getCount();
        r4 = r11 + -1;
        r0 = r17;
        r5 = r0.yQ;
        r2 = r2 + r5;
        r12 = java.lang.Math.min(r4, r2);
        r0 = r17;
        r2 = r0.yL;
        if (r11 == r2) goto L_0x00c3;
    L_0x005b:
        r2 = r17.getResources();	 Catch:{ NotFoundException -> 0x00b9 }
        r3 = r17.getId();	 Catch:{ NotFoundException -> 0x00b9 }
        r2 = r2.getResourceName(r3);	 Catch:{ NotFoundException -> 0x00b9 }
    L_0x0067:
        r3 = new java.lang.IllegalStateException;
        r4 = new java.lang.StringBuilder;
        r5 = "The application's PagerAdapter changed the adapter's contents without calling PagerAdapter#notifyDataSetChanged! Expected adapter item count: ";
        r4.<init>(r5);
        r0 = r17;
        r5 = r0.yL;
        r4 = r4.append(r5);
        r5 = ", found: ";
        r4 = r4.append(r5);
        r4 = r4.append(r11);
        r5 = " Pager id: ";
        r4 = r4.append(r5);
        r2 = r4.append(r2);
        r4 = " Pager class: ";
        r2 = r2.append(r4);
        r4 = r17.getClass();
        r2 = r2.append(r4);
        r4 = " Problematic adapter: ";
        r2 = r2.append(r4);
        r0 = r17;
        r4 = r0.yP;
        r4 = r4.getClass();
        r2 = r2.append(r4);
        r2 = r2.toString();
        r3.<init>(r2);
        throw r3;
    L_0x00b9:
        r2 = move-exception;
        r2 = r17.getId();
        r2 = java.lang.Integer.toHexString(r2);
        goto L_0x0067;
    L_0x00c3:
        r5 = 0;
        r2 = 0;
        r4 = r2;
    L_0x00c6:
        r0 = r17;
        r2 = r0.eB;
        r2 = r2.size();
        if (r4 >= r2) goto L_0x0309;
    L_0x00d0:
        r0 = r17;
        r2 = r0.eB;
        r2 = r2.get(r4);
        r2 = (android.support.v4.view.ViewPager$b) r2;
        r6 = r2.position;
        r0 = r17;
        r7 = r0.yQ;
        if (r6 < r7) goto L_0x0156;
    L_0x00e2:
        r6 = r2.position;
        r0 = r17;
        r7 = r0.yQ;
        if (r6 != r7) goto L_0x0309;
    L_0x00ea:
        if (r2 != 0) goto L_0x0306;
    L_0x00ec:
        if (r11 <= 0) goto L_0x0306;
    L_0x00ee:
        r0 = r17;
        r2 = r0.yQ;
        r0 = r17;
        r2 = r0.q(r2, r4);
        r9 = r2;
    L_0x00f9:
        if (r9 == 0) goto L_0x0270;
    L_0x00fb:
        r8 = 0;
        r7 = r4 + -1;
        if (r7 < 0) goto L_0x015b;
    L_0x0100:
        r0 = r17;
        r2 = r0.eB;
        r2 = r2.get(r7);
        r2 = (android.support.v4.view.ViewPager$b) r2;
    L_0x010a:
        r13 = r17.cb();
        if (r13 > 0) goto L_0x015d;
    L_0x0110:
        r5 = 0;
    L_0x0111:
        r0 = r17;
        r6 = r0.yQ;
        r6 = r6 + -1;
        r15 = r6;
        r6 = r8;
        r8 = r15;
        r16 = r7;
        r7 = r4;
        r4 = r16;
    L_0x011f:
        if (r8 < 0) goto L_0x01a3;
    L_0x0121:
        r14 = (r6 > r5 ? 1 : (r6 == r5 ? 0 : -1));
        if (r14 < 0) goto L_0x016d;
    L_0x0125:
        if (r8 >= r10) goto L_0x016d;
    L_0x0127:
        if (r2 == 0) goto L_0x01a3;
    L_0x0129:
        r14 = r2.position;
        if (r8 != r14) goto L_0x0153;
    L_0x012d:
        r14 = r2.zJ;
        if (r14 != 0) goto L_0x0153;
    L_0x0131:
        r0 = r17;
        r14 = r0.eB;
        r14.remove(r4);
        r0 = r17;
        r14 = r0.yP;
        r2 = r2.object;
        r0 = r17;
        r14.a(r0, r8, r2);
        r4 = r4 + -1;
        r7 = r7 + -1;
        if (r4 < 0) goto L_0x016b;
    L_0x0149:
        r0 = r17;
        r2 = r0.eB;
        r2 = r2.get(r4);
        r2 = (android.support.v4.view.ViewPager$b) r2;
    L_0x0153:
        r8 = r8 + -1;
        goto L_0x011f;
    L_0x0156:
        r2 = r4 + 1;
        r4 = r2;
        goto L_0x00c6;
    L_0x015b:
        r2 = 0;
        goto L_0x010a;
    L_0x015d:
        r5 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        r6 = r9.zK;
        r5 = r5 - r6;
        r6 = r17.getPaddingLeft();
        r6 = (float) r6;
        r14 = (float) r13;
        r6 = r6 / r14;
        r5 = r5 + r6;
        goto L_0x0111;
    L_0x016b:
        r2 = 0;
        goto L_0x0153;
    L_0x016d:
        if (r2 == 0) goto L_0x0187;
    L_0x016f:
        r14 = r2.position;
        if (r8 != r14) goto L_0x0187;
    L_0x0173:
        r2 = r2.zK;
        r6 = r6 + r2;
        r4 = r4 + -1;
        if (r4 < 0) goto L_0x0185;
    L_0x017a:
        r0 = r17;
        r2 = r0.eB;
        r2 = r2.get(r4);
        r2 = (android.support.v4.view.ViewPager$b) r2;
        goto L_0x0153;
    L_0x0185:
        r2 = 0;
        goto L_0x0153;
    L_0x0187:
        r2 = r4 + 1;
        r0 = r17;
        r2 = r0.q(r8, r2);
        r2 = r2.zK;
        r6 = r6 + r2;
        r7 = r7 + 1;
        if (r4 < 0) goto L_0x01a1;
    L_0x0196:
        r0 = r17;
        r2 = r0.eB;
        r2 = r2.get(r4);
        r2 = (android.support.v4.view.ViewPager$b) r2;
        goto L_0x0153;
    L_0x01a1:
        r2 = 0;
        goto L_0x0153;
    L_0x01a3:
        r5 = r9.zK;
        r8 = r7 + 1;
        r2 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        r2 = (r5 > r2 ? 1 : (r5 == r2 ? 0 : -1));
        if (r2 >= 0) goto L_0x026b;
    L_0x01ad:
        r0 = r17;
        r2 = r0.eB;
        r2 = r2.size();
        if (r8 >= r2) goto L_0x0211;
    L_0x01b7:
        r0 = r17;
        r2 = r0.eB;
        r2 = r2.get(r8);
        r2 = (android.support.v4.view.ViewPager$b) r2;
        r6 = r2;
    L_0x01c2:
        if (r13 > 0) goto L_0x0213;
    L_0x01c4:
        r2 = 0;
        r4 = r2;
    L_0x01c6:
        r0 = r17;
        r2 = r0.yQ;
        r2 = r2 + 1;
        r15 = r6;
        r6 = r8;
        r8 = r2;
        r2 = r15;
    L_0x01d0:
        if (r8 >= r11) goto L_0x026b;
    L_0x01d2:
        r10 = (r5 > r4 ? 1 : (r5 == r4 ? 0 : -1));
        if (r10 < 0) goto L_0x0221;
    L_0x01d6:
        if (r8 <= r12) goto L_0x0221;
    L_0x01d8:
        if (r2 == 0) goto L_0x026b;
    L_0x01da:
        r10 = r2.position;
        if (r8 != r10) goto L_0x0301;
    L_0x01de:
        r10 = r2.zJ;
        if (r10 != 0) goto L_0x0301;
    L_0x01e2:
        r0 = r17;
        r10 = r0.eB;
        r10.remove(r6);
        r0 = r17;
        r10 = r0.yP;
        r2 = r2.object;
        r0 = r17;
        r10.a(r0, r8, r2);
        r0 = r17;
        r2 = r0.eB;
        r2 = r2.size();
        if (r6 >= r2) goto L_0x021f;
    L_0x01fe:
        r0 = r17;
        r2 = r0.eB;
        r2 = r2.get(r6);
        r2 = (android.support.v4.view.ViewPager$b) r2;
    L_0x0208:
        r15 = r5;
        r5 = r2;
        r2 = r15;
    L_0x020b:
        r8 = r8 + 1;
        r15 = r2;
        r2 = r5;
        r5 = r15;
        goto L_0x01d0;
    L_0x0211:
        r6 = 0;
        goto L_0x01c2;
    L_0x0213:
        r2 = r17.getPaddingRight();
        r2 = (float) r2;
        r4 = (float) r13;
        r2 = r2 / r4;
        r4 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        r2 = r2 + r4;
        r4 = r2;
        goto L_0x01c6;
    L_0x021f:
        r2 = 0;
        goto L_0x0208;
    L_0x0221:
        if (r2 == 0) goto L_0x0246;
    L_0x0223:
        r10 = r2.position;
        if (r8 != r10) goto L_0x0246;
    L_0x0227:
        r2 = r2.zK;
        r5 = r5 + r2;
        r6 = r6 + 1;
        r0 = r17;
        r2 = r0.eB;
        r2 = r2.size();
        if (r6 >= r2) goto L_0x0244;
    L_0x0236:
        r0 = r17;
        r2 = r0.eB;
        r2 = r2.get(r6);
        r2 = (android.support.v4.view.ViewPager$b) r2;
    L_0x0240:
        r15 = r5;
        r5 = r2;
        r2 = r15;
        goto L_0x020b;
    L_0x0244:
        r2 = 0;
        goto L_0x0240;
    L_0x0246:
        r0 = r17;
        r2 = r0.q(r8, r6);
        r6 = r6 + 1;
        r2 = r2.zK;
        r5 = r5 + r2;
        r0 = r17;
        r2 = r0.eB;
        r2 = r2.size();
        if (r6 >= r2) goto L_0x0269;
    L_0x025b:
        r0 = r17;
        r2 = r0.eB;
        r2 = r2.get(r6);
        r2 = (android.support.v4.view.ViewPager$b) r2;
    L_0x0265:
        r15 = r5;
        r5 = r2;
        r2 = r15;
        goto L_0x020b;
    L_0x0269:
        r2 = 0;
        goto L_0x0265;
    L_0x026b:
        r0 = r17;
        r0.a(r9, r7, r3);
    L_0x0270:
        r0 = r17;
        r3 = r0.yP;
        if (r9 == 0) goto L_0x02b7;
    L_0x0276:
        r2 = r9.object;
    L_0x0278:
        r3.e(r2);
        r0 = r17;
        r2 = r0.yP;
        r2.bi();
        r4 = r17.getChildCount();
        r2 = 0;
        r3 = r2;
    L_0x0288:
        if (r3 >= r4) goto L_0x02b9;
    L_0x028a:
        r0 = r17;
        r5 = r0.getChildAt(r3);
        r2 = r5.getLayoutParams();
        r2 = (android.support.v4.view.ViewPager$LayoutParams) r2;
        r2.zO = r3;
        r6 = r2.zM;
        if (r6 != 0) goto L_0x02b3;
    L_0x029c:
        r6 = r2.zK;
        r7 = 0;
        r6 = (r6 > r7 ? 1 : (r6 == r7 ? 0 : -1));
        if (r6 != 0) goto L_0x02b3;
    L_0x02a3:
        r0 = r17;
        r5 = r0.ao(r5);
        if (r5 == 0) goto L_0x02b3;
    L_0x02ab:
        r6 = r5.zK;
        r2.zK = r6;
        r5 = r5.position;
        r2.position = r5;
    L_0x02b3:
        r2 = r3 + 1;
        r3 = r2;
        goto L_0x0288;
    L_0x02b7:
        r2 = 0;
        goto L_0x0278;
    L_0x02b9:
        r17.cd();
        r2 = r17.hasFocus();
        if (r2 == 0) goto L_0x0023;
    L_0x02c2:
        r2 = r17.findFocus();
        if (r2 == 0) goto L_0x02ff;
    L_0x02c8:
        r0 = r17;
        r2 = r0.ap(r2);
    L_0x02ce:
        if (r2 == 0) goto L_0x02d8;
    L_0x02d0:
        r2 = r2.position;
        r0 = r17;
        r3 = r0.yQ;
        if (r2 == r3) goto L_0x0023;
    L_0x02d8:
        r2 = 0;
    L_0x02d9:
        r3 = r17.getChildCount();
        if (r2 >= r3) goto L_0x0023;
    L_0x02df:
        r0 = r17;
        r3 = r0.getChildAt(r2);
        r0 = r17;
        r4 = r0.ao(r3);
        if (r4 == 0) goto L_0x02fc;
    L_0x02ed:
        r4 = r4.position;
        r0 = r17;
        r5 = r0.yQ;
        if (r4 != r5) goto L_0x02fc;
    L_0x02f5:
        r4 = 2;
        r3 = r3.requestFocus(r4);
        if (r3 != 0) goto L_0x0023;
    L_0x02fc:
        r2 = r2 + 1;
        goto L_0x02d9;
    L_0x02ff:
        r2 = 0;
        goto L_0x02ce;
    L_0x0301:
        r15 = r5;
        r5 = r2;
        r2 = r15;
        goto L_0x020b;
    L_0x0306:
        r9 = r2;
        goto L_0x00f9;
    L_0x0309:
        r2 = r5;
        goto L_0x00ea;
    L_0x030c:
        r3 = r2;
        goto L_0x001a;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.view.ViewPager.aj(int):void");
    }

    private void cd() {
        if (this.zE != 0) {
            if (this.zF == null) {
                this.zF = new ArrayList();
            } else {
                this.zF.clear();
            }
            int childCount = getChildCount();
            for (int i = 0; i < childCount; i++) {
                this.zF.add(getChildAt(i));
            }
            Collections.sort(this.zF, zG);
        }
    }

    private void a(ViewPager$b viewPager$b, int i, ViewPager$b viewPager$b2) {
        float f;
        int i2;
        ViewPager$b viewPager$b3;
        float f2;
        int i3;
        int count = this.yP.getCount();
        int cb = cb();
        if (cb > 0) {
            f = ((float) this.yX) / ((float) cb);
        } else {
            f = 0.0f;
        }
        if (viewPager$b2 != null) {
            cb = viewPager$b2.position;
            float f3;
            int i4;
            int i5;
            if (cb < viewPager$b.position) {
                f3 = (viewPager$b2.zL + viewPager$b2.zK) + f;
                i2 = 0;
                i4 = cb + 1;
                while (i4 <= viewPager$b.position && i2 < this.eB.size()) {
                    viewPager$b3 = (ViewPager$b) this.eB.get(i2);
                    while (i4 > viewPager$b3.position && i2 < this.eB.size() - 1) {
                        i2++;
                        viewPager$b3 = (ViewPager$b) this.eB.get(i2);
                    }
                    i5 = i4;
                    f2 = f3;
                    i3 = i5;
                    while (i3 < viewPager$b3.position) {
                        i3++;
                        f2 = (1.0f + f) + f2;
                    }
                    viewPager$b3.zL = f2;
                    f2 += viewPager$b3.zK + f;
                    cb = i3 + 1;
                    f3 = f2;
                    i4 = cb;
                }
            } else if (cb > viewPager$b.position) {
                i2 = this.eB.size() - 1;
                f3 = viewPager$b2.zL;
                i4 = cb - 1;
                while (i4 >= viewPager$b.position && i2 >= 0) {
                    viewPager$b3 = (ViewPager$b) this.eB.get(i2);
                    while (i4 < viewPager$b3.position && i2 > 0) {
                        i2--;
                        viewPager$b3 = (ViewPager$b) this.eB.get(i2);
                    }
                    i5 = i4;
                    f2 = f3;
                    i3 = i5;
                    while (i3 > viewPager$b3.position) {
                        i3--;
                        f2 -= 1.0f + f;
                    }
                    f2 -= viewPager$b3.zK + f;
                    viewPager$b3.zL = f2;
                    cb = i3 - 1;
                    f3 = f2;
                    i4 = cb;
                }
            }
        }
        int size = this.eB.size();
        f2 = viewPager$b.zL;
        i3 = viewPager$b.position - 1;
        this.zb = viewPager$b.position == 0 ? viewPager$b.zL : -3.4028235E38f;
        this.zc = viewPager$b.position == count + -1 ? (viewPager$b.zL + viewPager$b.zK) - 1.0f : Float.MAX_VALUE;
        for (i2 = i - 1; i2 >= 0; i2--) {
            viewPager$b3 = (ViewPager$b) this.eB.get(i2);
            while (i3 > viewPager$b3.position) {
                i3--;
                f2 -= 1.0f + f;
            }
            f2 -= viewPager$b3.zK + f;
            viewPager$b3.zL = f2;
            if (viewPager$b3.position == 0) {
                this.zb = f2;
            }
            i3--;
        }
        f2 = (viewPager$b.zL + viewPager$b.zK) + f;
        i3 = viewPager$b.position + 1;
        for (i2 = i + 1; i2 < size; i2++) {
            viewPager$b3 = (ViewPager$b) this.eB.get(i2);
            while (i3 < viewPager$b3.position) {
                i3++;
                f2 += 1.0f + f;
            }
            if (viewPager$b3.position == count - 1) {
                this.zc = (viewPager$b3.zK + f2) - 1.0f;
            }
            viewPager$b3.zL = f2;
            f2 += viewPager$b3.zK + f;
            i3++;
        }
        this.zw = false;
    }

    public Parcelable onSaveInstanceState() {
        Parcelable savedState = new SavedState(super.onSaveInstanceState());
        savedState.position = this.yQ;
        if (this.yP != null) {
            savedState.zP = this.yP.bj();
        }
        return savedState;
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        if (parcelable instanceof SavedState) {
            SavedState savedState = (SavedState) parcelable;
            super.onRestoreInstanceState(savedState.getSuperState());
            if (this.yP != null) {
                this.yP.a(savedState.zP, savedState.zQ);
                a(savedState.position, false, true);
                return;
            }
            this.yR = savedState.position;
            this.yS = savedState.zP;
            this.yT = savedState.zQ;
            return;
        }
        super.onRestoreInstanceState(parcelable);
    }

    public void addView(View view, int i, LayoutParams layoutParams) {
        LayoutParams layoutParams2;
        if (checkLayoutParams(layoutParams)) {
            layoutParams2 = layoutParams;
        } else {
            layoutParams2 = generateLayoutParams(layoutParams);
        }
        ViewPager$LayoutParams viewPager$LayoutParams = (ViewPager$LayoutParams) layoutParams2;
        viewPager$LayoutParams.zM |= view instanceof ViewPager$a;
        if (!this.mInLayout) {
            super.addView(view, i, layoutParams2);
        } else if (viewPager$LayoutParams == null || !viewPager$LayoutParams.zM) {
            viewPager$LayoutParams.zN = true;
            addViewInLayout(view, i, layoutParams2);
        } else {
            throw new IllegalStateException("Cannot add pager decor view during layout");
        }
    }

    public void removeView(View view) {
        if (this.mInLayout) {
            removeViewInLayout(view);
        } else {
            super.removeView(view);
        }
    }

    private ViewPager$b ao(View view) {
        for (int i = 0; i < this.eB.size(); i++) {
            ViewPager$b viewPager$b = (ViewPager$b) this.eB.get(i);
            if (this.yP.a(view, viewPager$b.object)) {
                return viewPager$b;
            }
        }
        return null;
    }

    private ViewPager$b ap(View view) {
        while (true) {
            ViewPager parent = view.getParent();
            if (parent == this) {
                return ao(view);
            }
            if (parent != null && (parent instanceof View)) {
                view = parent;
            }
        }
        return null;
    }

    private ViewPager$b ak(int i) {
        for (int i2 = 0; i2 < this.eB.size(); i2++) {
            ViewPager$b viewPager$b = (ViewPager$b) this.eB.get(i2);
            if (viewPager$b.position == i) {
                return viewPager$b;
            }
        }
        return null;
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.zv = true;
    }

    public void onMeasure(int i, int i2) {
        int i3;
        setMeasuredDimension(getDefaultSize(0, i), getDefaultSize(0, i2));
        int measuredWidth = getMeasuredWidth();
        this.zk = Math.min(measuredWidth / 10, this.zj);
        int paddingLeft = (measuredWidth - getPaddingLeft()) - getPaddingRight();
        int measuredHeight = (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom();
        int childCount = getChildCount();
        for (int i4 = 0; i4 < childCount; i4++) {
            ViewPager$LayoutParams viewPager$LayoutParams;
            int i5;
            View childAt = getChildAt(i4);
            if (childAt.getVisibility() != 8) {
                viewPager$LayoutParams = (ViewPager$LayoutParams) childAt.getLayoutParams();
                if (viewPager$LayoutParams != null && viewPager$LayoutParams.zM) {
                    int i6 = viewPager$LayoutParams.gravity & 7;
                    int i7 = viewPager$LayoutParams.gravity & MMGIFException.D_GIF_ERR_IMAGE_DEFECT;
                    i3 = Integer.MIN_VALUE;
                    i5 = Integer.MIN_VALUE;
                    Object obj = (i7 == 48 || i7 == 80) ? 1 : null;
                    Object obj2 = (i6 == 3 || i6 == 5) ? 1 : null;
                    if (obj != null) {
                        i3 = 1073741824;
                    } else if (obj2 != null) {
                        i5 = 1073741824;
                    }
                    if (viewPager$LayoutParams.width != -2) {
                        i7 = 1073741824;
                        i3 = viewPager$LayoutParams.width != -1 ? viewPager$LayoutParams.width : paddingLeft;
                    } else {
                        i7 = i3;
                        i3 = paddingLeft;
                    }
                    if (viewPager$LayoutParams.height != -2) {
                        i5 = 1073741824;
                        if (viewPager$LayoutParams.height != -1) {
                            measuredWidth = viewPager$LayoutParams.height;
                            childAt.measure(MeasureSpec.makeMeasureSpec(i3, i7), MeasureSpec.makeMeasureSpec(measuredWidth, i5));
                            if (obj != null) {
                                measuredHeight -= childAt.getMeasuredHeight();
                            } else if (obj2 != null) {
                                paddingLeft -= childAt.getMeasuredWidth();
                            }
                        }
                    }
                    measuredWidth = measuredHeight;
                    childAt.measure(MeasureSpec.makeMeasureSpec(i3, i7), MeasureSpec.makeMeasureSpec(measuredWidth, i5));
                    if (obj != null) {
                        measuredHeight -= childAt.getMeasuredHeight();
                    } else if (obj2 != null) {
                        paddingLeft -= childAt.getMeasuredWidth();
                    }
                }
            }
        }
        this.zd = MeasureSpec.makeMeasureSpec(paddingLeft, 1073741824);
        this.ze = MeasureSpec.makeMeasureSpec(measuredHeight, 1073741824);
        this.mInLayout = true;
        populate();
        this.mInLayout = false;
        i3 = getChildCount();
        for (i5 = 0; i5 < i3; i5++) {
            View childAt2 = getChildAt(i5);
            if (childAt2.getVisibility() != 8) {
                viewPager$LayoutParams = (ViewPager$LayoutParams) childAt2.getLayoutParams();
                if (viewPager$LayoutParams == null || !viewPager$LayoutParams.zM) {
                    childAt2.measure(MeasureSpec.makeMeasureSpec((int) (viewPager$LayoutParams.zK * ((float) paddingLeft)), 1073741824), this.ze);
                }
            }
        }
    }

    protected void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        if (i != i3) {
            int i5 = this.yX;
            int i6 = this.yX;
            if (i3 <= 0 || this.eB.isEmpty()) {
                ViewPager$b ak = ak(this.yQ);
                i5 = (int) ((ak != null ? Math.min(ak.zL, this.zc) : 0.0f) * ((float) ((i - getPaddingLeft()) - getPaddingRight())));
                if (i5 != getScrollX()) {
                    y(false);
                    scrollTo(i5, getScrollY());
                }
            } else if (this.yU.isFinished()) {
                scrollTo((int) (((float) (i5 + ((i - getPaddingLeft()) - getPaddingRight()))) * (((float) getScrollX()) / ((float) (i6 + ((i3 - getPaddingLeft()) - getPaddingRight()))))), getScrollY());
            } else {
                this.yU.setFinalX(this.yQ * cb());
            }
        }
    }

    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int max;
        int childCount = getChildCount();
        int i5 = i3 - i;
        int i6 = i4 - i2;
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingRight = getPaddingRight();
        int paddingBottom = getPaddingBottom();
        int scrollX = getScrollX();
        int i7 = 0;
        int i8 = 0;
        while (i8 < childCount) {
            ViewPager$LayoutParams viewPager$LayoutParams;
            int measuredWidth;
            View childAt = getChildAt(i8);
            if (childAt.getVisibility() != 8) {
                viewPager$LayoutParams = (ViewPager$LayoutParams) childAt.getLayoutParams();
                if (viewPager$LayoutParams.zM) {
                    int i9 = viewPager$LayoutParams.gravity & MMGIFException.D_GIF_ERR_IMAGE_DEFECT;
                    switch (viewPager$LayoutParams.gravity & 7) {
                        case 1:
                            max = Math.max((i5 - childAt.getMeasuredWidth()) / 2, paddingLeft);
                            break;
                        case 3:
                            max = paddingLeft;
                            paddingLeft = childAt.getMeasuredWidth() + paddingLeft;
                            break;
                        case 5:
                            measuredWidth = (i5 - paddingRight) - childAt.getMeasuredWidth();
                            paddingRight += childAt.getMeasuredWidth();
                            max = measuredWidth;
                            break;
                        default:
                            max = paddingLeft;
                            break;
                    }
                    int i10;
                    switch (i9) {
                        case 16:
                            measuredWidth = Math.max((i6 - childAt.getMeasuredHeight()) / 2, paddingTop);
                            i10 = paddingBottom;
                            paddingBottom = paddingTop;
                            paddingTop = i10;
                            break;
                        case R$styleable.AppCompatTheme_homeAsUpIndicator /*48*/:
                            measuredWidth = childAt.getMeasuredHeight() + paddingTop;
                            i10 = paddingTop;
                            paddingTop = paddingBottom;
                            paddingBottom = measuredWidth;
                            measuredWidth = i10;
                            break;
                        case 80:
                            measuredWidth = (i6 - paddingBottom) - childAt.getMeasuredHeight();
                            i10 = paddingBottom + childAt.getMeasuredHeight();
                            paddingBottom = paddingTop;
                            paddingTop = i10;
                            break;
                        default:
                            measuredWidth = paddingTop;
                            i10 = paddingBottom;
                            paddingBottom = paddingTop;
                            paddingTop = i10;
                            break;
                    }
                    max += scrollX;
                    childAt.layout(max, measuredWidth, childAt.getMeasuredWidth() + max, childAt.getMeasuredHeight() + measuredWidth);
                    measuredWidth = i7 + 1;
                    i7 = paddingBottom;
                    paddingBottom = paddingTop;
                    paddingTop = paddingRight;
                    paddingRight = paddingLeft;
                    i8++;
                    paddingLeft = paddingRight;
                    paddingRight = paddingTop;
                    paddingTop = i7;
                    i7 = measuredWidth;
                }
            }
            measuredWidth = i7;
            i7 = paddingTop;
            paddingTop = paddingRight;
            paddingRight = paddingLeft;
            i8++;
            paddingLeft = paddingRight;
            paddingRight = paddingTop;
            paddingTop = i7;
            i7 = measuredWidth;
        }
        max = (i5 - paddingLeft) - paddingRight;
        for (paddingRight = 0; paddingRight < childCount; paddingRight++) {
            View childAt2 = getChildAt(paddingRight);
            if (childAt2.getVisibility() != 8) {
                viewPager$LayoutParams = (ViewPager$LayoutParams) childAt2.getLayoutParams();
                if (!viewPager$LayoutParams.zM) {
                    ViewPager$b ao = ao(childAt2);
                    if (ao != null) {
                        i5 = ((int) (ao.zL * ((float) max))) + paddingLeft;
                        if (viewPager$LayoutParams.zN) {
                            viewPager$LayoutParams.zN = false;
                            childAt2.measure(MeasureSpec.makeMeasureSpec((int) (viewPager$LayoutParams.zK * ((float) max)), 1073741824), MeasureSpec.makeMeasureSpec((i6 - paddingTop) - paddingBottom, 1073741824));
                        }
                        childAt2.layout(i5, paddingTop, childAt2.getMeasuredWidth() + i5, childAt2.getMeasuredHeight() + paddingTop);
                    }
                }
            }
        }
        this.yZ = paddingTop;
        this.za = i6 - paddingBottom;
        this.zy = i7;
        if (this.zv) {
            a(this.yQ, false, 0, false);
        }
        this.zv = false;
    }

    public void computeScroll() {
        this.yV = true;
        if (this.yU.isFinished() || !this.yU.computeScrollOffset()) {
            y(true);
            return;
        }
        int scrollX = getScrollX();
        int scrollY = getScrollY();
        int currX = this.yU.getCurrX();
        int currY = this.yU.getCurrY();
        if (!(scrollX == currX && scrollY == currY)) {
            scrollTo(currX, currY);
            if (!al(currX)) {
                this.yU.abortAnimation();
                scrollTo(0, currY);
            }
        }
        z.E(this);
    }

    private boolean al(int i) {
        if (this.eB.size() != 0) {
            ViewPager$b cg = cg();
            int cb = cb();
            int i2 = this.yX + cb;
            float f = ((float) this.yX) / ((float) cb);
            int i3 = cg.position;
            float f2 = ((((float) i) / ((float) cb)) - cg.zL) / (cg.zK + f);
            cb = (int) (((float) i2) * f2);
            this.zx = false;
            a(i3, f2, cb);
            if (this.zx) {
                return true;
            }
            throw new IllegalStateException("onPageScrolled did not call superclass implementation");
        } else if (this.zv) {
            return false;
        } else {
            this.zx = false;
            a(0, 0.0f, 0);
            if (this.zx) {
                return false;
            }
            throw new IllegalStateException("onPageScrolled did not call superclass implementation");
        }
    }

    private void a(int i, float f, int i2) {
        int paddingLeft;
        int paddingRight;
        int i3;
        if (this.zy > 0) {
            int scrollX = getScrollX();
            paddingLeft = getPaddingLeft();
            paddingRight = getPaddingRight();
            int width = getWidth();
            int childCount = getChildCount();
            i3 = 0;
            while (i3 < childCount) {
                int i4;
                View childAt = getChildAt(i3);
                ViewPager$LayoutParams viewPager$LayoutParams = (ViewPager$LayoutParams) childAt.getLayoutParams();
                if (viewPager$LayoutParams.zM) {
                    int max;
                    switch (viewPager$LayoutParams.gravity & 7) {
                        case 1:
                            max = Math.max((width - childAt.getMeasuredWidth()) / 2, paddingLeft);
                            i4 = paddingRight;
                            paddingRight = paddingLeft;
                            paddingLeft = i4;
                            break;
                        case 3:
                            max = childAt.getWidth() + paddingLeft;
                            i4 = paddingLeft;
                            paddingLeft = paddingRight;
                            paddingRight = max;
                            max = i4;
                            break;
                        case 5:
                            max = (width - paddingRight) - childAt.getMeasuredWidth();
                            i4 = paddingRight + childAt.getMeasuredWidth();
                            paddingRight = paddingLeft;
                            paddingLeft = i4;
                            break;
                        default:
                            max = paddingLeft;
                            i4 = paddingRight;
                            paddingRight = paddingLeft;
                            paddingLeft = i4;
                            break;
                    }
                    max = (max + scrollX) - childAt.getLeft();
                    if (max != 0) {
                        childAt.offsetLeftAndRight(max);
                    }
                } else {
                    i4 = paddingRight;
                    paddingRight = paddingLeft;
                    paddingLeft = i4;
                }
                i3++;
                i4 = paddingLeft;
                paddingLeft = paddingRight;
                paddingRight = i4;
            }
        }
        if (this.zA != null) {
            this.zA.a(i, f, i2);
        }
        if (this.zz != null) {
            paddingRight = this.zz.size();
            for (paddingLeft = 0; paddingLeft < paddingRight; paddingLeft++) {
                ViewPager$e viewPager$e = (ViewPager$e) this.zz.get(paddingLeft);
                if (viewPager$e != null) {
                    viewPager$e.a(i, f, i2);
                }
            }
        }
        if (this.zB != null) {
            this.zB.a(i, f, i2);
        }
        if (this.zD != null) {
            paddingRight = getScrollX();
            i3 = getChildCount();
            for (paddingLeft = 0; paddingLeft < i3; paddingLeft++) {
                View childAt2 = getChildAt(paddingLeft);
                if (!((ViewPager$LayoutParams) childAt2.getLayoutParams()).zM) {
                    this.zD.h(childAt2, ((float) (childAt2.getLeft() - paddingRight)) / ((float) cb()));
                }
            }
        }
        this.zx = true;
    }

    private void am(int i) {
        if (this.zA != null) {
            this.zA.af(i);
        }
        if (this.zz != null) {
            int size = this.zz.size();
            for (int i2 = 0; i2 < size; i2++) {
                ViewPager$e viewPager$e = (ViewPager$e) this.zz.get(i2);
                if (viewPager$e != null) {
                    viewPager$e.af(i);
                }
            }
        }
        if (this.zB != null) {
            this.zB.af(i);
        }
    }

    private void y(boolean z) {
        int scrollX;
        boolean z2 = this.yt == 2;
        if (z2) {
            boolean z3;
            setScrollingCacheEnabled(false);
            if (this.yU.isFinished()) {
                z3 = false;
            } else {
                z3 = true;
            }
            if (z3) {
                this.yU.abortAnimation();
                scrollX = getScrollX();
                int scrollY = getScrollY();
                int currX = this.yU.getCurrX();
                int currY = this.yU.getCurrY();
                if (!(scrollX == currX && scrollY == currY)) {
                    scrollTo(currX, currY);
                    if (currX != scrollX) {
                        al(currX);
                    }
                }
            }
        }
        this.zg = false;
        boolean z4 = z2;
        for (scrollX = 0; scrollX < this.eB.size(); scrollX++) {
            ViewPager$b viewPager$b = (ViewPager$b) this.eB.get(scrollX);
            if (viewPager$b.zJ) {
                viewPager$b.zJ = false;
                z4 = true;
            }
        }
        if (!z4) {
            return;
        }
        if (z) {
            z.a(this, this.zH);
        } else {
            this.zH.run();
        }
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        int action = motionEvent.getAction() & 255;
        if (action == 3 || action == 1) {
            ce();
            return false;
        }
        if (action != 0) {
            if (this.iW) {
                return true;
            }
            if (this.zi) {
                return false;
            }
        }
        float x;
        switch (action) {
            case 0:
                x = motionEvent.getX();
                this.ya = x;
                this.zl = x;
                x = motionEvent.getY();
                this.yb = x;
                this.zm = x;
                this.fG = o.c(motionEvent, 0);
                this.zi = false;
                this.yV = true;
                this.yU.computeScrollOffset();
                if (this.yt == 2 && Math.abs(this.yU.getFinalX() - this.yU.getCurrX()) > this.zq) {
                    this.yU.abortAnimation();
                    this.zg = false;
                    populate();
                    this.iW = true;
                    cf();
                    ah(1);
                    break;
                }
                y(false);
                this.iW = false;
                break;
                break;
            case 2:
                action = this.fG;
                if (action != -1) {
                    action = o.b(motionEvent, action);
                    float d = o.d(motionEvent, action);
                    float f = d - this.zl;
                    float abs = Math.abs(f);
                    float e = o.e(motionEvent, action);
                    float abs2 = Math.abs(e - this.yb);
                    if (f != 0.0f) {
                        x = this.zl;
                        boolean z = (x < ((float) this.zk) && f > 0.0f) || (x > ((float) (getWidth() - this.zk)) && f < 0.0f);
                        if (!z && a(this, false, (int) f, (int) d, (int) e)) {
                            this.zl = d;
                            this.zm = e;
                            this.zi = true;
                            return false;
                        }
                    }
                    if (abs > ((float) this.iY) && 0.5f * abs > abs2) {
                        this.iW = true;
                        cf();
                        ah(1);
                        this.zl = f > 0.0f ? this.ya + ((float) this.iY) : this.ya - ((float) this.iY);
                        this.zm = e;
                        setScrollingCacheEnabled(true);
                    } else if (abs2 > ((float) this.iY)) {
                        this.zi = true;
                    }
                    if (this.iW && r(d)) {
                        z.E(this);
                        break;
                    }
                }
                break;
            case 6:
                h(motionEvent);
                break;
        }
        if (this.fF == null) {
            this.fF = VelocityTracker.obtain();
        }
        this.fF.addMovement(motionEvent);
        return this.iW;
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        boolean z = false;
        if (this.zr) {
            return true;
        }
        if (motionEvent.getAction() == 0 && motionEvent.getEdgeFlags() != 0) {
            return false;
        }
        if (this.yP == null || this.yP.getCount() == 0) {
            return false;
        }
        if (this.fF == null) {
            this.fF = VelocityTracker.obtain();
        }
        this.fF.addMovement(motionEvent);
        float x;
        int i;
        float f;
        switch (motionEvent.getAction() & 255) {
            case 0:
                this.yU.abortAnimation();
                this.zg = false;
                populate();
                x = motionEvent.getX();
                this.ya = x;
                this.zl = x;
                x = motionEvent.getY();
                this.yb = x;
                this.zm = x;
                this.fG = o.c(motionEvent, 0);
                break;
            case 1:
                if (this.iW) {
                    VelocityTracker velocityTracker = this.fF;
                    velocityTracker.computeCurrentVelocity(1000, (float) this.zo);
                    int a = (int) y.a(velocityTracker, this.fG);
                    this.zg = true;
                    int cb = cb();
                    int scrollX = getScrollX();
                    ViewPager$b cg = cg();
                    float f2 = ((float) this.yX) / ((float) cb);
                    i = cg.position;
                    f = ((((float) scrollX) / ((float) cb)) - cg.zL) / (cg.zK + f2);
                    if (Math.abs((int) (o.d(motionEvent, o.b(motionEvent, this.fG)) - this.ya)) <= this.zp || Math.abs(a) <= this.zn) {
                        scrollX = (int) ((((float) i) + f) + (i >= this.yQ ? 0.4f : 0.6f));
                    } else {
                        if (a <= 0) {
                            i++;
                        }
                        scrollX = i;
                    }
                    if (this.eB.size() > 0) {
                        scrollX = Math.max(((ViewPager$b) this.eB.get(0)).position, Math.min(scrollX, ((ViewPager$b) this.eB.get(this.eB.size() - 1)).position));
                    }
                    a(scrollX, true, true, a);
                    z = ce();
                    break;
                }
                break;
            case 2:
                if (!this.iW) {
                    i = o.b(motionEvent, this.fG);
                    if (i == -1) {
                        z = ce();
                        break;
                    }
                    float d = o.d(motionEvent, i);
                    f = Math.abs(d - this.zl);
                    float e = o.e(motionEvent, i);
                    x = Math.abs(e - this.zm);
                    if (f > ((float) this.iY) && f > x) {
                        this.iW = true;
                        cf();
                        if (d - this.ya > 0.0f) {
                            x = this.ya + ((float) this.iY);
                        } else {
                            x = this.ya - ((float) this.iY);
                        }
                        this.zl = x;
                        this.zm = e;
                        ah(1);
                        setScrollingCacheEnabled(true);
                        ViewParent parent = getParent();
                        if (parent != null) {
                            parent.requestDisallowInterceptTouchEvent(true);
                        }
                    }
                }
                if (this.iW) {
                    z = r(o.d(motionEvent, o.b(motionEvent, this.fG))) | 0;
                    break;
                }
                break;
            case 3:
                if (this.iW) {
                    a(this.yQ, true, 0, false);
                    z = ce();
                    break;
                }
                break;
            case 5:
                i = o.e(motionEvent);
                this.zl = o.d(motionEvent, i);
                this.fG = o.c(motionEvent, i);
                break;
            case 6:
                h(motionEvent);
                this.zl = o.d(motionEvent, o.b(motionEvent, this.fG));
                break;
        }
        if (z) {
            z.E(this);
        }
        return true;
    }

    private boolean ce() {
        this.fG = -1;
        this.iW = false;
        this.zi = false;
        if (this.fF != null) {
            this.fF.recycle();
            this.fF = null;
        }
        return this.zt.cG() | this.zu.cG();
    }

    private void cf() {
        ViewParent parent = getParent();
        if (parent != null) {
            parent.requestDisallowInterceptTouchEvent(true);
        }
    }

    private boolean r(float f) {
        boolean z;
        float f2;
        boolean z2 = true;
        boolean z3 = false;
        float f3 = this.zl - f;
        this.zl = f;
        float scrollX = ((float) getScrollX()) + f3;
        int cb = cb();
        float f4 = ((float) cb) * this.zb;
        float f5 = ((float) cb) * this.zc;
        ViewPager$b viewPager$b = (ViewPager$b) this.eB.get(0);
        ViewPager$b viewPager$b2 = (ViewPager$b) this.eB.get(this.eB.size() - 1);
        if (viewPager$b.position != 0) {
            f4 = viewPager$b.zL * ((float) cb);
            z = false;
        } else {
            z = true;
        }
        if (viewPager$b2.position != this.yP.getCount() - 1) {
            f2 = viewPager$b2.zL * ((float) cb);
            z2 = false;
        } else {
            f2 = f5;
        }
        if (scrollX < f4) {
            if (z) {
                z3 = this.zt.z(Math.abs(f4 - scrollX) / ((float) cb));
            }
        } else if (scrollX > f2) {
            if (z2) {
                z3 = this.zu.z(Math.abs(scrollX - f2) / ((float) cb));
            }
            f4 = f2;
        } else {
            f4 = scrollX;
        }
        this.zl += f4 - ((float) ((int) f4));
        scrollTo((int) f4, getScrollY());
        al((int) f4);
        return z3;
    }

    private ViewPager$b cg() {
        float f;
        int cb = cb();
        float scrollX = cb > 0 ? ((float) getScrollX()) / ((float) cb) : 0.0f;
        if (cb > 0) {
            f = ((float) this.yX) / ((float) cb);
        } else {
            f = 0.0f;
        }
        float f2 = 0.0f;
        float f3 = 0.0f;
        int i = -1;
        int i2 = 0;
        Object obj = 1;
        ViewPager$b viewPager$b = null;
        while (i2 < this.eB.size()) {
            int i3;
            ViewPager$b viewPager$b2;
            ViewPager$b viewPager$b3 = (ViewPager$b) this.eB.get(i2);
            ViewPager$b viewPager$b4;
            if (obj != null || viewPager$b3.position == i + 1) {
                viewPager$b4 = viewPager$b3;
                i3 = i2;
                viewPager$b2 = viewPager$b4;
            } else {
                viewPager$b3 = this.yO;
                viewPager$b3.zL = (f2 + f3) + f;
                viewPager$b3.position = i + 1;
                viewPager$b3.zK = 1.0f;
                viewPager$b4 = viewPager$b3;
                i3 = i2 - 1;
                viewPager$b2 = viewPager$b4;
            }
            f2 = viewPager$b2.zL;
            f3 = (viewPager$b2.zK + f2) + f;
            if (obj == null && scrollX < f2) {
                return viewPager$b;
            }
            if (scrollX < f3 || i3 == this.eB.size() - 1) {
                return viewPager$b2;
            }
            f3 = f2;
            i = viewPager$b2.position;
            obj = null;
            f2 = viewPager$b2.zK;
            viewPager$b = viewPager$b2;
            i2 = i3 + 1;
        }
        return viewPager$b;
    }

    public void draw(Canvas canvas) {
        super.draw(canvas);
        int i = 0;
        int B = z.B(this);
        if (B == 0 || (B == 1 && this.yP != null && this.yP.getCount() > 1)) {
            int width;
            if (!this.zt.isFinished()) {
                B = canvas.save();
                i = (getHeight() - getPaddingTop()) - getPaddingBottom();
                width = getWidth();
                canvas.rotate(270.0f);
                canvas.translate((float) ((-i) + getPaddingTop()), this.zb * ((float) width));
                this.zt.setSize(i, width);
                i = this.zt.draw(canvas) | 0;
                canvas.restoreToCount(B);
            }
            if (!this.zu.isFinished()) {
                B = canvas.save();
                width = getWidth();
                int height = (getHeight() - getPaddingTop()) - getPaddingBottom();
                canvas.rotate(90.0f);
                canvas.translate((float) (-getPaddingTop()), (-(this.zc + 1.0f)) * ((float) width));
                this.zu.setSize(height, width);
                i |= this.zu.draw(canvas);
                canvas.restoreToCount(B);
            }
        } else {
            this.zt.finish();
            this.zu.finish();
        }
        if (i != 0) {
            z.E(this);
        }
    }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.yX > 0 && this.yY != null && this.eB.size() > 0 && this.yP != null) {
            int scrollX = getScrollX();
            int width = getWidth();
            float f = ((float) this.yX) / ((float) width);
            ViewPager$b viewPager$b = (ViewPager$b) this.eB.get(0);
            float f2 = viewPager$b.zL;
            int size = this.eB.size();
            int i = viewPager$b.position;
            int i2 = ((ViewPager$b) this.eB.get(size - 1)).position;
            int i3 = 0;
            int i4 = i;
            while (i4 < i2) {
                float f3;
                while (i4 > viewPager$b.position && i3 < size) {
                    i3++;
                    viewPager$b = (ViewPager$b) this.eB.get(i3);
                }
                if (i4 == viewPager$b.position) {
                    f3 = (viewPager$b.zL + viewPager$b.zK) * ((float) width);
                    f2 = (viewPager$b.zL + viewPager$b.zK) + f;
                } else {
                    f3 = (1.0f + f2) * ((float) width);
                    f2 += 1.0f + f;
                }
                if (((float) this.yX) + f3 > ((float) scrollX)) {
                    this.yY.setBounds(Math.round(f3), this.yZ, Math.round(((float) this.yX) + f3), this.za);
                    this.yY.draw(canvas);
                }
                if (f3 <= ((float) (scrollX + width))) {
                    i4++;
                } else {
                    return;
                }
            }
        }
    }

    private void h(MotionEvent motionEvent) {
        int e = o.e(motionEvent);
        if (o.c(motionEvent, e) == this.fG) {
            e = e == 0 ? 1 : 0;
            this.zl = o.d(motionEvent, e);
            this.fG = o.c(motionEvent, e);
            if (this.fF != null) {
                this.fF.clear();
            }
        }
    }

    private void setScrollingCacheEnabled(boolean z) {
        if (this.zf != z) {
            this.zf = z;
        }
    }

    public boolean canScrollHorizontally(int i) {
        if (this.yP == null) {
            return false;
        }
        int cb = cb();
        int scrollX = getScrollX();
        if (i < 0) {
            if (scrollX > ((int) (((float) cb) * this.zb))) {
                return true;
            }
            return false;
        } else if (i <= 0 || scrollX >= ((int) (((float) cb) * this.zc))) {
            return false;
        } else {
            return true;
        }
    }

    private boolean a(View view, boolean z, int i, int i2, int i3) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            int scrollX = view.getScrollX();
            int scrollY = view.getScrollY();
            for (int childCount = viewGroup.getChildCount() - 1; childCount >= 0; childCount--) {
                View childAt = viewGroup.getChildAt(childCount);
                if (i2 + scrollX >= childAt.getLeft() && i2 + scrollX < childAt.getRight() && i3 + scrollY >= childAt.getTop() && i3 + scrollY < childAt.getBottom()) {
                    if (a(childAt, true, i, (i2 + scrollX) - childAt.getLeft(), (i3 + scrollY) - childAt.getTop())) {
                        return true;
                    }
                }
            }
        }
        if (z && z.g(view, -i)) {
            return true;
        }
        return false;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean dispatchKeyEvent(android.view.KeyEvent r5) {
        /*
        r4 = this;
        r0 = 0;
        r1 = 1;
        r2 = super.dispatchKeyEvent(r5);
        if (r2 != 0) goto L_0x0018;
    L_0x0008:
        r2 = r5.getAction();
        if (r2 != 0) goto L_0x0015;
    L_0x000e:
        r2 = r5.getKeyCode();
        switch(r2) {
            case 21: goto L_0x001a;
            case 22: goto L_0x0021;
            case 61: goto L_0x0028;
            default: goto L_0x0015;
        };
    L_0x0015:
        r2 = r0;
    L_0x0016:
        if (r2 == 0) goto L_0x0019;
    L_0x0018:
        r0 = r1;
    L_0x0019:
        return r0;
    L_0x001a:
        r2 = 17;
        r2 = r4.arrowScroll(r2);
        goto L_0x0016;
    L_0x0021:
        r2 = 66;
        r2 = r4.arrowScroll(r2);
        goto L_0x0016;
    L_0x0028:
        r2 = android.os.Build.VERSION.SDK_INT;
        r3 = 11;
        if (r2 < r3) goto L_0x0015;
    L_0x002e:
        r2 = android.support.v4.view.g.a(r5);
        if (r2 == 0) goto L_0x003a;
    L_0x0034:
        r2 = 2;
        r2 = r4.arrowScroll(r2);
        goto L_0x0016;
    L_0x003a:
        r2 = android.support.v4.view.g.a(r5, r1);
        if (r2 == 0) goto L_0x0015;
    L_0x0040:
        r2 = r4.arrowScroll(r1);
        goto L_0x0016;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.view.ViewPager.dispatchKeyEvent(android.view.KeyEvent):boolean");
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private boolean arrowScroll(int r10) {
        /*
        r9 = this;
        r1 = 0;
        r8 = 66;
        r7 = 17;
        r4 = 1;
        r3 = 0;
        r2 = r9.findFocus();
        if (r2 != r9) goto L_0x003e;
    L_0x000d:
        r0 = r1;
    L_0x000e:
        r1 = android.view.FocusFinder.getInstance();
        r1 = r1.findNextFocus(r9, r0, r10);
        if (r1 == 0) goto L_0x00b3;
    L_0x0018:
        if (r1 == r0) goto L_0x00b3;
    L_0x001a:
        if (r10 != r7) goto L_0x0098;
    L_0x001c:
        r2 = r9.eK;
        r2 = r9.a(r2, r1);
        r2 = r2.left;
        r3 = r9.eK;
        r3 = r9.a(r3, r0);
        r3 = r3.left;
        if (r0 == 0) goto L_0x0093;
    L_0x002e:
        if (r2 < r3) goto L_0x0093;
    L_0x0030:
        r0 = r9.ch();
    L_0x0034:
        if (r0 == 0) goto L_0x003d;
    L_0x0036:
        r1 = android.view.SoundEffectConstants.getContantForFocusDirection(r10);
        r9.playSoundEffect(r1);
    L_0x003d:
        return r0;
    L_0x003e:
        if (r2 == 0) goto L_0x00cb;
    L_0x0040:
        r0 = r2.getParent();
    L_0x0044:
        r5 = r0 instanceof android.view.ViewGroup;
        if (r5 == 0) goto L_0x00ce;
    L_0x0048:
        if (r0 != r9) goto L_0x007c;
    L_0x004a:
        r0 = r4;
    L_0x004b:
        if (r0 != 0) goto L_0x00cb;
    L_0x004d:
        r5 = new java.lang.StringBuilder;
        r5.<init>();
        r0 = r2.getClass();
        r0 = r0.getSimpleName();
        r5.append(r0);
        r0 = r2.getParent();
    L_0x0061:
        r2 = r0 instanceof android.view.ViewGroup;
        if (r2 == 0) goto L_0x0081;
    L_0x0065:
        r2 = " => ";
        r2 = r5.append(r2);
        r6 = r0.getClass();
        r6 = r6.getSimpleName();
        r2.append(r6);
        r0 = r0.getParent();
        goto L_0x0061;
    L_0x007c:
        r0 = r0.getParent();
        goto L_0x0044;
    L_0x0081:
        r0 = new java.lang.StringBuilder;
        r2 = "arrowScroll tried to find focus based on non-child current focused view ";
        r0.<init>(r2);
        r2 = r5.toString();
        r0.append(r2);
        r0 = r1;
        goto L_0x000e;
    L_0x0093:
        r0 = r1.requestFocus();
        goto L_0x0034;
    L_0x0098:
        if (r10 != r8) goto L_0x00c8;
    L_0x009a:
        r2 = r9.eK;
        r2 = r9.a(r2, r1);
        r2 = r2.left;
        r3 = r9.eK;
        r3 = r9.a(r3, r0);
        r3 = r3.left;
        if (r0 == 0) goto L_0x00ae;
    L_0x00ac:
        if (r2 <= r3) goto L_0x00c2;
    L_0x00ae:
        r0 = r1.requestFocus();
        goto L_0x0034;
    L_0x00b3:
        if (r10 == r7) goto L_0x00b7;
    L_0x00b5:
        if (r10 != r4) goto L_0x00bd;
    L_0x00b7:
        r0 = r9.ch();
        goto L_0x0034;
    L_0x00bd:
        if (r10 == r8) goto L_0x00c2;
    L_0x00bf:
        r0 = 2;
        if (r10 != r0) goto L_0x00c8;
    L_0x00c2:
        r0 = r9.ci();
        goto L_0x0034;
    L_0x00c8:
        r0 = r3;
        goto L_0x0034;
    L_0x00cb:
        r0 = r2;
        goto L_0x000e;
    L_0x00ce:
        r0 = r3;
        goto L_0x004b;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.view.ViewPager.arrowScroll(int):boolean");
    }

    private Rect a(Rect rect, View view) {
        Rect rect2;
        if (rect == null) {
            rect2 = new Rect();
        } else {
            rect2 = rect;
        }
        if (view == null) {
            rect2.set(0, 0, 0, 0);
            return rect2;
        }
        rect2.left = view.getLeft();
        rect2.right = view.getRight();
        rect2.top = view.getTop();
        rect2.bottom = view.getBottom();
        ViewPager parent = view.getParent();
        while ((parent instanceof ViewGroup) && parent != this) {
            ViewGroup viewGroup = parent;
            rect2.left += viewGroup.getLeft();
            rect2.right += viewGroup.getRight();
            rect2.top += viewGroup.getTop();
            rect2.bottom += viewGroup.getBottom();
            parent = viewGroup.getParent();
        }
        return rect2;
    }

    private boolean ch() {
        if (this.yQ <= 0) {
            return false;
        }
        k(this.yQ - 1, true);
        return true;
    }

    private boolean ci() {
        if (this.yP == null || this.yQ >= this.yP.getCount() - 1) {
            return false;
        }
        k(this.yQ + 1, true);
        return true;
    }

    public void addFocusables(ArrayList<View> arrayList, int i, int i2) {
        int size = arrayList.size();
        int descendantFocusability = getDescendantFocusability();
        if (descendantFocusability != 393216) {
            for (int i3 = 0; i3 < getChildCount(); i3++) {
                View childAt = getChildAt(i3);
                if (childAt.getVisibility() == 0) {
                    ViewPager$b ao = ao(childAt);
                    if (ao != null && ao.position == this.yQ) {
                        childAt.addFocusables(arrayList, i, i2);
                    }
                }
            }
        }
        if ((descendantFocusability == 262144 && size != arrayList.size()) || !isFocusable()) {
            return;
        }
        if (((i2 & 1) != 1 || !isInTouchMode() || isFocusableInTouchMode()) && arrayList != null) {
            arrayList.add(this);
        }
    }

    public void addTouchables(ArrayList<View> arrayList) {
        for (int i = 0; i < getChildCount(); i++) {
            View childAt = getChildAt(i);
            if (childAt.getVisibility() == 0) {
                ViewPager$b ao = ao(childAt);
                if (ao != null && ao.position == this.yQ) {
                    childAt.addTouchables(arrayList);
                }
            }
        }
    }

    protected boolean onRequestFocusInDescendants(int i, Rect rect) {
        int i2;
        int i3 = -1;
        int childCount = getChildCount();
        if ((i & 2) != 0) {
            i3 = 1;
            i2 = 0;
        } else {
            i2 = childCount - 1;
            childCount = -1;
        }
        while (i2 != childCount) {
            View childAt = getChildAt(i2);
            if (childAt.getVisibility() == 0) {
                ViewPager$b ao = ao(childAt);
                if (ao != null && ao.position == this.yQ && childAt.requestFocus(i, rect)) {
                    return true;
                }
            }
            i2 += i3;
        }
        return false;
    }

    public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        if (accessibilityEvent.getEventType() == 4096) {
            return super.dispatchPopulateAccessibilityEvent(accessibilityEvent);
        }
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            if (childAt.getVisibility() == 0) {
                ViewPager$b ao = ao(childAt);
                if (ao != null && ao.position == this.yQ && childAt.dispatchPopulateAccessibilityEvent(accessibilityEvent)) {
                    return true;
                }
            }
        }
        return false;
    }

    protected LayoutParams generateDefaultLayoutParams() {
        return new ViewPager$LayoutParams();
    }

    protected LayoutParams generateLayoutParams(LayoutParams layoutParams) {
        return generateDefaultLayoutParams();
    }

    protected boolean checkLayoutParams(LayoutParams layoutParams) {
        return (layoutParams instanceof ViewPager$LayoutParams) && super.checkLayoutParams(layoutParams);
    }

    public LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new ViewPager$LayoutParams(getContext(), attributeSet);
    }
}
