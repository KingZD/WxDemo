package android.support.v4.app;

import android.content.Intent;
import android.os.Build.VERSION;
import android.os.Bundle;

public final class ah extends android.support.v4.app.aj.a {
    private static final ah$b ty;
    public static final aj$a$a tz = new aj$a$a() {
    };
    private final Bundle mExtras;
    private final String tu;
    private final CharSequence tv;
    private final CharSequence[] tw;
    private final boolean tx;

    public static final class a {
        public Bundle mExtras = new Bundle();
        public final String tu;
        public CharSequence tv;
        public CharSequence[] tw;
        public boolean tx = true;

        public a(String str) {
            this.tu = str;
        }
    }

    private ah(String str, CharSequence charSequence, CharSequence[] charSequenceArr, boolean z, Bundle bundle) {
        this.tu = str;
        this.tv = charSequence;
        this.tw = charSequenceArr;
        this.tx = z;
        this.mExtras = bundle;
    }

    public final String getResultKey() {
        return this.tu;
    }

    public final CharSequence getLabel() {
        return this.tv;
    }

    public final CharSequence[] getChoices() {
        return this.tw;
    }

    public final boolean getAllowFreeFormInput() {
        return this.tx;
    }

    public final Bundle getExtras() {
        return this.mExtras;
    }

    public static Bundle getResultsFromIntent(Intent intent) {
        return ty.getResultsFromIntent(intent);
    }

    static {
        if (VERSION.SDK_INT >= 20) {
            ty = new ah$c();
        } else if (VERSION.SDK_INT >= 16) {
            ty = new ah$e();
        } else {
            ty = new ah$d();
        }
    }
}
