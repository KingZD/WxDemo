package android.support.v4.b.a;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader.TileMode;
import android.graphics.drawable.Drawable;
import com.tencent.mm.plugin.appbrand.jsapi.audio.JsApiSetBackgroundAudioState;

public abstract class i extends Drawable {
    public final Paint fO = new Paint(3);
    public float jq;
    final Bitmap mBitmap;
    private int uA;
    private int uB;
    private int ur = JsApiSetBackgroundAudioState.CTRL_INDEX;
    private int ut = 119;
    public final BitmapShader uu;
    private final Matrix uv = new Matrix();
    final Rect uw = new Rect();
    private final RectF ux = new RectF();
    private boolean uy = true;
    public boolean uz;

    public void setFilterBitmap(boolean z) {
        this.fO.setFilterBitmap(z);
        invalidateSelf();
    }

    public void setDither(boolean z) {
        this.fO.setDither(z);
        invalidateSelf();
    }

    void a(int i, int i2, int i3, Rect rect, Rect rect2) {
        throw new UnsupportedOperationException();
    }

    final void bB() {
        if (this.uy) {
            if (this.uz) {
                int min = Math.min(this.uA, this.uB);
                a(this.ut, min, min, getBounds(), this.uw);
                int min2 = Math.min(this.uw.width(), this.uw.height());
                this.uw.inset(Math.max(0, (this.uw.width() - min2) / 2), Math.max(0, (this.uw.height() - min2) / 2));
                this.jq = ((float) min2) * 0.5f;
            } else {
                a(this.ut, this.uA, this.uB, getBounds(), this.uw);
            }
            this.ux.set(this.uw);
            if (this.uu != null) {
                this.uv.setTranslate(this.ux.left, this.ux.top);
                this.uv.preScale(this.ux.width() / ((float) this.mBitmap.getWidth()), this.ux.height() / ((float) this.mBitmap.getHeight()));
                this.uu.setLocalMatrix(this.uv);
                this.fO.setShader(this.uu);
            }
            this.uy = false;
        }
    }

    public void draw(Canvas canvas) {
        Bitmap bitmap = this.mBitmap;
        if (bitmap != null) {
            bB();
            if (this.fO.getShader() == null) {
                canvas.drawBitmap(bitmap, null, this.uw, this.fO);
            } else {
                canvas.drawRoundRect(this.ux, this.jq, this.jq, this.fO);
            }
        }
    }

    public void setAlpha(int i) {
        if (i != this.fO.getAlpha()) {
            this.fO.setAlpha(i);
            invalidateSelf();
        }
    }

    public int getAlpha() {
        return this.fO.getAlpha();
    }

    public void setColorFilter(ColorFilter colorFilter) {
        this.fO.setColorFilter(colorFilter);
        invalidateSelf();
    }

    public ColorFilter getColorFilter() {
        return this.fO.getColorFilter();
    }

    public final void bC() {
        this.uz = true;
        this.uy = true;
        bD();
        this.fO.setShader(this.uu);
        invalidateSelf();
    }

    private void bD() {
        this.jq = (float) (Math.min(this.uB, this.uA) / 2);
    }

    protected void onBoundsChange(Rect rect) {
        super.onBoundsChange(rect);
        if (this.uz) {
            bD();
        }
        this.uy = true;
    }

    public int getIntrinsicWidth() {
        return this.uA;
    }

    public int getIntrinsicHeight() {
        return this.uB;
    }

    public int getOpacity() {
        if (this.ut != 119 || this.uz) {
            return -3;
        }
        Bitmap bitmap = this.mBitmap;
        if (bitmap == null || bitmap.hasAlpha() || this.fO.getAlpha() < 255 || q(this.jq)) {
            return -3;
        }
        return -1;
    }

    i(Resources resources, Bitmap bitmap) {
        if (resources != null) {
            this.ur = resources.getDisplayMetrics().densityDpi;
        }
        this.mBitmap = bitmap;
        if (this.mBitmap != null) {
            this.uA = this.mBitmap.getScaledWidth(this.ur);
            this.uB = this.mBitmap.getScaledHeight(this.ur);
            this.uu = new BitmapShader(this.mBitmap, TileMode.CLAMP, TileMode.CLAMP);
            return;
        }
        this.uB = -1;
        this.uA = -1;
        this.uu = null;
    }

    public static boolean q(float f) {
        return f > 0.05f;
    }
}
