package android.support.design.widget;

class TabLayout$a$2 extends u$b {
    final /* synthetic */ TabLayout$a kS;
    final /* synthetic */ int kT;

    TabLayout$a$2(TabLayout$a tabLayout$a, int i) {
        this.kS = tabLayout$a;
        this.kT = i;
    }

    public final void aE() {
        TabLayout$a.a(this.kS, this.kT);
        TabLayout$a.a(this.kS);
    }
}
