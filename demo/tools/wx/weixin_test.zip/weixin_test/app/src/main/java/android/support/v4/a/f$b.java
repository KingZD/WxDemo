package android.support.v4.a;

import android.animation.Animator;
import android.animation.ValueAnimator;
import android.view.View;

class f$b implements g {
    final Animator pe;

    public f$b(Animator animator) {
        this.pe = animator;
    }

    public final void w(View view) {
        this.pe.setTarget(view);
    }

    public final void a(b bVar) {
        this.pe.addListener(new f$a(bVar, this));
    }

    public final void setDuration(long j) {
        this.pe.setDuration(j);
    }

    public final void start() {
        this.pe.start();
    }

    public final void cancel() {
        this.pe.cancel();
    }

    public final void a(d dVar) {
        if (this.pe instanceof ValueAnimator) {
            ((ValueAnimator) this.pe).addUpdateListener(new f$b$1(this, dVar));
        }
    }

    public final float getAnimatedFraction() {
        return ((ValueAnimator) this.pe).getAnimatedFraction();
    }
}
