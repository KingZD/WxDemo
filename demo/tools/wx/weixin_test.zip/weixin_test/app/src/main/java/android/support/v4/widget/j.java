package android.support.v4.widget;

import android.widget.EdgeEffect;

final class j {
    public static boolean a(Object obj, float f) {
        ((EdgeEffect) obj).onPull(f);
        return true;
    }
}
