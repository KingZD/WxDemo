package android.support.v4.widget;

import android.graphics.Paint;
import android.graphics.Paint.Cap;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.Drawable.Callback;

class l$a {
    final RectF CX = new RectF();
    final Paint CY = new Paint();
    float CZ = 0.0f;
    float Da = 0.0f;
    float Db = 2.5f;
    int[] Dc;
    int Dd;
    float De;
    float Df;
    float Dg;
    boolean Dh;
    Path Di;
    float Dj;
    double Dk;
    int Dl;
    int Dm;
    int Dn;
    final Paint Do = new Paint(1);
    int Dp;
    final Paint fO = new Paint();
    float fZ = 0.0f;
    float mL = 5.0f;
    private final Callback mn;
    int ul;

    public l$a(Callback callback) {
        this.mn = callback;
        this.fO.setStrokeCap(Cap.SQUARE);
        this.fO.setAntiAlias(true);
        this.fO.setStyle(Style.STROKE);
        this.CY.setStyle(Style.FILL);
        this.CY.setAntiAlias(true);
    }

    public final void ar(int i) {
        this.Dd = i;
        this.ul = this.Dc[this.Dd];
    }

    final int cI() {
        return (this.Dd + 1) % this.Dc.length;
    }

    public final void C(float f) {
        this.CZ = f;
        invalidateSelf();
    }

    public final void D(float f) {
        this.Da = f;
        invalidateSelf();
    }

    public final void setRotation(float f) {
        this.fZ = f;
        invalidateSelf();
    }

    public final void C(boolean z) {
        if (this.Dh != z) {
            this.Dh = z;
            invalidateSelf();
        }
    }

    public final void cJ() {
        this.De = this.CZ;
        this.Df = this.Da;
        this.Dg = this.fZ;
    }

    public final void cK() {
        this.De = 0.0f;
        this.Df = 0.0f;
        this.Dg = 0.0f;
        C(0.0f);
        D(0.0f);
        setRotation(0.0f);
    }

    final void invalidateSelf() {
        this.mn.invalidateDrawable(null);
    }
}
