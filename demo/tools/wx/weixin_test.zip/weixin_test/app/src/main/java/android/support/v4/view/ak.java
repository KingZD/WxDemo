package android.support.v4.view;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;

final class ak {

    /* renamed from: android.support.v4.view.ak$1 */
    static class AnonymousClass1 extends AnimatorListenerAdapter {
        final /* synthetic */ am Ac;
        final /* synthetic */ View val$view;

        AnonymousClass1(am amVar, View view) {
            this.Ac = amVar;
            this.val$view = view;
        }

        public final void onAnimationCancel(Animator animator) {
            this.Ac.ar(this.val$view);
        }

        public final void onAnimationEnd(Animator animator) {
            this.Ac.q(this.val$view);
        }

        public final void onAnimationStart(Animator animator) {
            this.Ac.p(this.val$view);
        }
    }
}
