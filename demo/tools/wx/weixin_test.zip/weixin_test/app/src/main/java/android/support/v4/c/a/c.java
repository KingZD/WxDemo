package android.support.v4.c.a;

import android.view.SubMenu;

public interface c extends a, SubMenu {
}
