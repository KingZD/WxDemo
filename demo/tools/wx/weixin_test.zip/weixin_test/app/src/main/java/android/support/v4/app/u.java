package android.support.v4.app;

import android.os.Bundle;
import android.support.v4.content.c;
import android.support.v4.content.c.b;
import android.support.v4.e.k;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.reflect.Modifier;

public final class u extends t {
    public static boolean DEBUG = false;
    l mHost;
    boolean mRetaining;
    final String mWho;
    boolean oX;
    final k<a> rM = new k();
    final k<a> rN = new k();
    boolean rO;

    final class a implements android.support.v4.content.c.a<Object>, b<Object> {
        Object mData;
        final int mId;
        boolean mRetaining;
        boolean oX;
        boolean qP;
        final Bundle rP;
        android.support.v4.app.t.a<Object> rQ;
        c<Object> rR;
        boolean rS;
        boolean rT;
        boolean rU;
        boolean rV;
        boolean rW;
        a rX;
        final /* synthetic */ u rY;

        public a(u uVar, int i, Bundle bundle, android.support.v4.app.t.a<Object> aVar) {
            this.rY = uVar;
            this.mId = i;
            this.rP = bundle;
            this.rQ = aVar;
        }

        final void start() {
            if (this.mRetaining && this.rU) {
                this.oX = true;
            } else if (!this.oX) {
                this.oX = true;
                if (u.DEBUG) {
                    new StringBuilder("  Starting: ").append(this);
                }
                if (this.rR == null && this.rQ != null) {
                    this.rR = this.rQ.U(this.mId);
                }
                if (this.rR == null) {
                    return;
                }
                if (!this.rR.getClass().isMemberClass() || Modifier.isStatic(this.rR.getClass().getModifiers())) {
                    c cVar;
                    if (!this.rW) {
                        cVar = this.rR;
                        int i = this.mId;
                        if (cVar.tM != null) {
                            throw new IllegalStateException("There is already a listener registered");
                        }
                        cVar.tM = this;
                        cVar.mId = i;
                        cVar = this.rR;
                        if (cVar.tN != null) {
                            throw new IllegalStateException("There is already a listener registered");
                        }
                        cVar.tN = this;
                        this.rW = true;
                    }
                    cVar = this.rR;
                    cVar.oX = true;
                    cVar.tP = false;
                    cVar.tO = false;
                    cVar.onStartLoading();
                    return;
                }
                throw new IllegalArgumentException("Object returned from onCreateLoader must not be a non-static inner member class: " + this.rR);
            }
        }

        final void stop() {
            if (u.DEBUG) {
                new StringBuilder("  Stopping: ").append(this);
            }
            this.oX = false;
            if (!this.mRetaining && this.rR != null && this.rW) {
                this.rW = false;
                this.rR.a((b) this);
                this.rR.a((android.support.v4.content.c.a) this);
                c cVar = this.rR;
                cVar.oX = false;
                cVar.onStopLoading();
            }
        }

        final void destroy() {
            while (true) {
                android.support.v4.content.c.a this;
                if (u.DEBUG) {
                    new StringBuilder("  Destroying: ").append(this);
                }
                this.qP = true;
                boolean z = this.rT;
                this.rT = false;
                if (this.rQ != null && this.rR != null && this.rS && z) {
                    String str;
                    if (u.DEBUG) {
                        new StringBuilder("  Reseting: ").append(this);
                    }
                    if (this.rY.mHost != null) {
                        str = this.rY.mHost.mFragmentManager.qQ;
                        this.rY.mHost.mFragmentManager.qQ = "onLoaderReset";
                    } else {
                        str = null;
                    }
                    if (this.rY.mHost != null) {
                        this.rY.mHost.mFragmentManager.qQ = str;
                    }
                }
                this.rQ = null;
                this.mData = null;
                this.rS = false;
                if (this.rR != null) {
                    if (this.rW) {
                        this.rW = false;
                        this.rR.a((b) this);
                        this.rR.a(this);
                    }
                    c cVar = this.rR;
                    cVar.onReset();
                    cVar.tP = true;
                    cVar.oX = false;
                    cVar.tO = false;
                    cVar.tQ = false;
                    cVar.tR = false;
                }
                if (this.rX != null) {
                    this = this.rX;
                } else {
                    return;
                }
            }
        }

        public final void b(c<Object> cVar, Object obj) {
            if (u.DEBUG) {
                new StringBuilder("onLoadComplete: ").append(this);
            }
            if (!this.qP && this.rY.rM.get(this.mId) == this) {
                a aVar = this.rX;
                if (aVar != null) {
                    if (u.DEBUG) {
                        new StringBuilder("  Switching to pending loader: ").append(aVar);
                    }
                    this.rX = null;
                    this.rY.rM.put(this.mId, null);
                    destroy();
                    this.rY.a(aVar);
                    return;
                }
                if (!(this.mData == obj && this.rS)) {
                    this.mData = obj;
                    this.rS = true;
                    if (this.oX) {
                        c(cVar, obj);
                    }
                }
                aVar = (a) this.rY.rN.get(this.mId);
                if (!(aVar == null || aVar == this)) {
                    aVar.rT = false;
                    aVar.destroy();
                    this.rY.rN.remove(this.mId);
                }
                if (this.rY.mHost != null && !this.rY.bk()) {
                    this.rY.mHost.mFragmentManager.bf();
                }
            }
        }

        final void c(c<Object> cVar, Object obj) {
            String str;
            if (this.rQ != null) {
                if (this.rY.mHost != null) {
                    String str2 = this.rY.mHost.mFragmentManager.qQ;
                    this.rY.mHost.mFragmentManager.qQ = "onLoadFinished";
                    str = str2;
                } else {
                    str = null;
                }
                try {
                    if (u.DEBUG) {
                        StringBuilder append = new StringBuilder("  onLoadFinished in ").append(cVar).append(": ");
                        StringBuilder stringBuilder = new StringBuilder(64);
                        android.support.v4.e.c.a(obj, stringBuilder);
                        stringBuilder.append("}");
                        append.append(stringBuilder.toString());
                    }
                    this.rQ.a(cVar, obj);
                    this.rT = true;
                } finally {
                    if (this.rY.mHost != null) {
                        this.rY.mHost.mFragmentManager.qQ = str;
                    }
                }
            }
        }

        public final String toString() {
            StringBuilder stringBuilder = new StringBuilder(64);
            stringBuilder.append("LoaderInfo{");
            stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
            stringBuilder.append(" #");
            stringBuilder.append(this.mId);
            stringBuilder.append(" : ");
            android.support.v4.e.c.a(this.rR, stringBuilder);
            stringBuilder.append("}}");
            return stringBuilder.toString();
        }

        public final void dump(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
            while (true) {
                printWriter.print(str);
                printWriter.print("mId=");
                printWriter.print(this.mId);
                printWriter.print(" mArgs=");
                printWriter.println(this.rP);
                printWriter.print(str);
                printWriter.print("mCallbacks=");
                printWriter.println(this.rQ);
                printWriter.print(str);
                printWriter.print("mLoader=");
                printWriter.println(this.rR);
                if (this.rR != null) {
                    this.rR.dump(str + "  ", fileDescriptor, printWriter, strArr);
                }
                if (this.rS || this.rT) {
                    printWriter.print(str);
                    printWriter.print("mHaveData=");
                    printWriter.print(this.rS);
                    printWriter.print("  mDeliveredData=");
                    printWriter.println(this.rT);
                    printWriter.print(str);
                    printWriter.print("mData=");
                    printWriter.println(this.mData);
                }
                printWriter.print(str);
                printWriter.print("mStarted=");
                printWriter.print(this.oX);
                printWriter.print(" mReportNextStart=");
                printWriter.print(this.rV);
                printWriter.print(" mDestroyed=");
                printWriter.println(this.qP);
                printWriter.print(str);
                printWriter.print("mRetaining=");
                printWriter.print(this.mRetaining);
                printWriter.print(" mRetainingStarted=");
                printWriter.print(this.rU);
                printWriter.print(" mListenerRegistered=");
                printWriter.println(this.rW);
                if (this.rX != null) {
                    printWriter.print(str);
                    printWriter.println("Pending Loader ");
                    printWriter.print(this.rX);
                    printWriter.println(":");
                    this = this.rX;
                    str = str + "  ";
                } else {
                    return;
                }
            }
        }
    }

    u(String str, l lVar, boolean z) {
        this.mWho = str;
        this.mHost = lVar;
        this.oX = z;
    }

    private a a(int i, Bundle bundle, android.support.v4.app.t.a<Object> aVar) {
        a aVar2 = new a(this, i, bundle, aVar);
        aVar2.rR = aVar.U(i);
        return aVar2;
    }

    private a b(int i, Bundle bundle, android.support.v4.app.t.a<Object> aVar) {
        try {
            this.rO = true;
            a a = a(i, null, aVar);
            a(a);
            return a;
        } finally {
            this.rO = false;
        }
    }

    final void a(a aVar) {
        this.rM.put(aVar.mId, aVar);
        if (this.oX) {
            aVar.start();
        }
    }

    public final <D> c<D> a(int i, android.support.v4.app.t.a<D> aVar) {
        if (this.rO) {
            throw new IllegalStateException("Called while creating a loader");
        }
        a aVar2 = (a) this.rM.get(i);
        if (DEBUG) {
            new StringBuilder("initLoader in ").append(this).append(": args=").append(null);
        }
        if (aVar2 == null) {
            aVar2 = b(i, null, aVar);
            if (DEBUG) {
                new StringBuilder("  Created new loader ").append(aVar2);
            }
        } else {
            if (DEBUG) {
                new StringBuilder("  Re-using existing loader ").append(aVar2);
            }
            aVar2.rQ = aVar;
        }
        if (aVar2.rS && this.oX) {
            aVar2.c(aVar2.rR, aVar2.mData);
        }
        return aVar2.rR;
    }

    public final <D> c<D> b(int i, android.support.v4.app.t.a<D> aVar) {
        if (this.rO) {
            throw new IllegalStateException("Called while creating a loader");
        }
        a aVar2 = (a) this.rM.get(i);
        if (DEBUG) {
            new StringBuilder("restartLoader in ").append(this).append(": args=").append(null);
        }
        if (aVar2 != null) {
            a aVar3 = (a) this.rN.get(i);
            if (aVar3 != null) {
                if (aVar2.rS) {
                    if (DEBUG) {
                        new StringBuilder("  Removing last inactive loader: ").append(aVar2);
                    }
                    aVar3.rT = false;
                    aVar3.destroy();
                } else if (aVar2.oX) {
                    if (DEBUG) {
                        new StringBuilder("  Canceling: ").append(aVar2);
                    }
                    if (aVar2.oX && aVar2.rR != null && aVar2.rW) {
                        if (DEBUG) {
                            new StringBuilder("onLoadCanceled: ").append(aVar2);
                        }
                        if (!aVar2.qP && aVar2.rY.rM.get(aVar2.mId) == aVar2) {
                            aVar3 = aVar2.rX;
                            if (aVar3 != null) {
                                if (DEBUG) {
                                    new StringBuilder("  Switching to pending loader: ").append(aVar3);
                                }
                                aVar2.rX = null;
                                aVar2.rY.rM.put(aVar2.mId, null);
                                aVar2.destroy();
                                aVar2.rY.a(aVar3);
                            }
                        }
                    }
                    if (aVar2.rX != null) {
                        if (DEBUG) {
                            new StringBuilder("  Removing pending loader: ").append(aVar2.rX);
                        }
                        aVar2.rX.destroy();
                        aVar2.rX = null;
                    }
                    aVar2.rX = a(i, null, aVar);
                    return aVar2.rX.rR;
                } else {
                    this.rM.put(i, null);
                    aVar2.destroy();
                }
            } else if (DEBUG) {
                new StringBuilder("  Making last loader inactive: ").append(aVar2);
            }
            aVar2.rR.tO = true;
            this.rN.put(i, aVar2);
        }
        return b(i, null, aVar).rR;
    }

    public final void destroyLoader(int i) {
        if (this.rO) {
            throw new IllegalStateException("Called while creating a loader");
        }
        if (DEBUG) {
            new StringBuilder("destroyLoader in ").append(this).append(" of ").append(i);
        }
        int indexOfKey = this.rM.indexOfKey(i);
        if (indexOfKey >= 0) {
            a aVar = (a) this.rM.valueAt(indexOfKey);
            this.rM.removeAt(indexOfKey);
            aVar.destroy();
        }
        indexOfKey = this.rN.indexOfKey(i);
        if (indexOfKey >= 0) {
            aVar = (a) this.rN.valueAt(indexOfKey);
            this.rN.removeAt(indexOfKey);
            aVar.destroy();
        }
        if (this.mHost != null && !bk()) {
            this.mHost.mFragmentManager.bf();
        }
    }

    public final <D> c<D> T(int i) {
        if (this.rO) {
            throw new IllegalStateException("Called while creating a loader");
        }
        a aVar = (a) this.rM.get(i);
        if (aVar == null) {
            return null;
        }
        if (aVar.rX != null) {
            return aVar.rX.rR;
        }
        return aVar.rR;
    }

    final void bl() {
        if (DEBUG) {
            new StringBuilder("Starting in ").append(this);
        }
        if (this.oX) {
            new RuntimeException("here").fillInStackTrace();
            new StringBuilder("Called doStart when already started: ").append(this);
            return;
        }
        this.oX = true;
        for (int size = this.rM.size() - 1; size >= 0; size--) {
            ((a) this.rM.valueAt(size)).start();
        }
    }

    final void bm() {
        if (DEBUG) {
            new StringBuilder("Stopping in ").append(this);
        }
        if (this.oX) {
            for (int size = this.rM.size() - 1; size >= 0; size--) {
                ((a) this.rM.valueAt(size)).stop();
            }
            this.oX = false;
            return;
        }
        new RuntimeException("here").fillInStackTrace();
        new StringBuilder("Called doStop when not started: ").append(this);
    }

    final void bn() {
        if (DEBUG) {
            new StringBuilder("Retaining in ").append(this);
        }
        if (this.oX) {
            this.mRetaining = true;
            this.oX = false;
            for (int size = this.rM.size() - 1; size >= 0; size--) {
                a aVar = (a) this.rM.valueAt(size);
                if (DEBUG) {
                    new StringBuilder("  Retaining: ").append(aVar);
                }
                aVar.mRetaining = true;
                aVar.rU = aVar.oX;
                aVar.oX = false;
                aVar.rQ = null;
            }
            return;
        }
        new RuntimeException("here").fillInStackTrace();
        new StringBuilder("Called doRetain when not started: ").append(this);
    }

    final void bo() {
        for (int size = this.rM.size() - 1; size >= 0; size--) {
            ((a) this.rM.valueAt(size)).rV = true;
        }
    }

    final void bp() {
        for (int size = this.rM.size() - 1; size >= 0; size--) {
            a aVar = (a) this.rM.valueAt(size);
            if (aVar.oX && aVar.rV) {
                aVar.rV = false;
                if (aVar.rS) {
                    aVar.c(aVar.rR, aVar.mData);
                }
            }
        }
    }

    final void bq() {
        int size;
        if (!this.mRetaining) {
            if (DEBUG) {
                new StringBuilder("Destroying Active in ").append(this);
            }
            for (size = this.rM.size() - 1; size >= 0; size--) {
                ((a) this.rM.valueAt(size)).destroy();
            }
            this.rM.clear();
        }
        if (DEBUG) {
            new StringBuilder("Destroying Inactive in ").append(this);
        }
        for (size = this.rN.size() - 1; size >= 0; size--) {
            ((a) this.rN.valueAt(size)).destroy();
        }
        this.rN.clear();
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder(128);
        stringBuilder.append("LoaderManager{");
        stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
        stringBuilder.append(" in ");
        android.support.v4.e.c.a(this.mHost, stringBuilder);
        stringBuilder.append("}}");
        return stringBuilder.toString();
    }

    public final void dump(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        int i = 0;
        if (this.rM.size() > 0) {
            printWriter.print(str);
            printWriter.println("Active Loaders:");
            String str2 = str + "    ";
            for (int i2 = 0; i2 < this.rM.size(); i2++) {
                a aVar = (a) this.rM.valueAt(i2);
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(this.rM.keyAt(i2));
                printWriter.print(": ");
                printWriter.println(aVar.toString());
                aVar.dump(str2, fileDescriptor, printWriter, strArr);
            }
        }
        if (this.rN.size() > 0) {
            printWriter.print(str);
            printWriter.println("Inactive Loaders:");
            String str3 = str + "    ";
            while (i < this.rN.size()) {
                aVar = (a) this.rN.valueAt(i);
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(this.rN.keyAt(i));
                printWriter.print(": ");
                printWriter.println(aVar.toString());
                aVar.dump(str3, fileDescriptor, printWriter, strArr);
                i++;
            }
        }
    }

    public final boolean bk() {
        int size = this.rM.size();
        boolean z = false;
        for (int i = 0; i < size; i++) {
            int i2;
            a aVar = (a) this.rM.valueAt(i);
            if (!aVar.oX || aVar.rT) {
                i2 = 0;
            } else {
                i2 = 1;
            }
            z |= i2;
        }
        return z;
    }
}
