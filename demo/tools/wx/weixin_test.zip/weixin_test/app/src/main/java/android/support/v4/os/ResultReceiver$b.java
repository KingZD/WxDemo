package android.support.v4.os;

import android.os.Bundle;

class ResultReceiver$b implements Runnable {
    final /* synthetic */ ResultReceiver vQ;
    final int vR;
    final Bundle vS;

    public ResultReceiver$b(ResultReceiver resultReceiver, int i, Bundle bundle) {
        this.vQ = resultReceiver;
        this.vR = i;
        this.vS = bundle;
    }

    public final void run() {
        this.vQ.onReceiveResult(this.vR, this.vS);
    }
}
