package android.support.design.widget;

import android.view.View;
import android.view.View.OnClickListener;

class c$1 implements OnClickListener {
    final /* synthetic */ c fN;

    c$1(c cVar) {
        this.fN = cVar;
    }

    public final void onClick(View view) {
        if (this.fN.isShowing()) {
            this.fN.cancel();
        }
    }
}
