package android.support.design.internal;

import android.content.Context;
import android.support.v7.view.menu.h;
import android.support.v7.view.menu.p;

public final class c extends p {
    public c(Context context, a aVar, h hVar) {
        super(context, aVar, hVar);
    }

    public final void p(boolean z) {
        super.p(z);
        this.Mu.p(z);
    }
}
