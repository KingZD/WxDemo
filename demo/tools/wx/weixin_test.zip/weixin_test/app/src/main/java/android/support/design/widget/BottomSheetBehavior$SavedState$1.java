package android.support.design.widget;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.design.widget.BottomSheetBehavior.SavedState;

class BottomSheetBehavior$SavedState$1 implements Creator<SavedState> {
    BottomSheetBehavior$SavedState$1() {
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        return new SavedState(parcel);
    }

    public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
        return new SavedState[i];
    }
}
