package android.support.v4.view;

import android.view.View;

public interface t {
    ap a(View view, ap apVar);
}
