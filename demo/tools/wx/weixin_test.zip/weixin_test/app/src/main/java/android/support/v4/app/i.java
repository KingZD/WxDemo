package android.support.v4.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnDismissListener;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;

public class i extends Fragment implements OnCancelListener, OnDismissListener {
    int qf = 0;
    int qg = 0;
    boolean qh = true;
    public boolean qi = true;
    int qj = -1;
    Dialog qk;
    boolean ql;
    boolean qm;
    boolean qn;

    public void a(m mVar, String str) {
        this.qm = false;
        this.qn = true;
        q bd = mVar.bd();
        bd.a((Fragment) this, str);
        bd.commit();
    }

    public void onAttach(Activity activity) {
        super.onAttach(activity);
        if (!this.qn) {
            this.qm = false;
        }
    }

    public void onDetach() {
        super.onDetach();
        if (!this.qn && !this.qm) {
            this.qm = true;
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.qi = this.mContainerId == 0;
        if (bundle != null) {
            this.qf = bundle.getInt("android:style", 0);
            this.qg = bundle.getInt("android:theme", 0);
            this.qh = bundle.getBoolean("android:cancelable", true);
            this.qi = bundle.getBoolean("android:showsDialog", this.qi);
            this.qj = bundle.getInt("android:backStackId", -1);
        }
    }

    public LayoutInflater getLayoutInflater(Bundle bundle) {
        if (!this.qi) {
            return super.getLayoutInflater(bundle);
        }
        this.qk = aZ();
        if (this.qk == null) {
            return (LayoutInflater) this.mHost.mContext.getSystemService("layout_inflater");
        }
        Dialog dialog = this.qk;
        switch (this.qf) {
            case 1:
            case 2:
                break;
            case 3:
                dialog.getWindow().addFlags(24);
                break;
        }
        dialog.requestWindowFeature(1);
        return (LayoutInflater) this.qk.getContext().getSystemService("layout_inflater");
    }

    public Dialog aZ() {
        return new Dialog(getActivity(), this.qg);
    }

    public void onCancel(DialogInterface dialogInterface) {
    }

    public void onDismiss(DialogInterface dialogInterface) {
        if (!this.ql && !this.qm) {
            this.qm = true;
            this.qn = false;
            if (this.qk != null) {
                this.qk.dismiss();
                this.qk = null;
            }
            this.ql = true;
            if (this.qj >= 0) {
                getFragmentManager().P(this.qj);
                this.qj = -1;
                return;
            }
            q bd = getFragmentManager().bd();
            bd.a(this);
            bd.commitAllowingStateLoss();
        }
    }

    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        if (this.qi) {
            View view = getView();
            if (view != null) {
                if (view.getParent() != null) {
                    throw new IllegalStateException("DialogFragment can not be attached to a container view");
                }
                this.qk.setContentView(view);
            }
            this.qk.setOwnerActivity(getActivity());
            this.qk.setCancelable(this.qh);
            this.qk.setOnCancelListener(this);
            this.qk.setOnDismissListener(this);
            if (bundle != null) {
                Bundle bundle2 = bundle.getBundle("android:savedDialogState");
                if (bundle2 != null) {
                    this.qk.onRestoreInstanceState(bundle2);
                }
            }
        }
    }

    public void onStart() {
        super.onStart();
        if (this.qk != null) {
            this.ql = false;
            this.qk.show();
        }
    }

    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        if (this.qk != null) {
            Bundle onSaveInstanceState = this.qk.onSaveInstanceState();
            if (onSaveInstanceState != null) {
                bundle.putBundle("android:savedDialogState", onSaveInstanceState);
            }
        }
        if (this.qf != 0) {
            bundle.putInt("android:style", this.qf);
        }
        if (this.qg != 0) {
            bundle.putInt("android:theme", this.qg);
        }
        if (!this.qh) {
            bundle.putBoolean("android:cancelable", this.qh);
        }
        if (!this.qi) {
            bundle.putBoolean("android:showsDialog", this.qi);
        }
        if (this.qj != -1) {
            bundle.putInt("android:backStackId", this.qj);
        }
    }

    public void onStop() {
        super.onStop();
        if (this.qk != null) {
            this.qk.hide();
        }
    }

    public void onDestroyView() {
        super.onDestroyView();
        if (this.qk != null) {
            this.ql = true;
            this.qk.dismiss();
            this.qk = null;
        }
    }
}
