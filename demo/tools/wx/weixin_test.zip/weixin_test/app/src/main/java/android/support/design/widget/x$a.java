package android.support.design.widget;

import android.graphics.Rect;
import android.view.View;
import android.view.ViewGroup;

interface x$a {
    void b(ViewGroup viewGroup, View view, Rect rect);
}
