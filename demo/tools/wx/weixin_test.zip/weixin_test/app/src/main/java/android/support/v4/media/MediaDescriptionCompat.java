package android.support.v4.media;

import android.graphics.Bitmap;
import android.media.MediaDescription;
import android.media.MediaDescription.Builder;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.text.TextUtils;

public final class MediaDescriptionCompat implements Parcelable {
    public static final Creator<MediaDescriptionCompat> CREATOR = new Creator<MediaDescriptionCompat>() {
        public final /* synthetic */ Object createFromParcel(Parcel parcel) {
            return VERSION.SDK_INT < 21 ? new MediaDescriptionCompat(parcel) : MediaDescriptionCompat.g(MediaDescription.CREATOR.createFromParcel(parcel));
        }

        public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
            return new MediaDescriptionCompat[i];
        }
    };
    private final Bundle mExtras;
    private final String ve;
    private final CharSequence vf;
    private final CharSequence vg;
    private final CharSequence vh;
    private final Bitmap vi;
    private final Uri vj;
    private final Uri vk;
    private Object vl;

    public static final class a {
        Bundle mExtras;
        String ve;
        CharSequence vf;
        CharSequence vg;
        CharSequence vh;
        Bitmap vi;
        Uri vj;
        Uri vk;
    }

    private MediaDescriptionCompat(String str, CharSequence charSequence, CharSequence charSequence2, CharSequence charSequence3, Bitmap bitmap, Uri uri, Bundle bundle, Uri uri2) {
        this.ve = str;
        this.vf = charSequence;
        this.vg = charSequence2;
        this.vh = charSequence3;
        this.vi = bitmap;
        this.vj = uri;
        this.mExtras = bundle;
        this.vk = uri2;
    }

    private MediaDescriptionCompat(Parcel parcel) {
        this.ve = parcel.readString();
        this.vf = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.vg = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.vh = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.vi = (Bitmap) parcel.readParcelable(null);
        this.vj = (Uri) parcel.readParcelable(null);
        this.mExtras = parcel.readBundle();
        this.vk = (Uri) parcel.readParcelable(null);
    }

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        if (VERSION.SDK_INT < 21) {
            parcel.writeString(this.ve);
            TextUtils.writeToParcel(this.vf, parcel, i);
            TextUtils.writeToParcel(this.vg, parcel, i);
            TextUtils.writeToParcel(this.vh, parcel, i);
            parcel.writeParcelable(this.vi, i);
            parcel.writeParcelable(this.vj, i);
            parcel.writeBundle(this.mExtras);
            parcel.writeParcelable(this.vk, i);
            return;
        }
        Object obj;
        if (this.vl != null || VERSION.SDK_INT < 21) {
            obj = this.vl;
        } else {
            Bundle bundle;
            Builder builder = new Builder();
            builder.setMediaId(this.ve);
            builder.setTitle(this.vf);
            builder.setSubtitle(this.vg);
            builder.setDescription(this.vh);
            builder.setIconBitmap(this.vi);
            builder.setIconUri(this.vj);
            Bundle bundle2 = this.mExtras;
            if (VERSION.SDK_INT >= 23 || this.vk == null) {
                bundle = bundle2;
            } else {
                if (bundle2 == null) {
                    bundle2 = new Bundle();
                    bundle2.putBoolean("android.support.v4.media.description.NULL_BUNDLE_FLAG", true);
                }
                bundle2.putParcelable("android.support.v4.media.description.MEDIA_URI", this.vk);
                bundle = bundle2;
            }
            builder.setExtras(bundle);
            if (VERSION.SDK_INT >= 23) {
                builder.setMediaUri(this.vk);
            }
            this.vl = builder.build();
            obj = this.vl;
        }
        ((MediaDescription) obj).writeToParcel(parcel, i);
    }

    public final String toString() {
        return this.vf + ", " + this.vg + ", " + this.vh;
    }

    public static MediaDescriptionCompat g(Object obj) {
        if (obj == null || VERSION.SDK_INT < 21) {
            return null;
        }
        Uri uri;
        Bundle bundle;
        MediaDescriptionCompat mediaDescriptionCompat;
        a aVar = new a();
        aVar.ve = ((MediaDescription) obj).getMediaId();
        aVar.vf = ((MediaDescription) obj).getTitle();
        aVar.vg = ((MediaDescription) obj).getSubtitle();
        aVar.vh = ((MediaDescription) obj).getDescription();
        aVar.vi = ((MediaDescription) obj).getIconBitmap();
        aVar.vj = ((MediaDescription) obj).getIconUri();
        Bundle extras = ((MediaDescription) obj).getExtras();
        if (extras == null) {
            uri = null;
        } else {
            uri = (Uri) extras.getParcelable("android.support.v4.media.description.MEDIA_URI");
        }
        if (uri != null) {
            if (extras.containsKey("android.support.v4.media.description.NULL_BUNDLE_FLAG") && extras.size() == 2) {
                bundle = null;
                aVar.mExtras = bundle;
                if (uri != null) {
                    aVar.vk = uri;
                } else if (VERSION.SDK_INT >= 23) {
                    aVar.vk = ((MediaDescription) obj).getMediaUri();
                }
                mediaDescriptionCompat = new MediaDescriptionCompat(aVar.ve, aVar.vf, aVar.vg, aVar.vh, aVar.vi, aVar.vj, aVar.mExtras, aVar.vk);
                mediaDescriptionCompat.vl = obj;
                return mediaDescriptionCompat;
            }
            extras.remove("android.support.v4.media.description.MEDIA_URI");
            extras.remove("android.support.v4.media.description.NULL_BUNDLE_FLAG");
        }
        bundle = extras;
        aVar.mExtras = bundle;
        if (uri != null) {
            aVar.vk = uri;
        } else if (VERSION.SDK_INT >= 23) {
            aVar.vk = ((MediaDescription) obj).getMediaUri();
        }
        mediaDescriptionCompat = new MediaDescriptionCompat(aVar.ve, aVar.vf, aVar.vg, aVar.vh, aVar.vi, aVar.vj, aVar.mExtras, aVar.vk);
        mediaDescriptionCompat.vl = obj;
        return mediaDescriptionCompat;
    }
}
