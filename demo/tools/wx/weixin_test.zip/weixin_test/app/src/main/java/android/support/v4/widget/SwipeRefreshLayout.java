package android.support.v4.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Build.VERSION;
import android.support.v4.view.o;
import android.support.v4.view.p;
import android.support.v4.view.q;
import android.support.v4.view.r;
import android.support.v4.view.s;
import android.support.v4.view.z;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Transformation;
import android.widget.AbsListView;

public class SwipeRefreshLayout extends ViewGroup implements p, r {
    private static final String Ep = SwipeRefreshLayout.class.getSimpleName();
    private static final int[] yK = new int[]{16842766};
    private boolean EA = false;
    private float EB;
    private boolean EC;
    private boolean ED;
    private final DecelerateInterpolator EE;
    private b EF;
    private int EG = -1;
    protected int EH;
    private float EI;
    protected int EJ;
    private l EK;
    private Animation EL;
    private Animation EM;
    private Animation EN;
    private Animation EO;
    private float EP;
    private boolean EQ;
    private int ER;
    private int ES;
    private boolean ET;
    private AnimationListener EU = new SwipeRefreshLayout$1(this);
    private final Animation EV = new SwipeRefreshLayout$5(this);
    private final Animation EW = new SwipeRefreshLayout$6(this);
    private SwipeRefreshLayout$a Eq;
    private boolean Er = false;
    private float Es = -1.0f;
    private float Et;
    private final q Eu;
    private final int[] Ev = new int[2];
    private final int[] Ew = new int[2];
    private boolean Ex;
    private int Ey;
    private int Ez;
    private int fG = -1;
    private final s hM;
    private boolean iW;
    private int iY;
    private View oV;
    private float yb;

    private void reset() {
        this.EF.clearAnimation();
        this.EK.stop();
        this.EF.setVisibility(8);
        av(255);
        if (this.EC) {
            G(0.0f);
        } else {
            l(this.EJ - this.Ez, true);
        }
        this.Ez = this.EF.getTop();
    }

    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        reset();
    }

    private void av(int i) {
        this.EF.getBackground().setAlpha(i);
        this.EK.setAlpha(i);
    }

    public SwipeRefreshLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.iY = ViewConfiguration.get(context).getScaledTouchSlop();
        this.Ey = getResources().getInteger(17694721);
        setWillNotDraw(false);
        this.EE = new DecelerateInterpolator(2.0f);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, yK);
        setEnabled(obtainStyledAttributes.getBoolean(0, true));
        obtainStyledAttributes.recycle();
        DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
        this.ER = (int) (displayMetrics.density * 40.0f);
        this.ES = (int) (displayMetrics.density * 40.0f);
        this.EF = new b(getContext());
        this.EK = new l(getContext(), this);
        this.EK.CP.Dp = -328966;
        this.EF.setImageDrawable(this.EK);
        this.EF.setVisibility(8);
        addView(this.EF);
        z.c(this);
        this.EP = displayMetrics.density * 64.0f;
        this.Es = this.EP;
        this.hM = new s(this);
        this.Eu = new q(this);
        setNestedScrollingEnabled(true);
    }

    protected int getChildDrawingOrder(int i, int i2) {
        if (this.EG < 0) {
            return i2;
        }
        if (i2 == i - 1) {
            return this.EG;
        }
        if (i2 >= this.EG) {
            return i2 + 1;
        }
        return i2;
    }

    private static boolean cT() {
        return VERSION.SDK_INT < 11;
    }

    private void G(float f) {
        if (cT()) {
            av((int) (255.0f * f));
            return;
        }
        z.e(this.EF, f);
        z.f(this.EF, f);
    }

    private void a(AnimationListener animationListener) {
        this.EL = new SwipeRefreshLayout$2(this);
        this.EL.setDuration(150);
        this.EF.Bu = animationListener;
        this.EF.clearAnimation();
        this.EF.startAnimation(this.EL);
    }

    private Animation u(final int i, final int i2) {
        if (this.EC && cT()) {
            return null;
        }
        Animation anonymousClass3 = new Animation(this) {
            final /* synthetic */ SwipeRefreshLayout EX;

            public final void applyTransformation(float f, Transformation transformation) {
                this.EX.EK.setAlpha((int) (((float) i) + (((float) (i2 - i)) * f)));
            }
        };
        anonymousClass3.setDuration(300);
        this.EF.Bu = null;
        this.EF.clearAnimation();
        this.EF.startAnimation(anonymousClass3);
        return anonymousClass3;
    }

    private void cU() {
        if (this.oV == null) {
            int i = 0;
            while (i < getChildCount()) {
                View childAt = getChildAt(i);
                if (childAt.equals(this.EF)) {
                    i++;
                } else {
                    this.oV = childAt;
                    return;
                }
            }
        }
    }

    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int measuredWidth = getMeasuredWidth();
        int measuredHeight = getMeasuredHeight();
        if (getChildCount() != 0) {
            if (this.oV == null) {
                cU();
            }
            if (this.oV != null) {
                View view = this.oV;
                int paddingLeft = getPaddingLeft();
                int paddingTop = getPaddingTop();
                view.layout(paddingLeft, paddingTop, ((measuredWidth - getPaddingLeft()) - getPaddingRight()) + paddingLeft, ((measuredHeight - getPaddingTop()) - getPaddingBottom()) + paddingTop);
                measuredHeight = this.EF.getMeasuredWidth();
                this.EF.layout((measuredWidth / 2) - (measuredHeight / 2), this.Ez, (measuredWidth / 2) + (measuredHeight / 2), this.Ez + this.EF.getMeasuredHeight());
            }
        }
    }

    public void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        if (this.oV == null) {
            cU();
        }
        if (this.oV != null) {
            int i3;
            this.oV.measure(MeasureSpec.makeMeasureSpec((getMeasuredWidth() - getPaddingLeft()) - getPaddingRight(), 1073741824), MeasureSpec.makeMeasureSpec((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom(), 1073741824));
            this.EF.measure(MeasureSpec.makeMeasureSpec(this.ER, 1073741824), MeasureSpec.makeMeasureSpec(this.ES, 1073741824));
            if (!(this.ET || this.EA)) {
                this.EA = true;
                i3 = -this.EF.getMeasuredHeight();
                this.EJ = i3;
                this.Ez = i3;
            }
            this.EG = -1;
            for (i3 = 0; i3 < getChildCount(); i3++) {
                if (getChildAt(i3) == this.EF) {
                    this.EG = i3;
                    return;
                }
            }
        }
    }

    private boolean cV() {
        if (VERSION.SDK_INT >= 14) {
            return z.h(this.oV, -1);
        }
        if (!(this.oV instanceof AbsListView)) {
            return z.h(this.oV, -1) || this.oV.getScrollY() > 0;
        } else {
            AbsListView absListView = (AbsListView) this.oV;
            return absListView.getChildCount() > 0 && (absListView.getFirstVisiblePosition() > 0 || absListView.getChildAt(0).getTop() < absListView.getPaddingTop());
        }
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        cU();
        int d = o.d(motionEvent);
        if (this.ED && d == 0) {
            this.ED = false;
        }
        if (!isEnabled() || this.ED || cV() || this.Er || this.Ex) {
            return false;
        }
        float g;
        switch (d) {
            case 0:
                l(this.EJ - this.EF.getTop(), true);
                this.fG = o.c(motionEvent, 0);
                this.iW = false;
                g = g(motionEvent, this.fG);
                if (g != -1.0f) {
                    this.EB = g;
                    break;
                }
                return false;
            case 1:
            case 3:
                this.iW = false;
                this.fG = -1;
                break;
            case 2:
                if (this.fG == -1) {
                    return false;
                }
                g = g(motionEvent, this.fG);
                if (g != -1.0f) {
                    if (g - this.EB > ((float) this.iY) && !this.iW) {
                        this.yb = this.EB + ((float) this.iY);
                        this.iW = true;
                        this.EK.setAlpha(76);
                        break;
                    }
                }
                return false;
            case 6:
                h(motionEvent);
                break;
        }
        return this.iW;
    }

    private static float g(MotionEvent motionEvent, int i) {
        int b = o.b(motionEvent, i);
        if (b < 0) {
            return -1.0f;
        }
        return o.e(motionEvent, b);
    }

    public void requestDisallowInterceptTouchEvent(boolean z) {
        if (VERSION.SDK_INT < 21 && (this.oV instanceof AbsListView)) {
            return;
        }
        if (this.oV == null || z.ag(this.oV)) {
            super.requestDisallowInterceptTouchEvent(z);
        }
    }

    public boolean onStartNestedScroll(View view, View view2, int i) {
        return (!isEnabled() || this.ED || this.Er || (i & 2) == 0) ? false : true;
    }

    public void onNestedScrollAccepted(View view, View view2, int i) {
        this.hM.xL = i;
        startNestedScroll(i & 2);
        this.Et = 0.0f;
        this.Ex = true;
    }

    public void onNestedPreScroll(View view, int i, int i2, int[] iArr) {
        if (i2 > 0 && this.Et > 0.0f) {
            if (((float) i2) > this.Et) {
                iArr[1] = i2 - ((int) this.Et);
                this.Et = 0.0f;
            } else {
                this.Et -= (float) i2;
                iArr[1] = i2;
            }
            H(this.Et);
        }
        if (this.ET && i2 > 0 && this.Et == 0.0f && Math.abs(i2 - iArr[1]) > 0) {
            this.EF.setVisibility(8);
        }
        int[] iArr2 = this.Ev;
        if (dispatchNestedPreScroll(i - iArr[0], i2 - iArr[1], iArr2, null)) {
            iArr[0] = iArr[0] + iArr2[0];
            iArr[1] = iArr2[1] + iArr[1];
        }
    }

    public int getNestedScrollAxes() {
        return this.hM.xL;
    }

    public void onStopNestedScroll(View view) {
        this.hM.xL = 0;
        this.Ex = false;
        if (this.Et > 0.0f) {
            I(this.Et);
            this.Et = 0.0f;
        }
        stopNestedScroll();
    }

    public void onNestedScroll(View view, int i, int i2, int i3, int i4) {
        dispatchNestedScroll(i, i2, i3, i4, this.Ew);
        int i5 = this.Ew[1] + i4;
        if (i5 < 0 && !cV()) {
            this.Et = ((float) Math.abs(i5)) + this.Et;
            H(this.Et);
        }
    }

    public void setNestedScrollingEnabled(boolean z) {
        this.Eu.setNestedScrollingEnabled(z);
    }

    public boolean isNestedScrollingEnabled() {
        return this.Eu.xI;
    }

    public boolean startNestedScroll(int i) {
        return this.Eu.startNestedScroll(i);
    }

    public void stopNestedScroll() {
        this.Eu.stopNestedScroll();
    }

    public boolean hasNestedScrollingParent() {
        return this.Eu.hasNestedScrollingParent();
    }

    public boolean dispatchNestedScroll(int i, int i2, int i3, int i4, int[] iArr) {
        return this.Eu.dispatchNestedScroll(i, i2, i3, i4, iArr);
    }

    public boolean dispatchNestedPreScroll(int i, int i2, int[] iArr, int[] iArr2) {
        return this.Eu.dispatchNestedPreScroll(i, i2, iArr, iArr2);
    }

    public boolean onNestedPreFling(View view, float f, float f2) {
        return dispatchNestedPreFling(f, f2);
    }

    public boolean onNestedFling(View view, float f, float f2, boolean z) {
        return dispatchNestedFling(f, f2, z);
    }

    public boolean dispatchNestedFling(float f, float f2, boolean z) {
        return this.Eu.dispatchNestedFling(f, f2, z);
    }

    public boolean dispatchNestedPreFling(float f, float f2) {
        return this.Eu.dispatchNestedPreFling(f, f2);
    }

    private static boolean f(Animation animation) {
        return (animation == null || !animation.hasStarted() || animation.hasEnded()) ? false : true;
    }

    private void H(float f) {
        this.EK.B(true);
        float min = Math.min(1.0f, Math.abs(f / this.Es));
        float max = (((float) Math.max(((double) min) - 0.4d, 0.0d)) * 5.0f) / 3.0f;
        float abs = Math.abs(f) - this.Es;
        float f2 = this.ET ? this.EP - ((float) this.EJ) : this.EP;
        abs = Math.max(0.0f, Math.min(abs, f2 * 2.0f) / f2);
        abs = ((float) (((double) (abs / 4.0f)) - Math.pow((double) (abs / 4.0f), 2.0d))) * 2.0f;
        int i = ((int) ((f2 * min) + ((f2 * abs) * 2.0f))) + this.EJ;
        if (this.EF.getVisibility() != 0) {
            this.EF.setVisibility(0);
        }
        if (!this.EC) {
            z.e(this.EF, 1.0f);
            z.f(this.EF, 1.0f);
        }
        if (this.EC) {
            G(Math.min(1.0f, f / this.Es));
        }
        if (f < this.Es) {
            if (this.EK.getAlpha() > 76 && !f(this.EM)) {
                this.EM = u(this.EK.getAlpha(), 76);
            }
        } else if (this.EK.getAlpha() < 255 && !f(this.EN)) {
            this.EN = u(this.EK.getAlpha(), 255);
        }
        this.EK.B(Math.min(0.8f, max * 0.8f));
        this.EK.A(Math.min(1.0f, max));
        this.EK.CP.setRotation(((-0.25f + (max * 0.4f)) + (abs * 2.0f)) * 0.5f);
        l(i - this.Ez, true);
    }

    private void I(float f) {
        if (f <= this.Es) {
            this.Er = false;
            this.EK.B(0.0f);
            AnimationListener animationListener = null;
            if (!this.EC) {
                animationListener = new SwipeRefreshLayout$4(this);
            }
            int i = this.Ez;
            if (this.EC) {
                this.EH = i;
                if (cT()) {
                    this.EI = (float) this.EK.getAlpha();
                } else {
                    this.EI = z.V(this.EF);
                }
                this.EO = new SwipeRefreshLayout$7(this);
                this.EO.setDuration(150);
                if (animationListener != null) {
                    this.EF.Bu = animationListener;
                }
                this.EF.clearAnimation();
                this.EF.startAnimation(this.EO);
            } else {
                this.EH = i;
                this.EW.reset();
                this.EW.setDuration(200);
                this.EW.setInterpolator(this.EE);
                if (animationListener != null) {
                    this.EF.Bu = animationListener;
                }
                this.EF.clearAnimation();
                this.EF.startAnimation(this.EW);
            }
            this.EK.B(false);
        } else if (!this.Er) {
            this.EQ = true;
            cU();
            this.Er = true;
            if (this.Er) {
                int i2 = this.Ez;
                AnimationListener animationListener2 = this.EU;
                this.EH = i2;
                this.EV.reset();
                this.EV.setDuration(200);
                this.EV.setInterpolator(this.EE);
                if (animationListener2 != null) {
                    this.EF.Bu = animationListener2;
                }
                this.EF.clearAnimation();
                this.EF.startAnimation(this.EV);
                return;
            }
            a(this.EU);
        }
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        int d = o.d(motionEvent);
        if (this.ED && d == 0) {
            this.ED = false;
        }
        if (!isEnabled() || this.ED || cV() || this.Ex) {
            return false;
        }
        float e;
        switch (d) {
            case 0:
                this.fG = o.c(motionEvent, 0);
                this.iW = false;
                break;
            case 1:
                d = o.b(motionEvent, this.fG);
                if (d < 0) {
                    return false;
                }
                e = (o.e(motionEvent, d) - this.yb) * 0.5f;
                this.iW = false;
                I(e);
                this.fG = -1;
                return false;
            case 2:
                d = o.b(motionEvent, this.fG);
                if (d < 0) {
                    return false;
                }
                e = (o.e(motionEvent, d) - this.yb) * 0.5f;
                if (this.iW) {
                    if (e > 0.0f) {
                        H(e);
                        break;
                    }
                    return false;
                }
                break;
            case 3:
                return false;
            case 5:
                d = o.e(motionEvent);
                if (d >= 0) {
                    this.fG = o.c(motionEvent, d);
                    break;
                }
                return false;
            case 6:
                h(motionEvent);
                break;
        }
        return true;
    }

    private void l(int i, boolean z) {
        this.EF.bringToFront();
        this.EF.offsetTopAndBottom(i);
        this.Ez = this.EF.getTop();
        if (z && VERSION.SDK_INT < 11) {
            invalidate();
        }
    }

    private void h(MotionEvent motionEvent) {
        int e = o.e(motionEvent);
        if (o.c(motionEvent, e) == this.fG) {
            this.fG = o.c(motionEvent, e == 0 ? 1 : 0);
        }
    }
}
