package android.support.v4.app;

import android.app.Notification.Action;
import android.app.Notification.Builder;
import android.app.RemoteInput;
import android.support.v4.app.ac.a;

final class aa {
    public static void a(Builder builder, a aVar) {
        Action.Builder builder2 = new Action.Builder(aVar.getIcon(), aVar.getTitle(), aVar.bt());
        if (aVar.bu() != null) {
            for (RemoteInput addRemoteInput : ai.a(aVar.bu())) {
                builder2.addRemoteInput(addRemoteInput);
            }
        }
        if (aVar.getExtras() != null) {
            builder2.addExtras(aVar.getExtras());
        }
        builder.addAction(builder2.build());
    }
}
