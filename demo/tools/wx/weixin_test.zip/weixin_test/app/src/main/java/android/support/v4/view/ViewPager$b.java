package android.support.v4.view;

class ViewPager$b {
    Object object;
    int position;
    boolean zJ;
    float zK;
    float zL;

    ViewPager$b() {
    }
}
