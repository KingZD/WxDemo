package android.support.design.widget;

import android.support.v4.view.z;
import android.view.View;

class BottomSheetBehavior$b implements Runnable {
    final /* synthetic */ BottomSheetBehavior fK;
    private final int fL;
    private final View mView;

    public BottomSheetBehavior$b(BottomSheetBehavior bottomSheetBehavior, View view, int i) {
        this.fK = bottomSheetBehavior;
        this.mView = view;
        this.fL = i;
    }

    public final void run() {
        if (BottomSheetBehavior.j(this.fK) == null || !BottomSheetBehavior.j(this.fK).cW()) {
            BottomSheetBehavior.b(this.fK, this.fL);
        } else {
            z.a(this.mView, (Runnable) this);
        }
    }
}
