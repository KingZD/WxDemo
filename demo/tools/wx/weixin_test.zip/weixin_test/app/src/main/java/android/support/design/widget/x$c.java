package android.support.design.widget;

import android.graphics.Rect;
import android.view.View;
import android.view.ViewGroup;

class x$c implements x$a {
    private x$c() {
    }

    public final void b(ViewGroup viewGroup, View view, Rect rect) {
        y.b(viewGroup, view, rect);
    }
}
