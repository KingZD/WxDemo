package android.support.design.widget;

class TabLayout$a$1 implements u$c {
    final /* synthetic */ int kO;
    final /* synthetic */ int kP;
    final /* synthetic */ int kQ;
    final /* synthetic */ int kR;
    final /* synthetic */ TabLayout$a kS;

    TabLayout$a$1(TabLayout$a tabLayout$a, int i, int i2, int i3, int i4) {
        this.kS = tabLayout$a;
        this.kO = i;
        this.kP = i2;
        this.kQ = i3;
        this.kR = i4;
    }

    public final void a(u uVar) {
        float animatedFraction = uVar.lD.getAnimatedFraction();
        TabLayout$a.a(this.kS, a.a(this.kO, this.kP, animatedFraction), a.a(this.kQ, this.kR, animatedFraction));
    }
}
