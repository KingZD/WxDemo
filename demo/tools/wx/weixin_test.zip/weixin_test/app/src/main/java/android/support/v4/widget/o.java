package android.support.v4.widget;

import java.lang.reflect.Method;

final class o {
    static Method DL;
    static boolean DM;
}
