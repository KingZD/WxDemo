package android.support.design.widget;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.support.design.a$d;
import android.support.design.a$i;
import android.support.design.a.h;
import android.support.design.widget.CoordinatorLayout.b;
import android.support.v7.widget.i;
import android.util.AttributeSet;
import android.view.View.MeasureSpec;

@b(FloatingActionButton$a.class)
public class FloatingActionButton extends VisibilityAwareImageButton {
    private ColorStateList if;
    private Mode ig;
    private int ih;
    private int ii;
    private int ij;
    private int ik;
    private boolean il;
    private final Rect im;
    private i in;
    private l io;

    public /* bridge */ /* synthetic */ void setVisibility(int i) {
        super.setVisibility(i);
    }

    public FloatingActionButton(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public FloatingActionButton(Context context, AttributeSet attributeSet, int i) {
        Mode mode;
        super(context, attributeSet, i);
        this.im = new Rect();
        t.p(context);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, a$i.cO, i, h.bV);
        this.if = obtainStyledAttributes.getColorStateList(a$i.cV);
        switch (obtainStyledAttributes.getInt(a$i.cW, -1)) {
            case 3:
                mode = Mode.SRC_OVER;
                break;
            case 5:
                mode = Mode.SRC_IN;
                break;
            case 9:
                mode = Mode.SRC_ATOP;
                break;
            case 14:
                mode = Mode.MULTIPLY;
                break;
            case 15:
                mode = Mode.SCREEN;
                break;
            default:
                mode = null;
                break;
        }
        this.ig = mode;
        this.ii = obtainStyledAttributes.getColor(a$i.cQ, 0);
        this.ij = obtainStyledAttributes.getInt(a$i.cR, 0);
        this.ih = obtainStyledAttributes.getDimensionPixelSize(a$i.cT, 0);
        float dimension = obtainStyledAttributes.getDimension(a$i.cP, 0.0f);
        float dimension2 = obtainStyledAttributes.getDimension(a$i.cS, 0.0f);
        this.il = obtainStyledAttributes.getBoolean(a$i.cU, false);
        obtainStyledAttributes.recycle();
        this.in = new i(this, android.support.v7.widget.h.eJ());
        this.in.b(attributeSet, i);
        this.ik = (ag() - ((int) getResources().getDimension(a$d.bn))) / 2;
        ah().a(this.if, this.ig, this.ii, this.ih);
        l ah = ah();
        if (ah.iM != dimension) {
            ah.iM = dimension;
            ah.l(dimension);
        }
        l ah2 = ah();
        if (ah2.iN != dimension2) {
            ah2.iN = dimension2;
            ah2.m(dimension2);
        }
        ah().ao();
    }

    protected void onMeasure(int i, int i2) {
        int ag = ag();
        ag = Math.min(resolveAdjustedSize(ag, i), resolveAdjustedSize(ag, i2));
        setMeasuredDimension((this.im.left + ag) + this.im.right, (ag + this.im.top) + this.im.bottom);
    }

    public ColorStateList getBackgroundTintList() {
        return this.if;
    }

    public void setBackgroundTintList(ColorStateList colorStateList) {
        if (this.if != colorStateList) {
            this.if = colorStateList;
            ah().setBackgroundTintList(colorStateList);
        }
    }

    public Mode getBackgroundTintMode() {
        return this.ig;
    }

    public void setBackgroundTintMode(Mode mode) {
        if (this.ig != mode) {
            this.ig = mode;
            ah().setBackgroundTintMode(mode);
        }
    }

    public void setBackgroundDrawable(Drawable drawable) {
    }

    public void setBackgroundResource(int i) {
    }

    public void setBackgroundColor(int i) {
    }

    public void setImageResource(int i) {
        this.in.setImageResource(i);
    }

    final int ag() {
        switch (this.ij) {
            case 1:
                return getResources().getDimensionPixelSize(a$d.bo);
            default:
                return getResources().getDimensionPixelSize(a$d.bp);
        }
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        l ah = ah();
        if (ah.am()) {
            if (ah.iR == null) {
                ah.iR = new l$1(ah);
            }
            ah.iP.getViewTreeObserver().addOnPreDrawListener(ah.iR);
        }
    }

    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        l ah = ah();
        if (ah.iR != null) {
            ah.iP.getViewTreeObserver().removeOnPreDrawListener(ah.iR);
            ah.iR = null;
        }
    }

    protected void drawableStateChanged() {
        super.drawableStateChanged();
        ah().c(getDrawableState());
    }

    @TargetApi(11)
    public void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        ah().ak();
    }

    private static int resolveAdjustedSize(int i, int i2) {
        int mode = MeasureSpec.getMode(i2);
        int size = MeasureSpec.getSize(i2);
        switch (mode) {
            case Integer.MIN_VALUE:
                return Math.min(i, size);
            case 1073741824:
                return size;
            default:
                return i;
        }
    }

    private l ah() {
        if (this.io == null) {
            int i = VERSION.SDK_INT;
            l mVar = i >= 21 ? new m(this, new FloatingActionButton$b(this, (byte) 0)) : i >= 14 ? new k(this, new FloatingActionButton$b(this, (byte) 0)) : new j(this, new FloatingActionButton$b(this, (byte) 0));
            this.io = mVar;
        }
        return this.io;
    }
}
