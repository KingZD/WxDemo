package android.support.v4.view;

import android.database.DataSetObserver;

class ViewPager$g extends DataSetObserver {
    final /* synthetic */ ViewPager zI;

    private ViewPager$g(ViewPager viewPager) {
        this.zI = viewPager;
    }

    public final void onChanged() {
        this.zI.cc();
    }

    public final void onInvalidated() {
        this.zI.cc();
    }
}
