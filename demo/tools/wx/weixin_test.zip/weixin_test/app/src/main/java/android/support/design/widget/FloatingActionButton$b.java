package android.support.design.widget;

import android.graphics.drawable.Drawable;

class FloatingActionButton$b implements p {
    final /* synthetic */ FloatingActionButton iw;

    private FloatingActionButton$b(FloatingActionButton floatingActionButton) {
        this.iw = floatingActionButton;
    }

    public final float ai() {
        return ((float) this.iw.ag()) / 2.0f;
    }

    public final void d(int i, int i2, int i3, int i4) {
        FloatingActionButton.c(this.iw).set(i, i2, i3, i4);
        this.iw.setPadding(FloatingActionButton.d(this.iw) + i, FloatingActionButton.d(this.iw) + i2, FloatingActionButton.d(this.iw) + i3, FloatingActionButton.d(this.iw) + i4);
    }

    public final void setBackgroundDrawable(Drawable drawable) {
        FloatingActionButton.a(this.iw, drawable);
    }

    public final boolean aj() {
        return FloatingActionButton.e(this.iw);
    }
}
