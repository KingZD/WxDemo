package android.support.design.widget;

import android.support.v4.view.z;
import android.view.View;
import android.view.animation.Interpolator;

class CollapsingToolbarLayout$a implements AppBarLayout$a {
    final /* synthetic */ CollapsingToolbarLayout hl;

    private CollapsingToolbarLayout$a(CollapsingToolbarLayout collapsingToolbarLayout) {
        this.hl = collapsingToolbarLayout;
    }

    public final void a(AppBarLayout appBarLayout, int i) {
        int systemWindowInsetTop;
        int i2 = 255;
        int i3 = 1;
        int i4 = 0;
        CollapsingToolbarLayout.b(this.hl, i);
        if (CollapsingToolbarLayout.a(this.hl) != null) {
            systemWindowInsetTop = CollapsingToolbarLayout.a(this.hl).getSystemWindowInsetTop();
        } else {
            systemWindowInsetTop = 0;
        }
        int S = appBarLayout.S();
        int childCount = this.hl.getChildCount();
        for (int i5 = 0; i5 < childCount; i5++) {
            View childAt = this.hl.getChildAt(i5);
            CollapsingToolbarLayout$LayoutParams collapsingToolbarLayout$LayoutParams = (CollapsingToolbarLayout$LayoutParams) childAt.getLayoutParams();
            z l = CollapsingToolbarLayout.l(childAt);
            switch (collapsingToolbarLayout$LayoutParams.hm) {
                case 1:
                    if ((this.hl.getHeight() - systemWindowInsetTop) + i < childAt.getHeight()) {
                        break;
                    }
                    l.q(-i);
                    break;
                case 2:
                    l.q(Math.round(collapsingToolbarLayout$LayoutParams.hn * ((float) (-i))));
                    break;
                default:
                    break;
            }
        }
        if (!(CollapsingToolbarLayout.b(this.hl) == null && CollapsingToolbarLayout.c(this.hl) == null)) {
            View view = this.hl;
            boolean z = this.hl.getHeight() + i < (z.T(this.hl) * 2) + systemWindowInsetTop;
            if (!z.ai(view) || view.isInEditMode()) {
                i3 = 0;
            }
            if (view.hh != z) {
                if (i3 != 0) {
                    if (z) {
                        i4 = 255;
                    }
                    view.ac();
                    if (view.hi == null) {
                        Interpolator interpolator;
                        view.hi = aa.aJ();
                        view.hi.setDuration(600);
                        u uVar = view.hi;
                        if (i4 > view.hg) {
                            interpolator = a.eO;
                        } else {
                            interpolator = a.eP;
                        }
                        uVar.setInterpolator(interpolator);
                        view.hi.a(new CollapsingToolbarLayout$2(view));
                    } else if (view.hi.lD.isRunning()) {
                        view.hi.lD.cancel();
                    }
                    view.hi.i(view.hg, i4);
                    view.hi.lD.start();
                } else {
                    if (!z) {
                        i2 = 0;
                    }
                    view.C(i2);
                }
                view.hh = z;
            }
        }
        if (CollapsingToolbarLayout.c(this.hl) != null && systemWindowInsetTop > 0) {
            z.E(this.hl);
        }
        CollapsingToolbarLayout.d(this.hl).h(((float) Math.abs(i)) / ((float) ((this.hl.getHeight() - z.T(this.hl)) - systemWindowInsetTop)));
        if (Math.abs(i) == S) {
            z.g(appBarLayout, appBarLayout.eV);
        } else {
            z.g(appBarLayout, 0.0f);
        }
    }
}
