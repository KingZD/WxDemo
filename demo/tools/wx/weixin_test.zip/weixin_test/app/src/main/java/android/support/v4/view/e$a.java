package android.support.v4.view;

import android.view.MotionEvent;

interface e$a {
    boolean onTouchEvent(MotionEvent motionEvent);
}
