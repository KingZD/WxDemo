package android.support.v4.media;

import android.os.Binder;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.media.MediaBrowserServiceCompat$g.AnonymousClass4;
import android.support.v4.media.MediaBrowserServiceCompat$g.AnonymousClass6;
import android.support.v4.os.ResultReceiver;
import android.text.TextUtils;

final class MediaBrowserServiceCompat$f extends Handler {
    final /* synthetic */ MediaBrowserServiceCompat uK;
    private final MediaBrowserServiceCompat$g uW;

    private MediaBrowserServiceCompat$f(MediaBrowserServiceCompat mediaBrowserServiceCompat) {
        this.uK = mediaBrowserServiceCompat;
        this.uW = new MediaBrowserServiceCompat$g(this.uK, (byte) 0);
    }

    public final void handleMessage(Message message) {
        Bundle data = message.getData();
        MediaBrowserServiceCompat$g mediaBrowserServiceCompat$g;
        MediaBrowserServiceCompat$g mediaBrowserServiceCompat$g2;
        String string;
        switch (message.what) {
            case 1:
                mediaBrowserServiceCompat$g = this.uW;
                String string2 = data.getString("data_package_name");
                int i = data.getInt("data_calling_uid");
                Bundle bundle = data.getBundle("data_root_hints");
                MediaBrowserServiceCompat$d mediaBrowserServiceCompat$e = new MediaBrowserServiceCompat$e(this.uK, message.replyTo);
                if (MediaBrowserServiceCompat.a(mediaBrowserServiceCompat$g.uK, string2, i)) {
                    MediaBrowserServiceCompat.a(mediaBrowserServiceCompat$g.uK).c(new MediaBrowserServiceCompat$g$1(mediaBrowserServiceCompat$g, mediaBrowserServiceCompat$e, string2, bundle, i));
                    return;
                }
                throw new IllegalArgumentException("Package/uid mismatch: uid=" + i + " package=" + string2);
            case 2:
                mediaBrowserServiceCompat$g2 = this.uW;
                MediaBrowserServiceCompat.a(mediaBrowserServiceCompat$g2.uK).c(new MediaBrowserServiceCompat$g$2(mediaBrowserServiceCompat$g2, new MediaBrowserServiceCompat$e(this.uK, message.replyTo)));
                return;
            case 3:
                mediaBrowserServiceCompat$g = this.uW;
                string = data.getString("data_media_item_id");
                data = data.getBundle("data_options");
                MediaBrowserServiceCompat.a(mediaBrowserServiceCompat$g.uK).c(new MediaBrowserServiceCompat$g$3(mediaBrowserServiceCompat$g, new MediaBrowserServiceCompat$e(this.uK, message.replyTo), string, data));
                return;
            case 4:
                mediaBrowserServiceCompat$g = this.uW;
                string = data.getString("data_media_item_id");
                data = data.getBundle("data_options");
                MediaBrowserServiceCompat.a(mediaBrowserServiceCompat$g.uK).c(new AnonymousClass4(mediaBrowserServiceCompat$g, new MediaBrowserServiceCompat$e(this.uK, message.replyTo), string, data));
                return;
            case 5:
                mediaBrowserServiceCompat$g = this.uW;
                Object string3 = data.getString("data_media_item_id");
                ResultReceiver resultReceiver = (ResultReceiver) data.getParcelable("data_result_receiver");
                if (!TextUtils.isEmpty(string3) && resultReceiver != null) {
                    MediaBrowserServiceCompat.a(mediaBrowserServiceCompat$g.uK).c(new MediaBrowserServiceCompat$g$5(mediaBrowserServiceCompat$g, string3, resultReceiver));
                    return;
                }
                return;
            case 6:
                mediaBrowserServiceCompat$g2 = this.uW;
                MediaBrowserServiceCompat.a(mediaBrowserServiceCompat$g2.uK).c(new AnonymousClass6(mediaBrowserServiceCompat$g2, new MediaBrowserServiceCompat$e(this.uK, message.replyTo)));
                return;
            case 7:
                mediaBrowserServiceCompat$g2 = this.uW;
                MediaBrowserServiceCompat.a(mediaBrowserServiceCompat$g2.uK).c(new MediaBrowserServiceCompat$g$7(mediaBrowserServiceCompat$g2, new MediaBrowserServiceCompat$e(this.uK, message.replyTo)));
                return;
            default:
                new StringBuilder("Unhandled message: ").append(message).append("\n  Service version: 1\n  Client version: ").append(message.arg1);
                return;
        }
    }

    public final boolean sendMessageAtTime(Message message, long j) {
        Bundle data = message.getData();
        data.setClassLoader(MediaBrowserCompat.class.getClassLoader());
        data.putInt("data_calling_uid", Binder.getCallingUid());
        return super.sendMessageAtTime(message, j);
    }

    private void c(Runnable runnable) {
        if (Thread.currentThread() == getLooper().getThread()) {
            runnable.run();
        } else {
            post(runnable);
        }
    }
}
