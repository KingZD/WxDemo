package android.support.v4.b.a;

import android.graphics.drawable.Drawable;

public interface c {
    Drawable by();

    void k(Drawable drawable);
}
