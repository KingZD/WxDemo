package android.support.v4.b.a;

import android.graphics.drawable.Drawable;
import java.lang.reflect.Method;

final class b {
    static Method ug;
    static boolean uh;
    private static Method uj;
    private static boolean uk;

    public static int j(Drawable drawable) {
        if (!uk) {
            try {
                Method declaredMethod = Drawable.class.getDeclaredMethod("getLayoutDirection", new Class[0]);
                uj = declaredMethod;
                declaredMethod.setAccessible(true);
            } catch (NoSuchMethodException e) {
            }
            uk = true;
        }
        if (uj != null) {
            try {
                return ((Integer) uj.invoke(drawable, new Object[0])).intValue();
            } catch (Exception e2) {
                uj = null;
            }
        }
        return -1;
    }
}
