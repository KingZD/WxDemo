package android.support.v4.widget;

import android.support.v4.widget.r.d;

class r$a extends d {
    r$a() {
    }
}
