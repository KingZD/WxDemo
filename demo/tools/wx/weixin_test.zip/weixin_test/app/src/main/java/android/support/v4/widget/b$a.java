package android.support.v4.widget;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader.TileMode;
import android.graphics.drawable.shapes.OvalShape;

class b$a extends OvalShape {
    private RadialGradient Bw;
    private Paint Bx = new Paint();
    private int By;
    final /* synthetic */ b Bz;

    public b$a(b bVar, int i, int i2) {
        this.Bz = bVar;
        b.a(bVar, i);
        this.By = i2;
        this.Bw = new RadialGradient((float) (this.By / 2), (float) (this.By / 2), (float) b.a(bVar), new int[]{1023410176, 0}, null, TileMode.CLAMP);
        this.Bx.setShader(this.Bw);
    }

    public final void draw(Canvas canvas, Paint paint) {
        int width = this.Bz.getWidth();
        int height = this.Bz.getHeight();
        canvas.drawCircle((float) (width / 2), (float) (height / 2), (float) ((this.By / 2) + b.a(this.Bz)), this.Bx);
        canvas.drawCircle((float) (width / 2), (float) (height / 2), (float) (this.By / 2), paint);
    }
}
