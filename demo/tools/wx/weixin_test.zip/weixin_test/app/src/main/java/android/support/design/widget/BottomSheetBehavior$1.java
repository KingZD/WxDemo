package android.support.design.widget;

import android.support.v4.view.z;
import android.support.v4.widget.u.a;
import android.view.View;

class BottomSheetBehavior$1 extends a {
    final /* synthetic */ BottomSheetBehavior fK;

    BottomSheetBehavior$1(BottomSheetBehavior bottomSheetBehavior) {
        this.fK = bottomSheetBehavior;
    }

    public final boolean b(View view, int i) {
        if (BottomSheetBehavior.a(this.fK) == 1) {
            return false;
        }
        if (BottomSheetBehavior.b(this.fK)) {
            return false;
        }
        if (BottomSheetBehavior.a(this.fK) == 3 && BottomSheetBehavior.c(this.fK) == i) {
            View view2 = (View) BottomSheetBehavior.d(this.fK).get();
            if (view2 != null && z.h(view2, -1)) {
                return false;
            }
        }
        return BottomSheetBehavior.e(this.fK) != null && BottomSheetBehavior.e(this.fK).get() == view;
    }

    public final void a(View view, int i, int i2) {
        BottomSheetBehavior.a(this.fK, i2);
    }

    public final void u(int i) {
        if (i == 1) {
            BottomSheetBehavior.b(this.fK, 1);
        }
    }

    public final void a(View view, float f, float f2) {
        int f3;
        int i = 3;
        if (f2 < 0.0f) {
            f3 = BottomSheetBehavior.f(this.fK);
        } else if (BottomSheetBehavior.g(this.fK) && BottomSheetBehavior.a(this.fK, view, f2)) {
            f3 = BottomSheetBehavior.h(this.fK);
            i = 5;
        } else if (f2 == 0.0f) {
            int top = view.getTop();
            if (Math.abs(top - BottomSheetBehavior.f(this.fK)) < Math.abs(top - BottomSheetBehavior.i(this.fK))) {
                f3 = BottomSheetBehavior.f(this.fK);
            } else {
                f3 = BottomSheetBehavior.i(this.fK);
                i = 4;
            }
        } else {
            f3 = BottomSheetBehavior.i(this.fK);
            i = 4;
        }
        if (BottomSheetBehavior.j(this.fK).v(view.getLeft(), f3)) {
            BottomSheetBehavior.b(this.fK, 2);
            z.a(view, new BottomSheetBehavior$b(this.fK, view, i));
            return;
        }
        BottomSheetBehavior.b(this.fK, i);
    }

    public final int c(View view, int i) {
        return n.e(i, BottomSheetBehavior.f(this.fK), BottomSheetBehavior.g(this.fK) ? BottomSheetBehavior.h(this.fK) : BottomSheetBehavior.i(this.fK));
    }

    public final int d(View view, int i) {
        return view.getLeft();
    }

    public final int X() {
        if (BottomSheetBehavior.g(this.fK)) {
            return BottomSheetBehavior.h(this.fK) - BottomSheetBehavior.f(this.fK);
        }
        return BottomSheetBehavior.i(this.fK) - BottomSheetBehavior.f(this.fK);
    }
}
