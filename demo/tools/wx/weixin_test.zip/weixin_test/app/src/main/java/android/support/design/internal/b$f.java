package android.support.design.internal;

import android.support.design.internal.b.d;
import android.support.v7.view.menu.h;

class b$f implements d {
    final h eH;

    private b$f(h hVar) {
        this.eH = hVar;
    }
}
