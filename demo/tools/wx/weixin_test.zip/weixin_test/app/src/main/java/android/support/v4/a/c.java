package android.support.v4.a;

import android.view.View;

interface c {
    g aW();

    void v(View view);
}
