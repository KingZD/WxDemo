package android.support.v4.b;

import android.graphics.Bitmap;
import android.os.Build.VERSION;

public final class a {
    static final a$b ud;

    static {
        int i = VERSION.SDK_INT;
        if (i >= 19) {
            ud = new a$e();
        } else if (i >= 18) {
            ud = new a$d();
        } else if (i >= 12) {
            ud = new a$c();
        } else {
            ud = new a$a();
        }
    }

    public static int e(Bitmap bitmap) {
        return ud.e(bitmap);
    }
}
