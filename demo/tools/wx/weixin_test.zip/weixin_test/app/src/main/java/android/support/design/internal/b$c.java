package android.support.design.internal;

import android.support.design.internal.b.d;

class b$c implements d {
    private b$c() {
    }
}
