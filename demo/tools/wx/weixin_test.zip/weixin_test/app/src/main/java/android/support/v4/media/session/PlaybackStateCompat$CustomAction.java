package android.support.v4.media.session;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.text.TextUtils;

public final class PlaybackStateCompat$CustomAction implements Parcelable {
    public static final Creator<PlaybackStateCompat$CustomAction> CREATOR = new PlaybackStateCompat$CustomAction$1();
    private final Bundle mExtras;
    private final String vK;
    private final CharSequence vL;
    private final int vM;

    private PlaybackStateCompat$CustomAction(Parcel parcel) {
        this.vK = parcel.readString();
        this.vL = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.vM = parcel.readInt();
        this.mExtras = parcel.readBundle();
    }

    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.vK);
        TextUtils.writeToParcel(this.vL, parcel, i);
        parcel.writeInt(this.vM);
        parcel.writeBundle(this.mExtras);
    }

    public final int describeContents() {
        return 0;
    }

    public final String toString() {
        return "Action:mName='" + this.vL + ", mIcon=" + this.vM + ", mExtras=" + this.mExtras;
    }
}
