package android.support.design.widget;

import android.view.animation.Animation;
import android.view.animation.Transformation;

abstract class j$a extends Animation {
    final /* synthetic */ j iD;
    private float iE;
    private float iF;

    protected abstract float al();

    private j$a(j jVar) {
        this.iD = jVar;
    }

    public void reset() {
        super.reset();
        this.iE = this.iD.iA.jv;
        this.iF = al() - this.iE;
    }

    protected void applyTransformation(float f, Transformation transformation) {
        o oVar = this.iD.iA;
        oVar.o(this.iE + (this.iF * f), oVar.jt);
    }
}
