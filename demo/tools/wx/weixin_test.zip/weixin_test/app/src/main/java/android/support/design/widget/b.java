package android.support.design.widget;

class b {
    b() {
    }
}
