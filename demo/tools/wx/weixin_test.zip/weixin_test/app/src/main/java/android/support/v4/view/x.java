package android.support.v4.view;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;

public interface x {
    void a(Mode mode);

    ColorStateList bX();

    Mode bY();

    void d(ColorStateList colorStateList);
}
