package android.support.v4.app;

import android.app.Notification;
import android.os.Bundle;
import android.support.v4.app.af.a;

class z$q extends z$p {
    z$q() {
    }

    public Notification b(z$d z_d) {
        y aVar = new a(z_d.mContext, z_d.sG, z_d.si, z_d.sj, z_d.so, z_d.sm, z_d.sp, z_d.sk, z_d.sl, z_d.sn, z_d.su, z_d.sv, z_d.sw, z_d.sq, z_d.sr, z_d.mPriority, z_d.st, z_d.sB, z_d.sH, z_d.mExtras, z_d.sx, z_d.sy, z_d.sz);
        z.a(aVar, z_d.sA);
        z.a(aVar, z_d.ss);
        return aVar.build();
    }

    public final Bundle a(Notification notification) {
        return notification.extras;
    }
}
