package android.support.design.widget;

import android.support.v4.view.an;
import android.support.v4.view.z;
import android.view.View;

class Snackbar$8 extends an {
    final /* synthetic */ Snackbar jH;
    final /* synthetic */ int val$event;

    Snackbar$8(Snackbar snackbar, int i) {
        this.jH = snackbar;
        this.val$event = i;
    }

    public final void p(View view) {
        Snackbar$SnackbarLayout c = Snackbar.c(this.jH);
        z.d(c.jJ, 1.0f);
        z.U(c.jJ).s(0.0f).h(180).i(0).start();
        if (c.jK.getVisibility() == 0) {
            z.d(c.jK, 1.0f);
            z.U(c.jK).s(0.0f).h(180).i(0).start();
        }
    }

    public final void q(View view) {
        Snackbar.a(this.jH, this.val$event);
    }
}
