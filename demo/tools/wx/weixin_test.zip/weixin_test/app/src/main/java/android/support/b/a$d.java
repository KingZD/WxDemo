package android.support.b;

class a$d {
    public final String name;
    public final int number;
    public final int oJ;
    public final int oK;

    private a$d(String str, int i, int i2) {
        this.name = str;
        this.number = i;
        this.oJ = i2;
        this.oK = -1;
    }

    private a$d(String str, int i, int i2, int i3) {
        this.name = str;
        this.number = i;
        this.oJ = 3;
        this.oK = 4;
    }
}
