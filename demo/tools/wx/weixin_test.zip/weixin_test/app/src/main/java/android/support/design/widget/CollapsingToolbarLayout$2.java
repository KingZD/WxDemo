package android.support.design.widget;

class CollapsingToolbarLayout$2 implements u$c {
    final /* synthetic */ CollapsingToolbarLayout hl;

    CollapsingToolbarLayout$2(CollapsingToolbarLayout collapsingToolbarLayout) {
        this.hl = collapsingToolbarLayout;
    }

    public final void a(u uVar) {
        CollapsingToolbarLayout.a(this.hl, uVar.lD.aK());
    }
}
