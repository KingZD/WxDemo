package android.support.v4.app;

import android.app.Notification;
import android.os.Bundle;
import android.support.v4.app.ac.b;

interface z$i {
    Bundle a(Notification notification);

    Bundle a(b bVar);

    Notification b(z$d z_d);
}
