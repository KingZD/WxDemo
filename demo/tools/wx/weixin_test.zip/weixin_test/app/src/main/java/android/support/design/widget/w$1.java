package android.support.design.widget;

import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;

class w$1 implements AnimatorUpdateListener {
    final /* synthetic */ u$e$b lO;
    final /* synthetic */ w lP;

    w$1(w wVar, u$e$b u_e_b) {
        this.lP = wVar;
        this.lO = u_e_b;
    }

    public final void onAnimationUpdate(ValueAnimator valueAnimator) {
        this.lO.aI();
    }
}
