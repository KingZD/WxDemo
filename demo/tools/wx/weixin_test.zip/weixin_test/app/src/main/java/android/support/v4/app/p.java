package android.support.v4.app;

import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.app.Fragment.SavedState;
import android.support.v4.view.u;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;

public abstract class p extends u {
    private final m rj;
    private q rk = null;
    private Fragment rl = null;
    private ArrayList<SavedState> ro = new ArrayList();
    private ArrayList<Fragment> rp = new ArrayList();

    public abstract Fragment S(int i);

    public p(m mVar) {
        this.rj = mVar;
    }

    public final Object b(ViewGroup viewGroup, int i) {
        if (this.rp.size() > i) {
            Fragment fragment = (Fragment) this.rp.get(i);
            if (fragment != null) {
                return fragment;
            }
        }
        if (this.rk == null) {
            this.rk = this.rj.bd();
        }
        Fragment S = S(i);
        if (this.ro.size() > i) {
            SavedState savedState = (SavedState) this.ro.get(i);
            if (savedState != null) {
                S.setInitialSavedState(savedState);
            }
        }
        while (this.rp.size() <= i) {
            this.rp.add(null);
        }
        S.setMenuVisibility(false);
        S.setUserVisibleHint(false);
        this.rp.set(i, S);
        this.rk.a(viewGroup.getId(), S);
        return S;
    }

    public final void a(ViewGroup viewGroup, int i, Object obj) {
        Fragment fragment = (Fragment) obj;
        if (this.rk == null) {
            this.rk = this.rj.bd();
        }
        while (this.ro.size() <= i) {
            this.ro.add(null);
        }
        this.ro.set(i, fragment.isAdded() ? this.rj.e(fragment) : null);
        this.rp.set(i, null);
        this.rk.a(fragment);
    }

    public final void e(Object obj) {
        Fragment fragment = (Fragment) obj;
        if (fragment != this.rl) {
            if (this.rl != null) {
                this.rl.setMenuVisibility(false);
                this.rl.setUserVisibleHint(false);
            }
            if (fragment != null) {
                fragment.setMenuVisibility(true);
                fragment.setUserVisibleHint(true);
            }
            this.rl = fragment;
        }
    }

    public final void bi() {
        if (this.rk != null) {
            this.rk.commitAllowingStateLoss();
            this.rk = null;
            this.rj.executePendingTransactions();
        }
    }

    public final boolean a(View view, Object obj) {
        return ((Fragment) obj).getView() == view;
    }

    public final Parcelable bj() {
        Bundle bundle = null;
        if (this.ro.size() > 0) {
            bundle = new Bundle();
            Parcelable[] parcelableArr = new SavedState[this.ro.size()];
            this.ro.toArray(parcelableArr);
            bundle.putParcelableArray("states", parcelableArr);
        }
        Parcelable parcelable = bundle;
        for (int i = 0; i < this.rp.size(); i++) {
            Fragment fragment = (Fragment) this.rp.get(i);
            if (fragment != null && fragment.isAdded()) {
                if (parcelable == null) {
                    parcelable = new Bundle();
                }
                this.rj.a(parcelable, "f" + i, fragment);
            }
        }
        return parcelable;
    }

    public final void a(Parcelable parcelable, ClassLoader classLoader) {
        if (parcelable != null) {
            Bundle bundle = (Bundle) parcelable;
            bundle.setClassLoader(classLoader);
            Parcelable[] parcelableArray = bundle.getParcelableArray("states");
            this.ro.clear();
            this.rp.clear();
            if (parcelableArray != null) {
                for (Parcelable parcelable2 : parcelableArray) {
                    this.ro.add((SavedState) parcelable2);
                }
            }
            for (String str : bundle.keySet()) {
                if (str.startsWith("f")) {
                    int parseInt = Integer.parseInt(str.substring(1));
                    Fragment c = this.rj.c(bundle, str);
                    if (c != null) {
                        while (this.rp.size() <= parseInt) {
                            this.rp.add(null);
                        }
                        c.setMenuVisibility(false);
                        this.rp.set(parseInt, c);
                    }
                }
            }
        }
    }
}
