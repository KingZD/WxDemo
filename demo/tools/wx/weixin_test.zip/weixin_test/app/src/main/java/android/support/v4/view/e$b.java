package android.support.v4.view;

import android.content.Context;
import android.os.Handler;
import android.view.GestureDetector.OnDoubleTapListener;
import android.view.GestureDetector.OnGestureListener;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.ViewConfiguration;

class e$b implements e$a {
    private static final int xb = ViewConfiguration.getLongPressTimeout();
    private static final int xc = ViewConfiguration.getTapTimeout();
    private static final int xd = ViewConfiguration.getDoubleTapTimeout();
    private VelocityTracker fF;
    private final Handler mHandler = new e$b$a(this);
    private int wX;
    private int wY;
    private int wZ;
    private int xa;
    private final OnGestureListener xe;
    private OnDoubleTapListener xf;
    private boolean xg;
    private boolean xh;
    private boolean xi;
    private boolean xj;
    private boolean xk;
    private MotionEvent xl;
    private MotionEvent xm;
    private boolean xn;
    private float xo;
    private float xp;
    private float xq;
    private float xr;
    private boolean xs;

    static /* synthetic */ void c(e$b e_b) {
        e_b.mHandler.removeMessages(3);
        e_b.xh = false;
        e_b.xi = true;
        e_b.xe.onLongPress(e_b.xl);
    }

    public e$b(Context context, OnGestureListener onGestureListener, Handler handler) {
        this.xe = onGestureListener;
        if (onGestureListener instanceof OnDoubleTapListener) {
            this.xf = (OnDoubleTapListener) onGestureListener;
        }
        if (context == null) {
            throw new IllegalArgumentException("Context must not be null");
        } else if (this.xe == null) {
            throw new IllegalArgumentException("OnGestureListener must not be null");
        } else {
            this.xs = true;
            ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
            int scaledTouchSlop = viewConfiguration.getScaledTouchSlop();
            int scaledDoubleTapSlop = viewConfiguration.getScaledDoubleTapSlop();
            this.wZ = viewConfiguration.getScaledMinimumFlingVelocity();
            this.xa = viewConfiguration.getScaledMaximumFlingVelocity();
            this.wX = scaledTouchSlop * scaledTouchSlop;
            this.wY = scaledDoubleTapSlop * scaledDoubleTapSlop;
        }
    }

    public final boolean onTouchEvent(MotionEvent motionEvent) {
        int i;
        int action = motionEvent.getAction();
        if (this.fF == null) {
            this.fF = VelocityTracker.obtain();
        }
        this.fF.addMovement(motionEvent);
        boolean z = (action & 255) == 6;
        int e = z ? o.e(motionEvent) : -1;
        int f = o.f(motionEvent);
        float f2 = 0.0f;
        float f3 = 0.0f;
        for (i = 0; i < f; i++) {
            if (e != i) {
                f3 += o.d(motionEvent, i);
                f2 += o.e(motionEvent, i);
            }
        }
        e = z ? f - 1 : f;
        f3 /= (float) e;
        f2 /= (float) e;
        boolean hasMessages;
        float b;
        float a;
        switch (action & 255) {
            case 0:
                if (this.xf != null) {
                    hasMessages = this.mHandler.hasMessages(3);
                    if (hasMessages) {
                        this.mHandler.removeMessages(3);
                    }
                    if (!(this.xl == null || this.xm == null || !hasMessages)) {
                        MotionEvent motionEvent2 = this.xl;
                        MotionEvent motionEvent3 = this.xm;
                        if (this.xk && motionEvent.getEventTime() - motionEvent3.getEventTime() <= ((long) xd)) {
                            f = ((int) motionEvent2.getX()) - ((int) motionEvent.getX());
                            e = ((int) motionEvent2.getY()) - ((int) motionEvent.getY());
                            if ((e * e) + (f * f) < this.wY) {
                                hasMessages = true;
                                if (hasMessages) {
                                    this.xn = true;
                                    e = (this.xf.onDoubleTap(this.xl) | 0) | this.xf.onDoubleTapEvent(motionEvent);
                                    this.xo = f3;
                                    this.xq = f3;
                                    this.xp = f2;
                                    this.xr = f2;
                                    if (this.xl != null) {
                                        this.xl.recycle();
                                    }
                                    this.xl = MotionEvent.obtain(motionEvent);
                                    this.xj = true;
                                    this.xk = true;
                                    this.xg = true;
                                    this.xi = false;
                                    this.xh = false;
                                    if (this.xs) {
                                        this.mHandler.removeMessages(2);
                                        this.mHandler.sendEmptyMessageAtTime(2, (this.xl.getDownTime() + ((long) xc)) + ((long) xb));
                                    }
                                    this.mHandler.sendEmptyMessageAtTime(1, this.xl.getDownTime() + ((long) xc));
                                    return e | this.xe.onDown(motionEvent);
                                }
                            }
                        }
                        hasMessages = false;
                        if (hasMessages) {
                            this.xn = true;
                            e = (this.xf.onDoubleTap(this.xl) | 0) | this.xf.onDoubleTapEvent(motionEvent);
                            this.xo = f3;
                            this.xq = f3;
                            this.xp = f2;
                            this.xr = f2;
                            if (this.xl != null) {
                                this.xl.recycle();
                            }
                            this.xl = MotionEvent.obtain(motionEvent);
                            this.xj = true;
                            this.xk = true;
                            this.xg = true;
                            this.xi = false;
                            this.xh = false;
                            if (this.xs) {
                                this.mHandler.removeMessages(2);
                                this.mHandler.sendEmptyMessageAtTime(2, (this.xl.getDownTime() + ((long) xc)) + ((long) xb));
                            }
                            this.mHandler.sendEmptyMessageAtTime(1, this.xl.getDownTime() + ((long) xc));
                            return e | this.xe.onDown(motionEvent);
                        }
                    }
                    this.mHandler.sendEmptyMessageDelayed(3, (long) xd);
                }
                e = 0;
                this.xo = f3;
                this.xq = f3;
                this.xp = f2;
                this.xr = f2;
                if (this.xl != null) {
                    this.xl.recycle();
                }
                this.xl = MotionEvent.obtain(motionEvent);
                this.xj = true;
                this.xk = true;
                this.xg = true;
                this.xi = false;
                this.xh = false;
                if (this.xs) {
                    this.mHandler.removeMessages(2);
                    this.mHandler.sendEmptyMessageAtTime(2, (this.xl.getDownTime() + ((long) xc)) + ((long) xb));
                }
                this.mHandler.sendEmptyMessageAtTime(1, this.xl.getDownTime() + ((long) xc));
                return e | this.xe.onDown(motionEvent);
            case 1:
                this.xg = false;
                MotionEvent obtain = MotionEvent.obtain(motionEvent);
                if (this.xn) {
                    hasMessages = this.xf.onDoubleTapEvent(motionEvent) | 0;
                } else if (this.xi) {
                    this.mHandler.removeMessages(3);
                    this.xi = false;
                    hasMessages = false;
                } else if (this.xj) {
                    hasMessages = this.xe.onSingleTapUp(motionEvent);
                    if (this.xh && this.xf != null) {
                        this.xf.onSingleTapConfirmed(motionEvent);
                    }
                } else {
                    VelocityTracker velocityTracker = this.fF;
                    int c = o.c(motionEvent, 0);
                    velocityTracker.computeCurrentVelocity(1000, (float) this.xa);
                    b = y.b(velocityTracker, c);
                    a = y.a(velocityTracker, c);
                    hasMessages = (Math.abs(b) > ((float) this.wZ) || Math.abs(a) > ((float) this.wZ)) ? this.xe.onFling(this.xl, motionEvent, a, b) : false;
                }
                if (this.xm != null) {
                    this.xm.recycle();
                }
                this.xm = obtain;
                if (this.fF != null) {
                    this.fF.recycle();
                    this.fF = null;
                }
                this.xn = false;
                this.xh = false;
                this.mHandler.removeMessages(1);
                this.mHandler.removeMessages(2);
                return hasMessages;
            case 2:
                if (this.xi) {
                    return false;
                }
                a = this.xo - f3;
                b = this.xp - f2;
                if (this.xn) {
                    return this.xf.onDoubleTapEvent(motionEvent) | 0;
                }
                if (this.xj) {
                    i = (int) (f3 - this.xq);
                    int i2 = (int) (f2 - this.xr);
                    i = (i * i) + (i2 * i2);
                    if (i > this.wX) {
                        hasMessages = this.xe.onScroll(this.xl, motionEvent, a, b);
                        this.xo = f3;
                        this.xp = f2;
                        this.xj = false;
                        this.mHandler.removeMessages(3);
                        this.mHandler.removeMessages(1);
                        this.mHandler.removeMessages(2);
                    } else {
                        hasMessages = false;
                    }
                    if (i > this.wX) {
                        this.xk = false;
                    }
                    return hasMessages;
                } else if (Math.abs(a) < 1.0f && Math.abs(b) < 1.0f) {
                    return false;
                } else {
                    boolean onScroll = this.xe.onScroll(this.xl, motionEvent, a, b);
                    this.xo = f3;
                    this.xp = f2;
                    return onScroll;
                }
            case 3:
                this.mHandler.removeMessages(1);
                this.mHandler.removeMessages(2);
                this.mHandler.removeMessages(3);
                this.fF.recycle();
                this.fF = null;
                this.xn = false;
                this.xg = false;
                this.xj = false;
                this.xk = false;
                this.xh = false;
                if (!this.xi) {
                    return false;
                }
                this.xi = false;
                return false;
            case 5:
                this.xo = f3;
                this.xq = f3;
                this.xp = f2;
                this.xr = f2;
                this.mHandler.removeMessages(1);
                this.mHandler.removeMessages(2);
                this.mHandler.removeMessages(3);
                this.xn = false;
                this.xj = false;
                this.xk = false;
                this.xh = false;
                if (!this.xi) {
                    return false;
                }
                this.xi = false;
                return false;
            case 6:
                this.xo = f3;
                this.xq = f3;
                this.xp = f2;
                this.xr = f2;
                this.fF.computeCurrentVelocity(1000, (float) this.xa);
                int e2 = o.e(motionEvent);
                e = o.c(motionEvent, e2);
                f3 = y.a(this.fF, e);
                float b2 = y.b(this.fF, e);
                for (e = 0; e < f; e++) {
                    if (e != e2) {
                        i = o.c(motionEvent, e);
                        if ((y.b(this.fF, i) * b2) + (y.a(this.fF, i) * f3) < 0.0f) {
                            this.fF.clear();
                            return false;
                        }
                    }
                }
                return false;
            default:
                return false;
        }
    }
}
