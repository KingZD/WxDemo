package android.support.v4.b;

import android.graphics.Bitmap;

class a$a implements a$b {
    a$a() {
    }

    public int e(Bitmap bitmap) {
        return bitmap.getRowBytes() * bitmap.getHeight();
    }
}
