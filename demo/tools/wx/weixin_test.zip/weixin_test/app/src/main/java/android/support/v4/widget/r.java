package android.support.v4.widget;

import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.widget.TextView;

public final class r {
    static final f Fa;

    static class d extends r$c {
        d() {
        }

        public final void a(TextView textView, Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
            textView.setCompoundDrawablesRelative(drawable, null, null, null);
        }
    }

    interface f {
        void a(TextView textView, Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4);

        int c(TextView textView);
    }

    static class b implements f {
        b() {
        }

        public void a(TextView textView, Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
            textView.setCompoundDrawables(drawable, null, null, null);
        }

        public int c(TextView textView) {
            if (!s.Fe) {
                s.Fd = s.w("mMaxMode");
                s.Fe = true;
            }
            if (s.Fd != null && s.a(s.Fd, textView) == 1) {
                if (!s.Fc) {
                    s.Fb = s.w("mMaximum");
                    s.Fc = true;
                }
                if (s.Fb != null) {
                    return s.a(s.Fb, textView);
                }
            }
            return -1;
        }
    }

    static {
        int i = VERSION.SDK_INT;
        if (i >= 23) {
            Fa = new r$a();
        } else if (i >= 18) {
            Fa = new d();
        } else if (i >= 17) {
            Fa = new r$c();
        } else if (i >= 16) {
            Fa = new r$e();
        } else {
            Fa = new b();
        }
    }

    public static void a(TextView textView, Drawable drawable) {
        Fa.a(textView, drawable, null, null, null);
    }

    public static int c(TextView textView) {
        return Fa.c(textView);
    }
}
