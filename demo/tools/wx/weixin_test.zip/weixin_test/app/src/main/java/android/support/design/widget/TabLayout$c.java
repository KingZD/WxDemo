package android.support.design.widget;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.design.a$f;
import android.support.v4.view.z;
import android.support.v4.widget.r;
import android.support.v7.app.ActionBar.a;
import android.support.v7.widget.h;
import android.text.Layout;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.View.OnLongClickListener;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

class TabLayout$c extends LinearLayout implements OnLongClickListener {
    final /* synthetic */ TabLayout kG;
    private View kV;
    private TabLayout$b kY;
    private TextView kZ;
    private ImageView la;
    private TextView lb;
    private ImageView lc;
    private int ld = 2;

    static /* synthetic */ void a(TabLayout$c tabLayout$c, TabLayout$b tabLayout$b) {
        if (tabLayout$b != tabLayout$c.kY) {
            tabLayout$c.kY = tabLayout$b;
            tabLayout$c.update();
        }
    }

    public TabLayout$c(TabLayout tabLayout, Context context) {
        this.kG = tabLayout;
        super(context);
        if (TabLayout.a(tabLayout) != 0) {
            setBackgroundDrawable(h.eJ().a(context, TabLayout.a(tabLayout), false));
        }
        z.c(this, TabLayout.b(tabLayout), TabLayout.c(tabLayout), TabLayout.d(tabLayout), TabLayout.e(tabLayout));
        setGravity(17);
        setOrientation(1);
        setClickable(true);
    }

    public final boolean performClick() {
        boolean performClick = super.performClick();
        if (this.kY == null) {
            return performClick;
        }
        this.kY.select();
        return true;
    }

    public final void setSelected(boolean z) {
        Object obj = isSelected() != z ? 1 : null;
        super.setSelected(z);
        if (obj != null && z) {
            sendAccessibilityEvent(4);
            if (this.kZ != null) {
                this.kZ.setSelected(z);
            }
            if (this.la != null) {
                this.la.setSelected(z);
            }
        }
    }

    @TargetApi(14)
    public final void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName(a.class.getName());
    }

    @TargetApi(14)
    public final void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName(a.class.getName());
    }

    public final void onMeasure(int i, int i2) {
        int i3 = 1;
        int size = MeasureSpec.getSize(i);
        int mode = MeasureSpec.getMode(i);
        int f = TabLayout.f(this.kG);
        if (f > 0 && (mode == 0 || size > f)) {
            i = MeasureSpec.makeMeasureSpec(TabLayout.g(this.kG), Integer.MIN_VALUE);
        }
        super.onMeasure(i, i2);
        if (this.kZ != null) {
            getResources();
            float h = TabLayout.h(this.kG);
            size = this.ld;
            if (this.la != null && this.la.getVisibility() == 0) {
                size = 1;
            } else if (this.kZ != null && this.kZ.getLineCount() > 1) {
                h = TabLayout.i(this.kG);
            }
            float textSize = this.kZ.getTextSize();
            int lineCount = this.kZ.getLineCount();
            int c = r.c(this.kZ);
            if (h != textSize || (c >= 0 && size != c)) {
                if (TabLayout.j(this.kG) == 1 && h > textSize && lineCount == 1) {
                    Layout layout = this.kZ.getLayout();
                    if (layout == null || layout.getLineWidth(0) * (h / layout.getPaint().getTextSize()) > ((float) layout.getWidth())) {
                        i3 = 0;
                    }
                }
                if (i3 != 0) {
                    this.kZ.setTextSize(0, h);
                    this.kZ.setMaxLines(size);
                    super.onMeasure(i, i2);
                }
            }
        }
    }

    final void update() {
        TabLayout$b tabLayout$b = this.kY;
        View view = tabLayout$b != null ? tabLayout$b.kV : null;
        if (view != null) {
            TabLayout$c parent = view.getParent();
            if (parent != this) {
                if (parent != null) {
                    parent.removeView(view);
                }
                addView(view);
            }
            this.kV = view;
            if (this.kZ != null) {
                this.kZ.setVisibility(8);
            }
            if (this.la != null) {
                this.la.setVisibility(8);
                this.la.setImageDrawable(null);
            }
            this.lb = (TextView) view.findViewById(16908308);
            if (this.lb != null) {
                this.ld = r.c(this.lb);
            }
            this.lc = (ImageView) view.findViewById(16908294);
        } else {
            if (this.kV != null) {
                removeView(this.kV);
                this.kV = null;
            }
            this.lb = null;
            this.lc = null;
        }
        if (this.kV == null) {
            if (this.la == null) {
                ImageView imageView = (ImageView) LayoutInflater.from(getContext()).inflate(a$f.bG, this, false);
                addView(imageView, 0);
                this.la = imageView;
            }
            if (this.kZ == null) {
                TextView textView = (TextView) LayoutInflater.from(getContext()).inflate(a$f.bH, this, false);
                addView(textView);
                this.kZ = textView;
                this.ld = r.c(this.kZ);
            }
            this.kZ.setTextAppearance(getContext(), TabLayout.k(this.kG));
            if (TabLayout.l(this.kG) != null) {
                this.kZ.setTextColor(TabLayout.l(this.kG));
            }
            a(this.kZ, this.la);
        } else if (this.lb != null || this.lc != null) {
            a(this.lb, this.lc);
        }
    }

    private void a(TextView textView, ImageView imageView) {
        CharSequence charSequence;
        CharSequence charSequence2;
        boolean z;
        Drawable drawable = this.kY != null ? this.kY.kj : null;
        if (this.kY != null) {
            charSequence = this.kY.mText;
        } else {
            charSequence = null;
        }
        if (this.kY != null) {
            charSequence2 = this.kY.kU;
        } else {
            charSequence2 = null;
        }
        if (imageView != null) {
            if (drawable != null) {
                imageView.setImageDrawable(drawable);
                imageView.setVisibility(0);
                setVisibility(0);
            } else {
                imageView.setVisibility(8);
                imageView.setImageDrawable(null);
            }
            imageView.setContentDescription(charSequence2);
        }
        if (TextUtils.isEmpty(charSequence)) {
            z = false;
        } else {
            z = true;
        }
        if (textView != null) {
            if (z) {
                textView.setText(charSequence);
                textView.setVisibility(0);
                setVisibility(0);
            } else {
                textView.setVisibility(8);
                textView.setText(null);
            }
            textView.setContentDescription(charSequence2);
        }
        if (imageView != null) {
            int a;
            MarginLayoutParams marginLayoutParams = (MarginLayoutParams) imageView.getLayoutParams();
            if (z && imageView.getVisibility() == 0) {
                a = TabLayout.a(this.kG, 8);
            } else {
                a = 0;
            }
            if (a != marginLayoutParams.bottomMargin) {
                marginLayoutParams.bottomMargin = a;
                imageView.requestLayout();
            }
        }
        if (z || TextUtils.isEmpty(charSequence2)) {
            setOnLongClickListener(null);
            setLongClickable(false);
            return;
        }
        setOnLongClickListener(this);
    }

    public final boolean onLongClick(View view) {
        int[] iArr = new int[2];
        getLocationOnScreen(iArr);
        Context context = getContext();
        int width = getWidth();
        int height = getHeight();
        int i = context.getResources().getDisplayMetrics().widthPixels;
        Toast makeText = Toast.makeText(context, this.kY.kU, 0);
        makeText.setGravity(49, (iArr[0] + (width / 2)) - (i / 2), height);
        makeText.show();
        return true;
    }
}
