package android.support.design.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.support.design.a$a;
import android.support.v4.b.a.a;
import android.util.StateSet;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import java.lang.ref.WeakReference;

class j extends l {
    o iA;
    private int ix;
    private r iy = new r();
    private boolean iz;

    private class c extends j$a {
        final /* synthetic */ j iD;

        private c(j jVar) {
            this.iD = jVar;
            super(jVar, (byte) 0);
        }

        protected final float al() {
            return this.iD.iM;
        }
    }

    j(VisibilityAwareImageButton visibilityAwareImageButton, p pVar) {
        super(visibilityAwareImageButton, pVar);
        this.ix = visibilityAwareImageButton.getResources().getInteger(17694720);
        r rVar = this.iy;
        View aB = rVar.aB();
        if (aB != visibilityAwareImageButton) {
            if (aB != null) {
                View aB2 = rVar.aB();
                int size = rVar.jT.size();
                for (int i = 0; i < size; i++) {
                    if (aB2.getAnimation() == ((r$a) rVar.jT.get(i)).mAnimation) {
                        aB2.clearAnimation();
                    }
                }
                rVar.fC = null;
                rVar.jU = null;
                rVar.jV = null;
            }
            if (visibilityAwareImageButton != null) {
                rVar.fC = new WeakReference(visibilityAwareImageButton);
            }
        }
        this.iy.a(PRESSED_ENABLED_STATE_SET, e(new j$b(this, (byte) 0)));
        this.iy.a(iO, e(new j$b(this, (byte) 0)));
        this.iy.a(EMPTY_STATE_SET, e(new c()));
    }

    void a(ColorStateList colorStateList, Mode mode, int i, int i2) {
        Drawable[] drawableArr;
        this.iI = a.h(aq());
        a.a(this.iI, colorStateList);
        if (mode != null) {
            a.a(this.iI, mode);
        }
        this.iJ = a.h(aq());
        Drawable drawable = this.iJ;
        r1 = new int[3][];
        int[] iArr = new int[]{iO, i, PRESSED_ENABLED_STATE_SET};
        iArr[1] = i;
        r1[2] = new int[0];
        iArr[2] = 0;
        a.a(drawable, new ColorStateList(r1, iArr));
        if (i2 > 0) {
            this.iK = a(i2, colorStateList);
            drawableArr = new Drawable[]{this.iK, this.iI, this.iJ};
        } else {
            this.iK = null;
            drawableArr = new Drawable[]{this.iI, this.iJ};
        }
        this.iL = new LayerDrawable(drawableArr);
        this.iA = new o(this.iP.getResources(), this.iL, this.iQ.ai(), this.iM, this.iM + this.iN);
        o oVar = this.iA;
        oVar.jA = false;
        oVar.invalidateSelf();
        this.iQ.setBackgroundDrawable(this.iA);
    }

    final void setBackgroundTintList(ColorStateList colorStateList) {
        if (this.iI != null) {
            a.a(this.iI, colorStateList);
        }
        if (this.iK != null) {
            this.iK.c(colorStateList);
        }
    }

    final void setBackgroundTintMode(Mode mode) {
        if (this.iI != null) {
            a.a(this.iI, mode);
        }
    }

    void l(float f) {
        if (this.iA != null) {
            this.iA.o(f, this.iN + f);
            ao();
        }
    }

    void m(float f) {
        if (this.iA != null) {
            o oVar = this.iA;
            oVar.o(oVar.jv, this.iM + f);
            ao();
        }
    }

    void c(int[] iArr) {
        r$a r_a;
        r rVar = this.iy;
        int size = rVar.jT.size();
        for (int i = 0; i < size; i++) {
            r$a r_a2 = (r$a) rVar.jT.get(i);
            if (StateSet.stateSetMatches(r_a2.jY, iArr)) {
                r_a = r_a2;
                break;
            }
        }
        r_a = null;
        if (r_a != rVar.jU) {
            View aB;
            if (!(rVar.jU == null || rVar.jV == null)) {
                aB = rVar.aB();
                if (aB != null && aB.getAnimation() == rVar.jV) {
                    aB.clearAnimation();
                }
                rVar.jV = null;
            }
            rVar.jU = r_a;
            aB = (View) rVar.fC.get();
            if (r_a != null && aB != null && aB.getVisibility() == 0) {
                rVar.jV = r_a.mAnimation;
                aB = rVar.aB();
                if (aB != null) {
                    aB.startAnimation(rVar.jV);
                }
            }
        }
    }

    void ak() {
        r rVar = this.iy;
        if (rVar.jV != null) {
            View aB = rVar.aB();
            if (aB != null && aB.getAnimation() == rVar.jV) {
                aB.clearAnimation();
            }
        }
    }

    void a(l$a l_a, boolean z) {
        if (!this.iz && this.iP.getVisibility() == 0) {
            Animation loadAnimation = AnimationUtils.loadAnimation(this.iP.getContext(), a$a.bb);
            loadAnimation.setInterpolator(a.eO);
            loadAnimation.setDuration(200);
            loadAnimation.setAnimationListener(new j$1(this, false, l_a));
            this.iP.startAnimation(loadAnimation);
        }
    }

    void b(l$a l_a, boolean z) {
        if (this.iP.getVisibility() != 0 || this.iz) {
            this.iP.clearAnimation();
            this.iP.i(0, false);
            Animation loadAnimation = AnimationUtils.loadAnimation(this.iP.getContext(), a$a.ba);
            loadAnimation.setDuration(200);
            loadAnimation.setInterpolator(a.eP);
            loadAnimation.setAnimationListener(new j$2(this, l_a));
            this.iP.startAnimation(loadAnimation);
        }
    }

    void d(Rect rect) {
        this.iA.getPadding(rect);
    }

    private Animation e(Animation animation) {
        animation.setInterpolator(a.eN);
        animation.setDuration((long) this.ix);
        return animation;
    }
}
