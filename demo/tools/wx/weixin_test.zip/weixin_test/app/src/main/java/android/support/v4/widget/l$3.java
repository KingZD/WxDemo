package android.support.v4.widget;

import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.Callback;

class l$3 implements Callback {
    final /* synthetic */ l CW;

    l$3(l lVar) {
        this.CW = lVar;
    }

    public final void invalidateDrawable(Drawable drawable) {
        this.CW.invalidateSelf();
    }

    public final void scheduleDrawable(Drawable drawable, Runnable runnable, long j) {
        this.CW.scheduleSelf(runnable, j);
    }

    public final void unscheduleDrawable(Drawable drawable, Runnable runnable) {
        this.CW.unscheduleSelf(runnable);
    }
}
