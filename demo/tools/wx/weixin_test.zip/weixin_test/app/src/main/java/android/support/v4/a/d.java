package android.support.v4.a;

public interface d {
    void b(g gVar);
}
