package android.support.v4.media;

import android.support.v4.os.ResultReceiver;

class MediaBrowserServiceCompat$g$5 implements Runnable {
    final /* synthetic */ ResultReceiver uL;
    final /* synthetic */ MediaBrowserServiceCompat$g vb;
    final /* synthetic */ String vd;

    MediaBrowserServiceCompat$g$5(MediaBrowserServiceCompat$g mediaBrowserServiceCompat$g, String str, ResultReceiver resultReceiver) {
        this.vb = mediaBrowserServiceCompat$g;
        this.vd = str;
        this.uL = resultReceiver;
    }

    public final void run() {
        MediaBrowserServiceCompat.a(this.vb.uK, this.vd, this.uL);
    }
}
