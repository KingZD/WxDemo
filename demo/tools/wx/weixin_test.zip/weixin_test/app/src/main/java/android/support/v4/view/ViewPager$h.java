package android.support.v4.view;

public class ViewPager$h implements ViewPager$e {
    public void a(int i, float f, int i2) {
    }

    public void af(int i) {
    }

    public void ag(int i) {
    }
}
