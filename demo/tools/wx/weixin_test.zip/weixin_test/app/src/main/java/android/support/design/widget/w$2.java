package android.support.design.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;

class w$2 extends AnimatorListenerAdapter {
    final /* synthetic */ w lP;
    final /* synthetic */ u$e$a lQ;

    w$2(w wVar, u$e$a u_e_a) {
        this.lP = wVar;
        this.lQ = u_e_a;
    }

    public final void onAnimationStart(Animator animator) {
    }

    public final void onAnimationEnd(Animator animator) {
        this.lQ.onAnimationEnd();
    }

    public final void onAnimationCancel(Animator animator) {
    }
}
