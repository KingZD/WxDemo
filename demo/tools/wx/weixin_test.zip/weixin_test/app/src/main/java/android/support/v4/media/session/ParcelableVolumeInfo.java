package android.support.v4.media.session;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class ParcelableVolumeInfo implements Parcelable {
    public static final Creator<ParcelableVolumeInfo> CREATOR = new ParcelableVolumeInfo$1();
    public int vA;
    public int vB;
    public int vx;
    public int vy;
    public int vz;

    public ParcelableVolumeInfo(Parcel parcel) {
        this.vx = parcel.readInt();
        this.vz = parcel.readInt();
        this.vA = parcel.readInt();
        this.vB = parcel.readInt();
        this.vy = parcel.readInt();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.vx);
        parcel.writeInt(this.vz);
        parcel.writeInt(this.vA);
        parcel.writeInt(this.vB);
        parcel.writeInt(this.vy);
    }
}
