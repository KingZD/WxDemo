package android.support.v4.app;

import android.app.Service;

public abstract class NotificationCompatSideChannelService extends Service {
}
