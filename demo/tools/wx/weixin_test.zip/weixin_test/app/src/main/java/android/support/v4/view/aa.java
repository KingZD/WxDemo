package android.support.v4.view;

import android.view.View;
import java.lang.reflect.Field;

final class aa {
    private static Field yB;
    private static boolean yC;
    private static Field yD;
    private static boolean yE;

    static int S(View view) {
        if (!yC) {
            try {
                Field declaredField = View.class.getDeclaredField("mMinWidth");
                yB = declaredField;
                declaredField.setAccessible(true);
            } catch (NoSuchFieldException e) {
            }
            yC = true;
        }
        if (yB != null) {
            try {
                return ((Integer) yB.get(view)).intValue();
            } catch (Exception e2) {
            }
        }
        return 0;
    }

    static int T(View view) {
        if (!yE) {
            try {
                Field declaredField = View.class.getDeclaredField("mMinHeight");
                yD = declaredField;
                declaredField.setAccessible(true);
            } catch (NoSuchFieldException e) {
            }
            yE = true;
        }
        if (yD != null) {
            try {
                return ((Integer) yD.get(view)).intValue();
            } catch (Exception e2) {
            }
        }
        return 0;
    }
}
