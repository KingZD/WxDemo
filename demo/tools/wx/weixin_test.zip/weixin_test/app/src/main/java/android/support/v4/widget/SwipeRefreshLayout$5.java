package android.support.v4.widget;

import android.view.animation.Animation;
import android.view.animation.Transformation;

class SwipeRefreshLayout$5 extends Animation {
    final /* synthetic */ SwipeRefreshLayout EX;

    SwipeRefreshLayout$5(SwipeRefreshLayout swipeRefreshLayout) {
        this.EX = swipeRefreshLayout;
    }

    public final void applyTransformation(float f, Transformation transformation) {
        int j;
        if (SwipeRefreshLayout.i(this.EX)) {
            j = (int) SwipeRefreshLayout.j(this.EX);
        } else {
            j = (int) (SwipeRefreshLayout.j(this.EX) - ((float) Math.abs(this.EX.EJ)));
        }
        SwipeRefreshLayout.b(this.EX, (((int) (((float) (j - this.EX.EH)) * f)) + this.EX.EH) - SwipeRefreshLayout.e(this.EX).getTop());
        SwipeRefreshLayout.b(this.EX).A(1.0f - f);
    }
}
