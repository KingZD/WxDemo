package android.support.design.internal;

import android.support.v7.widget.RecyclerView$t;
import android.view.View;

abstract class b$j extends RecyclerView$t {
    public b$j(View view) {
        super(view);
    }
}
