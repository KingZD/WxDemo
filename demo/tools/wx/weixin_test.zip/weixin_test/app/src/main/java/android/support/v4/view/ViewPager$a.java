package android.support.v4.view;

interface ViewPager$a {
}
