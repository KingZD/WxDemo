package android.support.v4.app;

class ag$a implements ag$i {
    final int id;
    final String packageName;
    final String tag = null;
    final boolean tk = false;

    public ag$a(String str, int i, String str2) {
        this.packageName = str;
        this.id = i;
    }

    public final void a(s sVar) {
        if (this.tk) {
            sVar.t(this.packageName);
        } else {
            sVar.b(this.packageName, this.id, this.tag);
        }
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("CancelTask[");
        stringBuilder.append("packageName:").append(this.packageName);
        stringBuilder.append(", id:").append(this.id);
        stringBuilder.append(", tag:").append(this.tag);
        stringBuilder.append(", all:").append(this.tk);
        stringBuilder.append("]");
        return stringBuilder.toString();
    }
}
