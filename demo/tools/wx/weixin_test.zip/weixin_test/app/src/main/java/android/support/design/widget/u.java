package android.support.design.widget;

import android.view.animation.Interpolator;

final class u {
    final u$e lD;

    interface a {
        void aE();
    }

    u(u$e u_e) {
        this.lD = u_e;
    }

    public final void setInterpolator(Interpolator interpolator) {
        this.lD.setInterpolator(interpolator);
    }

    public final void a(final u$c u_c) {
        this.lD.a(new u$e$b(this) {
            final /* synthetic */ u lF;

            public final void aI() {
                u_c.a(this.lF);
            }
        });
    }

    public final void i(int i, int i2) {
        this.lD.i(i, i2);
    }

    public final void p(float f, float f2) {
        this.lD.p(f, f2);
    }

    public final void setDuration(int i) {
        this.lD.setDuration(i);
    }
}
