package android.support.v4.media;

public class MediaBrowserServiceCompat$c<T> {
    int uC;
    Object uS;
    private boolean uT;
    boolean uU;

    MediaBrowserServiceCompat$c(Object obj) {
        this.uS = obj;
    }

    final boolean isDone() {
        return this.uT || this.uU;
    }

    void b(T t, int i) {
    }
}
