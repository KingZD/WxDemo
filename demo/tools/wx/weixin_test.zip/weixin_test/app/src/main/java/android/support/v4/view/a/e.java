package android.support.v4.view.a;

import android.os.Bundle;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeProvider;
import java.util.List;

final class e {

    /* renamed from: android.support.v4.view.a.e$1 */
    static class AnonymousClass1 extends AccessibilityNodeProvider {
        final /* synthetic */ a AL;

        AnonymousClass1(a aVar) {
            this.AL = aVar;
        }

        public final AccessibilityNodeInfo createAccessibilityNodeInfo(int i) {
            this.AL.cs();
            return null;
        }

        public final List<AccessibilityNodeInfo> findAccessibilityNodeInfosByText(String str, int i) {
            return this.AL.cq();
        }

        public final boolean performAction(int i, int i2, Bundle bundle) {
            return this.AL.cp();
        }

        public final AccessibilityNodeInfo findFocus(int i) {
            this.AL.ct();
            return null;
        }
    }

    interface a {
        boolean cp();

        List<Object> cq();

        Object cs();

        Object ct();
    }
}
