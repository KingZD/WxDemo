package android.support.design.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;

class k$1 extends AnimatorListenerAdapter {
    final /* synthetic */ boolean iB;
    final /* synthetic */ l$a iC;
    private boolean iG;
    final /* synthetic */ k iH;

    k$1(k kVar, boolean z, l$a l_a) {
        this.iH = kVar;
        this.iB = z;
        this.iC = l_a;
    }

    public final void onAnimationStart(Animator animator) {
        k.a(this.iH, true);
        this.iG = false;
        this.iH.iP.i(0, this.iB);
    }

    public final void onAnimationCancel(Animator animator) {
        k.a(this.iH, false);
        this.iG = true;
    }

    public final void onAnimationEnd(Animator animator) {
        k.a(this.iH, false);
        if (!this.iG) {
            this.iH.iP.i(8, this.iB);
        }
    }
}
