package android.support.design.widget;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.support.design.a$c;
import android.view.ViewTreeObserver.OnPreDrawListener;

abstract class l {
    static final int[] EMPTY_STATE_SET = new int[0];
    static final int[] PRESSED_ENABLED_STATE_SET = new int[]{16842919, 16842910};
    static final int[] iO = new int[]{16842908, 16842910};
    private final Rect ha = new Rect();
    Drawable iI;
    Drawable iJ;
    d iK;
    Drawable iL;
    float iM;
    float iN;
    final VisibilityAwareImageButton iP;
    final p iQ;
    OnPreDrawListener iR;

    abstract void a(ColorStateList colorStateList, Mode mode, int i, int i2);

    abstract void a(l$a l_a, boolean z);

    abstract void ak();

    abstract void b(l$a l_a, boolean z);

    abstract void c(int[] iArr);

    abstract void d(Rect rect);

    abstract void l(float f);

    abstract void m(float f);

    abstract void setBackgroundTintList(ColorStateList colorStateList);

    abstract void setBackgroundTintMode(Mode mode);

    l(VisibilityAwareImageButton visibilityAwareImageButton, p pVar) {
        this.iP = visibilityAwareImageButton;
        this.iQ = pVar;
    }

    final void ao() {
        Rect rect = this.ha;
        d(rect);
        e(rect);
        this.iQ.d(rect.left, rect.top, rect.right, rect.bottom);
    }

    void e(Rect rect) {
    }

    boolean am() {
        return false;
    }

    final d a(int i, ColorStateList colorStateList) {
        Resources resources = this.iP.getResources();
        d ap = ap();
        int color = resources.getColor(a$c.bl);
        int color2 = resources.getColor(a$c.bk);
        int color3 = resources.getColor(a$c.bi);
        int color4 = resources.getColor(a$c.bj);
        ap.fS = color;
        ap.fT = color2;
        ap.fU = color3;
        ap.fV = color4;
        float f = (float) i;
        if (ap.fR != f) {
            ap.fR = f;
            ap.fO.setStrokeWidth(f * 1.3333f);
            ap.fY = true;
            ap.invalidateSelf();
        }
        ap.c(colorStateList);
        return ap;
    }

    d ap() {
        return new d();
    }

    void an() {
    }

    static GradientDrawable aq() {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(1);
        gradientDrawable.setColor(-1);
        return gradientDrawable;
    }
}
