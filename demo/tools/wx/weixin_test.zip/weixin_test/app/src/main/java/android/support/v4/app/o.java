package android.support.v4.app;

import android.os.Parcelable;
import android.support.v4.view.u;
import android.view.View;
import android.view.ViewGroup;

public abstract class o extends u {
    private final m rj;
    private q rk = null;
    private Fragment rl = null;

    public abstract Fragment S(int i);

    public o(m mVar) {
        this.rj = mVar;
    }

    public final Object b(ViewGroup viewGroup, int i) {
        if (this.rk == null) {
            this.rk = this.rj.bd();
        }
        long j = (long) i;
        Fragment s = this.rj.s(b(viewGroup.getId(), j));
        if (s != null) {
            this.rk.d(s);
        } else {
            s = S(i);
            this.rk.a(viewGroup.getId(), s, b(viewGroup.getId(), j));
        }
        if (s != this.rl) {
            s.setMenuVisibility(false);
            s.setUserVisibleHint(false);
        }
        return s;
    }

    public final void a(ViewGroup viewGroup, int i, Object obj) {
        if (this.rk == null) {
            this.rk = this.rj.bd();
        }
        this.rk.c((Fragment) obj);
    }

    public final void e(Object obj) {
        Fragment fragment = (Fragment) obj;
        if (fragment != this.rl) {
            if (this.rl != null) {
                this.rl.setMenuVisibility(false);
                this.rl.setUserVisibleHint(false);
            }
            if (fragment != null) {
                fragment.setMenuVisibility(true);
                fragment.setUserVisibleHint(true);
            }
            this.rl = fragment;
        }
    }

    public final void bi() {
        if (this.rk != null) {
            this.rk.commitAllowingStateLoss();
            this.rk = null;
            this.rj.executePendingTransactions();
        }
    }

    public final boolean a(View view, Object obj) {
        return ((Fragment) obj).getView() == view;
    }

    public final Parcelable bj() {
        return null;
    }

    public final void a(Parcelable parcelable, ClassLoader classLoader) {
    }

    private static String b(int i, long j) {
        return "android:switcher:" + i + ":" + j;
    }
}
