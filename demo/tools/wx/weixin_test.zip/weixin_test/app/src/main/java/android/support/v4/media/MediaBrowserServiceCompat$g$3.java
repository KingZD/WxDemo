package android.support.v4.media;

import android.os.Bundle;

class MediaBrowserServiceCompat$g$3 implements Runnable {
    final /* synthetic */ Bundle uJ;
    final /* synthetic */ MediaBrowserServiceCompat$d uX;
    final /* synthetic */ MediaBrowserServiceCompat$g vb;
    final /* synthetic */ String vc;

    MediaBrowserServiceCompat$g$3(MediaBrowserServiceCompat$g mediaBrowserServiceCompat$g, MediaBrowserServiceCompat$d mediaBrowserServiceCompat$d, String str, Bundle bundle) {
        this.vb = mediaBrowserServiceCompat$g;
        this.uX = mediaBrowserServiceCompat$d;
        this.vc = str;
        this.uJ = bundle;
    }

    public final void run() {
        MediaBrowserServiceCompat$b mediaBrowserServiceCompat$b = (MediaBrowserServiceCompat$b) MediaBrowserServiceCompat.b(this.vb.uK).get(this.uX.asBinder());
        if (mediaBrowserServiceCompat$b == null) {
            new StringBuilder("addSubscription for callback that isn't registered id=").append(this.vc);
        } else {
            MediaBrowserServiceCompat.a(this.vb.uK, this.vc, mediaBrowserServiceCompat$b, this.uJ);
        }
    }
}
