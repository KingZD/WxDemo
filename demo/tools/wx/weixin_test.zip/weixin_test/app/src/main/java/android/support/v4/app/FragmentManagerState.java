package android.support.v4.app;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

final class FragmentManagerState implements Parcelable {
    public static final Creator<FragmentManagerState> CREATOR = new Creator<FragmentManagerState>() {
        public final /* synthetic */ Object createFromParcel(Parcel parcel) {
            return new FragmentManagerState(parcel);
        }

        public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
            return new FragmentManagerState[i];
        }
    };
    FragmentState[] rg;
    int[] rh;
    BackStackState[] ri;

    public FragmentManagerState(Parcel parcel) {
        this.rg = (FragmentState[]) parcel.createTypedArray(FragmentState.CREATOR);
        this.rh = parcel.createIntArray();
        this.ri = (BackStackState[]) parcel.createTypedArray(BackStackState.CREATOR);
    }

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeTypedArray(this.rg, i);
        parcel.writeIntArray(this.rh);
        parcel.writeTypedArray(this.ri, i);
    }
}
