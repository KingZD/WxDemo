package android.support.v4.d;

public interface d {
    boolean a(CharSequence charSequence, int i);
}
