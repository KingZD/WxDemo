package android.support.b;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

class a$c {
    public final int format;
    public final int oH;
    public final byte[] oI;

    a$c(int i, int i2, byte[] bArr) {
        this.format = i;
        this.oH = i2;
        this.oI = bArr;
    }

    public static a$c a(int[] iArr, ByteOrder byteOrder) {
        ByteBuffer wrap = ByteBuffer.wrap(new byte[(a.aR()[3] * iArr.length)]);
        wrap.order(byteOrder);
        for (int i : iArr) {
            wrap.putShort((short) i);
        }
        return new a$c(3, iArr.length, wrap.array());
    }

    public static a$c a(int i, ByteOrder byteOrder) {
        return a(new int[]{i}, byteOrder);
    }

    public static a$c a(long[] jArr, ByteOrder byteOrder) {
        ByteBuffer wrap = ByteBuffer.wrap(new byte[(a.aR()[4] * jArr.length)]);
        wrap.order(byteOrder);
        for (long j : jArr) {
            wrap.putInt((int) j);
        }
        return new a$c(4, jArr.length, wrap.array());
    }

    public static a$c a(long j, ByteOrder byteOrder) {
        return a(new long[]{j}, byteOrder);
    }

    public static a$c b(int[] iArr, ByteOrder byteOrder) {
        ByteBuffer wrap = ByteBuffer.wrap(new byte[(a.aR()[9] * iArr.length)]);
        wrap.order(byteOrder);
        for (int putInt : iArr) {
            wrap.putInt(putInt);
        }
        return new a$c(9, iArr.length, wrap.array());
    }

    public static a$c n(String str) {
        byte[] bytes = (str + '\u0000').getBytes(a.aS());
        return new a$c(2, bytes.length, bytes);
    }

    public static a$c a(a$e[] a_eArr, ByteOrder byteOrder) {
        ByteBuffer wrap = ByteBuffer.wrap(new byte[(a.aR()[5] * a_eArr.length)]);
        wrap.order(byteOrder);
        for (a$e a_e : a_eArr) {
            wrap.putInt((int) a_e.oL);
            wrap.putInt((int) a_e.oM);
        }
        return new a$c(5, a_eArr.length, wrap.array());
    }

    public static a$c a(a$e a_e, ByteOrder byteOrder) {
        return a(new a$e[]{a_e}, byteOrder);
    }

    public static a$c b(a$e[] a_eArr, ByteOrder byteOrder) {
        ByteBuffer wrap = ByteBuffer.wrap(new byte[(a.aR()[10] * a_eArr.length)]);
        wrap.order(byteOrder);
        for (a$e a_e : a_eArr) {
            wrap.putInt((int) a_e.oL);
            wrap.putInt((int) a_e.oM);
        }
        return new a$c(10, a_eArr.length, wrap.array());
    }

    public static a$c a(double[] dArr, ByteOrder byteOrder) {
        ByteBuffer wrap = ByteBuffer.wrap(new byte[(a.aR()[12] * dArr.length)]);
        wrap.order(byteOrder);
        for (double putDouble : dArr) {
            wrap.putDouble(putDouble);
        }
        return new a$c(12, dArr.length, wrap.array());
    }

    public final String toString() {
        return "(" + a.aT()[this.format] + ", data length:" + this.oI.length + ")";
    }

    final Object a(ByteOrder byteOrder) {
        a$a a_a;
        Throwable th;
        int i = 1;
        int i2 = 0;
        a$a a_a2;
        try {
            a_a2 = new a$a(this.oI);
            try {
                a_a2.oF = byteOrder;
                Object str;
                int i3;
                switch (this.format) {
                    case 1:
                    case 6:
                        if (this.oI.length != 1 || this.oI[0] < (byte) 0 || this.oI[0] > (byte) 1) {
                            str = new String(this.oI, a.aS());
                            try {
                                a_a2.close();
                                return str;
                            } catch (IOException e) {
                                return str;
                            }
                        }
                        str = new String(new char[]{(char) (this.oI[0] + 48)});
                        try {
                            a_a2.close();
                            return str;
                        } catch (IOException e2) {
                            return str;
                        }
                    case 2:
                    case 7:
                        StringBuilder stringBuilder;
                        byte b;
                        if (this.oH >= a.aU().length) {
                            for (int i4 = 0; i4 < a.aU().length; i4++) {
                                if (this.oI[i4] != a.aU()[i4]) {
                                    i = 0;
                                    if (i != 0) {
                                        i = a.aU().length;
                                        stringBuilder = new StringBuilder();
                                        while (i < this.oH) {
                                            b = this.oI[i];
                                            if (b != (byte) 0) {
                                                if (b >= (byte) 32) {
                                                    stringBuilder.append((char) b);
                                                } else {
                                                    stringBuilder.append('?');
                                                }
                                                i++;
                                            }
                                        }
                                        str = stringBuilder.toString();
                                        a_a2.close();
                                        return str;
                                    }
                                }
                            }
                            if (i != 0) {
                                i = a.aU().length;
                                stringBuilder = new StringBuilder();
                                while (i < this.oH) {
                                    b = this.oI[i];
                                    if (b != (byte) 0) {
                                        if (b >= (byte) 32) {
                                            stringBuilder.append('?');
                                        } else {
                                            stringBuilder.append((char) b);
                                        }
                                        i++;
                                    }
                                }
                                str = stringBuilder.toString();
                                a_a2.close();
                                return str;
                            }
                        }
                        i = 0;
                        stringBuilder = new StringBuilder();
                        while (i < this.oH) {
                            b = this.oI[i];
                            if (b != (byte) 0) {
                                if (b >= (byte) 32) {
                                    stringBuilder.append((char) b);
                                } else {
                                    stringBuilder.append('?');
                                }
                                i++;
                            }
                        }
                        str = stringBuilder.toString();
                        try {
                            a_a2.close();
                            return str;
                        } catch (IOException e3) {
                            return str;
                        }
                    case 3:
                        str = new int[this.oH];
                        while (i2 < this.oH) {
                            str[i2] = a_a2.readUnsignedShort();
                            i2++;
                        }
                        try {
                            a_a2.close();
                            return str;
                        } catch (IOException e4) {
                            return str;
                        }
                    case 4:
                        str = new long[this.oH];
                        while (i2 < this.oH) {
                            str[i2] = a_a2.aV();
                            i2++;
                        }
                        try {
                            a_a2.close();
                            return str;
                        } catch (IOException e5) {
                            return str;
                        }
                    case 5:
                        str = new a$e[this.oH];
                        for (i3 = 0; i3 < this.oH; i3++) {
                            str[i3] = new a$e(a_a2.aV(), a_a2.aV(), (byte) 0);
                        }
                        try {
                            a_a2.close();
                            return str;
                        } catch (IOException e6) {
                            return str;
                        }
                    case 8:
                        str = new int[this.oH];
                        while (i2 < this.oH) {
                            str[i2] = a_a2.readShort();
                            i2++;
                        }
                        try {
                            a_a2.close();
                            return str;
                        } catch (IOException e7) {
                            return str;
                        }
                    case 9:
                        str = new int[this.oH];
                        while (i2 < this.oH) {
                            str[i2] = a_a2.readInt();
                            i2++;
                        }
                        try {
                            a_a2.close();
                            return str;
                        } catch (IOException e8) {
                            return str;
                        }
                    case 10:
                        str = new a$e[this.oH];
                        for (i3 = 0; i3 < this.oH; i3++) {
                            str[i3] = new a$e((long) a_a2.readInt(), (long) a_a2.readInt(), (byte) 0);
                        }
                        try {
                            a_a2.close();
                            return str;
                        } catch (IOException e9) {
                            return str;
                        }
                    case 11:
                        str = new double[this.oH];
                        while (i2 < this.oH) {
                            str[i2] = (double) a_a2.readFloat();
                            i2++;
                        }
                        try {
                            a_a2.close();
                            return str;
                        } catch (IOException e10) {
                            return str;
                        }
                    case 12:
                        str = new double[this.oH];
                        while (i2 < this.oH) {
                            str[i2] = a_a2.readDouble();
                            i2++;
                        }
                        try {
                            a_a2.close();
                            return str;
                        } catch (IOException e11) {
                            return str;
                        }
                    default:
                        try {
                            a_a2.close();
                        } catch (IOException e12) {
                        }
                        return null;
                }
            } catch (IOException e13) {
                a_a = a_a2;
                if (a_a != null) {
                    try {
                        a_a.close();
                    } catch (IOException e14) {
                    }
                }
                return null;
            } catch (Throwable th2) {
                th = th2;
                if (a_a2 != null) {
                    try {
                        a_a2.close();
                    } catch (IOException e15) {
                    }
                }
                throw th;
            }
        } catch (IOException e16) {
            a_a = null;
            if (a_a != null) {
                a_a.close();
            }
            return null;
        } catch (Throwable th3) {
            th = th3;
            a_a2 = null;
            if (a_a2 != null) {
                a_a2.close();
            }
            throw th;
        }
    }

    public final int b(ByteOrder byteOrder) {
        Object a = a(byteOrder);
        if (a == null) {
            throw new NumberFormatException("NULL can't be converted to a integer value");
        } else if (a instanceof String) {
            return Integer.parseInt((String) a);
        } else {
            if (a instanceof long[]) {
                long[] jArr = (long[]) a;
                if (jArr.length == 1) {
                    return (int) jArr[0];
                }
                throw new NumberFormatException("There are more than one component");
            } else if (a instanceof int[]) {
                int[] iArr = (int[]) a;
                if (iArr.length == 1) {
                    return iArr[0];
                }
                throw new NumberFormatException("There are more than one component");
            } else {
                throw new NumberFormatException("Couldn't find a integer value");
            }
        }
    }

    public final String c(ByteOrder byteOrder) {
        int i = 0;
        Object a = a(byteOrder);
        if (a == null) {
            return null;
        }
        if (a instanceof String) {
            return (String) a;
        }
        StringBuilder stringBuilder = new StringBuilder();
        if (a instanceof long[]) {
            long[] jArr = (long[]) a;
            while (i < jArr.length) {
                stringBuilder.append(jArr[i]);
                if (i + 1 != jArr.length) {
                    stringBuilder.append(",");
                }
                i++;
            }
            return stringBuilder.toString();
        } else if (a instanceof int[]) {
            int[] iArr = (int[]) a;
            while (i < iArr.length) {
                stringBuilder.append(iArr[i]);
                if (i + 1 != iArr.length) {
                    stringBuilder.append(",");
                }
                i++;
            }
            return stringBuilder.toString();
        } else if (a instanceof double[]) {
            double[] dArr = (double[]) a;
            while (i < dArr.length) {
                stringBuilder.append(dArr[i]);
                if (i + 1 != dArr.length) {
                    stringBuilder.append(",");
                }
                i++;
            }
            return stringBuilder.toString();
        } else if (!(a instanceof a$e[])) {
            return null;
        } else {
            a$e[] a_eArr = (a$e[]) a;
            while (i < a_eArr.length) {
                stringBuilder.append(a_eArr[i].oL);
                stringBuilder.append('/');
                stringBuilder.append(a_eArr[i].oM);
                if (i + 1 != a_eArr.length) {
                    stringBuilder.append(",");
                }
                i++;
            }
            return stringBuilder.toString();
        }
    }

    public final int size() {
        return a.aR()[this.format] * this.oH;
    }
}
