package android.support.design.widget;

import android.support.design.widget.u.a;

class u$2 implements u$e$a {
    final /* synthetic */ u lF;
    final /* synthetic */ a lG;

    u$2(u uVar, a aVar) {
        this.lF = uVar;
        this.lG = aVar;
    }

    public final void onAnimationEnd() {
        this.lG.aE();
    }
}
