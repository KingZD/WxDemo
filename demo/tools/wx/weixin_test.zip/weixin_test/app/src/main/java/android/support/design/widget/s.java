package android.support.design.widget;

import android.support.design.widget.CoordinatorLayout.Behavior;
import android.support.v4.view.o;
import android.support.v4.view.z;
import android.support.v4.widget.u;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewParent;

public class s<V extends View> extends Behavior<V> {
    private final android.support.v4.widget.u.a fJ = new android.support.v4.widget.u.a(this) {
        private int fG = -1;
        private int kg;
        final /* synthetic */ s kh;

        {
            this.kh = r2;
        }

        public final boolean b(View view, int i) {
            return this.fG == -1 && this.kh.r(view);
        }

        public final void f(View view, int i) {
            this.fG = i;
            this.kg = view.getLeft();
            ViewParent parent = view.getParent();
            if (parent != null) {
                parent.requestDisallowInterceptTouchEvent(true);
            }
        }

        public final void u(int i) {
            if (this.kh.jZ != null) {
                this.kh.jZ.H(i);
            }
        }

        public final void a(View view, float f, float f2) {
            boolean z;
            int i;
            boolean z2 = true;
            this.fG = -1;
            int width = view.getWidth();
            if (f != 0.0f) {
                z = z.I(view) == 1;
                z = this.kh.kc == 2 ? true : this.kh.kc == 0 ? z ? f < 0.0f : f > 0.0f : this.kh.kc == 1 ? z ? f > 0.0f : f < 0.0f : false;
            } else {
                z = Math.abs(view.getLeft() - this.kg) >= Math.round(((float) view.getWidth()) * this.kh.kd);
            }
            if (z) {
                i = view.getLeft() < this.kg ? this.kg - width : this.kg + width;
            } else {
                i = this.kg;
                z2 = false;
            }
            if (this.kh.fx.v(i, view.getTop())) {
                z.a(view, new s$b(this.kh, view, z2));
            } else if (z2 && this.kh.jZ != null) {
                this.kh.jZ.onDismiss(view);
            }
        }

        public final int s(View view) {
            return view.getWidth();
        }

        public final int d(View view, int i) {
            int width;
            int i2;
            Object obj = z.I(view) == 1 ? 1 : null;
            if (this.kh.kc == 0) {
                if (obj != null) {
                    width = this.kg - view.getWidth();
                    i2 = this.kg;
                } else {
                    width = this.kg;
                    i2 = this.kg + view.getWidth();
                }
            } else if (this.kh.kc != 1) {
                width = this.kg - view.getWidth();
                i2 = this.kg + view.getWidth();
            } else if (obj != null) {
                width = this.kg;
                i2 = this.kg + view.getWidth();
            } else {
                width = this.kg - view.getWidth();
                i2 = this.kg;
            }
            return Math.min(Math.max(width, i), i2);
        }

        public final int c(View view, int i) {
            return view.getTop();
        }

        public final void a(View view, int i, int i2) {
            float width = ((float) this.kg) + (((float) view.getWidth()) * this.kh.ke);
            float width2 = ((float) this.kg) + (((float) view.getWidth()) * this.kh.kf);
            if (((float) i) <= width) {
                z.d(view, 1.0f);
            } else if (((float) i) >= width2) {
                z.d(view, 0.0f);
            } else {
                z.d(view, s.c(0.0f, 1.0f - s.d(width, width2, (float) i), 1.0f));
            }
        }
    };
    private u fx;
    private boolean fy;
    a jZ;
    private float ka = 0.0f;
    private boolean kb;
    int kc = 2;
    private float kd = 0.5f;
    float ke = 0.0f;
    float kf = 0.5f;

    public interface a {
        void H(int i);

        void onDismiss(View view);
    }

    public boolean a(CoordinatorLayout coordinatorLayout, V v, MotionEvent motionEvent) {
        switch (o.d(motionEvent)) {
            case 1:
            case 3:
                if (this.fy) {
                    this.fy = false;
                    return false;
                }
                break;
            default:
                boolean z;
                if (coordinatorLayout.b(v, (int) motionEvent.getX(), (int) motionEvent.getY())) {
                    z = false;
                } else {
                    z = true;
                }
                this.fy = z;
                break;
        }
        if (this.fy) {
            return false;
        }
        if (this.fx == null) {
            u a;
            if (this.kb) {
                a = u.a(coordinatorLayout, this.ka, this.fJ);
            } else {
                a = u.a(coordinatorLayout, this.fJ);
            }
            this.fx = a;
        }
        return this.fx.j(motionEvent);
    }

    public final boolean b(CoordinatorLayout coordinatorLayout, V v, MotionEvent motionEvent) {
        if (this.fx == null) {
            return false;
        }
        this.fx.k(motionEvent);
        return true;
    }

    public boolean r(View view) {
        return true;
    }

    static float c(float f, float f2, float f3) {
        return Math.min(Math.max(0.0f, f2), 1.0f);
    }

    static float d(float f, float f2, float f3) {
        return (f3 - f) / (f2 - f);
    }
}
