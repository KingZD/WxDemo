package android.support.design.widget;

import android.view.View;
import android.view.ViewOutlineProvider;

class aa$c implements aa$a {
    private aa$c() {
    }

    public final void u(View view) {
        view.setOutlineProvider(ViewOutlineProvider.BOUNDS);
    }
}
