package android.support.v4.view;

public interface ViewPager$e {
    void a(int i, float f, int i2);

    void af(int i);

    void ag(int i);
}
