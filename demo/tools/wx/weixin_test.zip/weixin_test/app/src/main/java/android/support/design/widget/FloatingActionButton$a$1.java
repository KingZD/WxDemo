package android.support.design.widget;

import android.support.v4.view.z;

class FloatingActionButton$a$1 implements u$c {
    final /* synthetic */ FloatingActionButton it;
    final /* synthetic */ FloatingActionButton$a iu;

    FloatingActionButton$a$1(FloatingActionButton$a floatingActionButton$a, FloatingActionButton floatingActionButton) {
        this.iu = floatingActionButton$a;
        this.it = floatingActionButton;
    }

    public final void a(u uVar) {
        z.c(this.it, uVar.lD.aL());
    }
}
