package android.support.v4.media;

import android.os.Bundle;
import android.os.IBinder;

class MediaBrowserServiceCompat$g {
    final /* synthetic */ MediaBrowserServiceCompat uK;

    /* renamed from: android.support.v4.media.MediaBrowserServiceCompat$g$4 */
    class AnonymousClass4 implements Runnable {
        final /* synthetic */ Bundle uJ;
        final /* synthetic */ MediaBrowserServiceCompat$d uX;
        final /* synthetic */ MediaBrowserServiceCompat$g vb;
        final /* synthetic */ String vc;

        AnonymousClass4(MediaBrowserServiceCompat$g mediaBrowserServiceCompat$g, MediaBrowserServiceCompat$d mediaBrowserServiceCompat$d, String str, Bundle bundle) {
            this.vb = mediaBrowserServiceCompat$g;
            this.uX = mediaBrowserServiceCompat$d;
            this.vc = str;
            this.uJ = bundle;
        }

        public final void run() {
            MediaBrowserServiceCompat$b mediaBrowserServiceCompat$b = (MediaBrowserServiceCompat$b) MediaBrowserServiceCompat.b(this.vb.uK).get(this.uX.asBinder());
            if (mediaBrowserServiceCompat$b == null) {
                new StringBuilder("removeSubscription for callback that isn't registered id=").append(this.vc);
            } else if (!MediaBrowserServiceCompat.a(this.vc, mediaBrowserServiceCompat$b, this.uJ)) {
                new StringBuilder("removeSubscription called for ").append(this.vc).append(" which is not subscribed");
            }
        }
    }

    /* renamed from: android.support.v4.media.MediaBrowserServiceCompat$g$6 */
    class AnonymousClass6 implements Runnable {
        final /* synthetic */ MediaBrowserServiceCompat$d uX;
        final /* synthetic */ MediaBrowserServiceCompat$g vb;

        AnonymousClass6(MediaBrowserServiceCompat$g mediaBrowserServiceCompat$g, MediaBrowserServiceCompat$d mediaBrowserServiceCompat$d) {
            this.vb = mediaBrowserServiceCompat$g;
            this.uX = mediaBrowserServiceCompat$d;
        }

        public final void run() {
            IBinder asBinder = this.uX.asBinder();
            MediaBrowserServiceCompat.b(this.vb.uK).remove(asBinder);
            MediaBrowserServiceCompat$b mediaBrowserServiceCompat$b = new MediaBrowserServiceCompat$b(this.vb.uK);
            mediaBrowserServiceCompat$b.uP = this.uX;
            MediaBrowserServiceCompat.b(this.vb.uK).put(asBinder, mediaBrowserServiceCompat$b);
        }
    }

    private MediaBrowserServiceCompat$g(MediaBrowserServiceCompat mediaBrowserServiceCompat) {
        this.uK = mediaBrowserServiceCompat;
    }
}
