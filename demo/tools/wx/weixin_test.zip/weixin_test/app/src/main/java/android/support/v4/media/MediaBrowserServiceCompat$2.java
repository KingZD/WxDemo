package android.support.v4.media;

import android.os.Bundle;
import android.os.RemoteException;
import android.support.v4.os.ResultReceiver;
import android.support.v4.os.ResultReceiver$b;

class MediaBrowserServiceCompat$2 extends MediaBrowserServiceCompat$c<MediaBrowserCompat$MediaItem> {
    final /* synthetic */ MediaBrowserServiceCompat uK;
    final /* synthetic */ ResultReceiver uL;

    MediaBrowserServiceCompat$2(MediaBrowserServiceCompat mediaBrowserServiceCompat, Object obj, ResultReceiver resultReceiver) {
        this.uK = mediaBrowserServiceCompat;
        this.uL = resultReceiver;
        super(obj);
    }

    final /* synthetic */ void b(Object obj, int i) {
        Bundle bundle = new Bundle();
        bundle.putParcelable("media_item", null);
        ResultReceiver resultReceiver = this.uL;
        if (resultReceiver.vO) {
            if (resultReceiver.mHandler != null) {
                resultReceiver.mHandler.post(new ResultReceiver$b(resultReceiver, 0, bundle));
            } else {
                resultReceiver.onReceiveResult(0, bundle);
            }
        } else if (resultReceiver.vP != null) {
            try {
                resultReceiver.vP.send(0, bundle);
            } catch (RemoteException e) {
            }
        }
    }
}
