package android.support.design.widget;

import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader.TileMode;
import android.graphics.drawable.Drawable;
import android.support.v4.b.b;

class d extends Drawable {
    final Paint fO = new Paint(1);
    final Rect fP = new Rect();
    final RectF fQ = new RectF();
    float fR;
    int fS;
    int fT;
    int fU;
    int fV;
    private ColorStateList fW;
    private int fX;
    boolean fY = true;
    float fZ;

    public d() {
        this.fO.setStyle(Style.STROKE);
    }

    public void draw(Canvas canvas) {
        float height;
        if (this.fY) {
            Paint paint = this.fO;
            Rect rect = this.fP;
            copyBounds(rect);
            height = this.fR / ((float) rect.height());
            float f = 0.0f;
            paint.setShader(new LinearGradient(0.0f, (float) rect.top, f, (float) rect.bottom, new int[]{b.n(this.fS, this.fX), b.n(this.fT, this.fX), b.n(b.o(this.fT, 0), this.fX), b.n(b.o(this.fV, 0), this.fX), b.n(this.fV, this.fX), b.n(this.fU, this.fX)}, new float[]{0.0f, height, 0.5f, 0.5f, 1.0f - height, 1.0f}, TileMode.CLAMP));
            this.fY = false;
        }
        height = this.fO.getStrokeWidth() / 2.0f;
        RectF rectF = this.fQ;
        copyBounds(this.fP);
        rectF.set(this.fP);
        rectF.left += height;
        rectF.top += height;
        rectF.right -= height;
        rectF.bottom -= height;
        canvas.save();
        canvas.rotate(this.fZ, rectF.centerX(), rectF.centerY());
        canvas.drawOval(rectF, this.fO);
        canvas.restore();
    }

    public boolean getPadding(Rect rect) {
        int round = Math.round(this.fR);
        rect.set(round, round, round, round);
        return true;
    }

    public void setAlpha(int i) {
        this.fO.setAlpha(i);
        invalidateSelf();
    }

    final void c(ColorStateList colorStateList) {
        if (colorStateList != null) {
            this.fX = colorStateList.getColorForState(getState(), this.fX);
        }
        this.fW = colorStateList;
        this.fY = true;
        invalidateSelf();
    }

    public void setColorFilter(ColorFilter colorFilter) {
        this.fO.setColorFilter(colorFilter);
        invalidateSelf();
    }

    public int getOpacity() {
        return this.fR > 0.0f ? -3 : -2;
    }

    protected void onBoundsChange(Rect rect) {
        this.fY = true;
    }

    public boolean isStateful() {
        return (this.fW != null && this.fW.isStateful()) || super.isStateful();
    }

    protected boolean onStateChange(int[] iArr) {
        if (this.fW != null) {
            int colorForState = this.fW.getColorForState(iArr, this.fX);
            if (colorForState != this.fX) {
                this.fY = true;
                this.fX = colorForState;
            }
        }
        if (this.fY) {
            invalidateSelf();
        }
        return this.fY;
    }
}
