package android.support.design.internal;

import android.graphics.Rect;
import android.support.v4.view.ap;
import android.support.v4.view.t;
import android.support.v4.view.z;
import android.view.View;

class ScrimInsetsFrameLayout$1 implements t {
    final /* synthetic */ ScrimInsetsFrameLayout eL;

    ScrimInsetsFrameLayout$1(ScrimInsetsFrameLayout scrimInsetsFrameLayout) {
        this.eL = scrimInsetsFrameLayout;
    }

    public final ap a(View view, ap apVar) {
        if (ScrimInsetsFrameLayout.a(this.eL) == null) {
            ScrimInsetsFrameLayout.a(this.eL, new Rect());
        }
        ScrimInsetsFrameLayout.a(this.eL).set(apVar.getSystemWindowInsetLeft(), apVar.getSystemWindowInsetTop(), apVar.getSystemWindowInsetRight(), apVar.getSystemWindowInsetBottom());
        this.eL.c(ScrimInsetsFrameLayout.a(this.eL));
        ScrimInsetsFrameLayout scrimInsetsFrameLayout = this.eL;
        boolean z = ScrimInsetsFrameLayout.a(this.eL).isEmpty() || ScrimInsetsFrameLayout.b(this.eL) == null;
        scrimInsetsFrameLayout.setWillNotDraw(z);
        z.E(this.eL);
        return apVar.cm();
    }
}
