package android.support.v4.media.session;

public final class a {
    public final a vt;

    interface a {
        Object bH();
    }
}
