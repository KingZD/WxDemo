package android.support.v4.a;

import android.animation.Animator;
import android.animation.Animator.AnimatorListener;

class f$a implements AnimatorListener {
    final b pc;
    final g pd;

    public f$a(b bVar, g gVar) {
        this.pc = bVar;
        this.pd = gVar;
    }

    public final void onAnimationStart(Animator animator) {
    }

    public final void onAnimationEnd(Animator animator) {
        this.pc.a(this.pd);
    }

    public final void onAnimationCancel(Animator animator) {
        this.pc.aX();
    }

    public final void onAnimationRepeat(Animator animator) {
    }
}
