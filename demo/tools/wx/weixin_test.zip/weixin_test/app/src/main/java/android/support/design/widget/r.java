package android.support.design.widget;

import android.view.View;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

final class r {
    WeakReference<View> fC;
    final ArrayList<r$a> jT = new ArrayList();
    r$a jU = null;
    Animation jV = null;
    private AnimationListener jW = new r$1(this);

    r() {
    }

    public final void a(int[] iArr, Animation animation) {
        r$a r_a = new r$a(iArr, animation, (byte) 0);
        animation.setAnimationListener(this.jW);
        this.jT.add(r_a);
    }

    final View aB() {
        return this.fC == null ? null : (View) this.fC.get();
    }
}
