package android.support.design.internal;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.support.design.a$i;
import android.support.design.a.h;
import android.support.v4.view.z;
import android.util.AttributeSet;
import android.widget.FrameLayout;

public class ScrimInsetsFrameLayout extends FrameLayout {
    private Drawable eI;
    private Rect eJ;
    private Rect eK;

    public ScrimInsetsFrameLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public ScrimInsetsFrameLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.eK = new Rect();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, a$i.do, i, h.bX);
        this.eI = obtainStyledAttributes.getDrawable(a$i.dp);
        obtainStyledAttributes.recycle();
        setWillNotDraw(true);
        z.b(this, new ScrimInsetsFrameLayout$1(this));
    }

    public void draw(Canvas canvas) {
        super.draw(canvas);
        int width = getWidth();
        int height = getHeight();
        if (this.eJ != null && this.eI != null) {
            int save = canvas.save();
            canvas.translate((float) getScrollX(), (float) getScrollY());
            this.eK.set(0, 0, width, this.eJ.top);
            this.eI.setBounds(this.eK);
            this.eI.draw(canvas);
            this.eK.set(0, height - this.eJ.bottom, width, height);
            this.eI.setBounds(this.eK);
            this.eI.draw(canvas);
            this.eK.set(0, this.eJ.top, this.eJ.left, height - this.eJ.bottom);
            this.eI.setBounds(this.eK);
            this.eI.draw(canvas);
            this.eK.set(width - this.eJ.right, this.eJ.top, width, height - this.eJ.bottom);
            this.eI.setBounds(this.eK);
            this.eI.draw(canvas);
            canvas.restoreToCount(save);
        }
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (this.eI != null) {
            this.eI.setCallback(this);
        }
    }

    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (this.eI != null) {
            this.eI.setCallback(null);
        }
    }

    public void c(Rect rect) {
    }
}
