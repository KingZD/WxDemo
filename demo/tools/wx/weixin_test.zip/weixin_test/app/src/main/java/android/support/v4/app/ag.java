package android.support.v4.app;

import android.app.NotificationManager;
import android.content.ComponentName;
import android.content.Context;
import android.os.Build.VERSION;
import android.os.IBinder;
import android.provider.Settings.Secure;
import java.util.HashSet;
import java.util.Set;

public final class ag {
    private static final int tc = tj.bx();
    private static final Object td = new Object();
    private static String te;
    private static Set<String> tf = new HashSet();
    private static final Object th = new Object();
    private static ag$h ti;
    public static final ag$b tj;
    public final Context mContext;
    public final NotificationManager tg = ((NotificationManager) this.mContext.getSystemService("notification"));

    static class e extends ag$d {
        e() {
        }

        public final int bx() {
            return 33;
        }
    }

    private static class g {
        final ComponentName tm;
        final IBinder tn;

        public g(ComponentName componentName, IBinder iBinder) {
            this.tm = componentName;
            this.tn = iBinder;
        }
    }

    static {
        if (VERSION.SDK_INT >= 14) {
            tj = new e();
        } else if (VERSION.SDK_INT >= 5) {
            tj = new ag$d();
        } else {
            tj = new ag$c();
        }
    }

    public static ag u(Context context) {
        return new ag(context);
    }

    private ag(Context context) {
        this.mContext = context;
    }

    public static Set<String> v(Context context) {
        String string = Secure.getString(context.getContentResolver(), "enabled_notification_listeners");
        if (!(string == null || string.equals(te))) {
            String[] split = string.split(":");
            Set hashSet = new HashSet(split.length);
            for (String unflattenFromString : split) {
                ComponentName unflattenFromString2 = ComponentName.unflattenFromString(unflattenFromString);
                if (unflattenFromString2 != null) {
                    hashSet.add(unflattenFromString2.getPackageName());
                }
            }
            synchronized (td) {
                tf = hashSet;
                te = string;
            }
        }
        return tf;
    }

    public final void a(ag$i ag_i) {
        synchronized (th) {
            if (ti == null) {
                ti = new ag$h(this.mContext.getApplicationContext());
            }
        }
        ti.mHandler.obtainMessage(0, ag_i).sendToTarget();
    }
}
