package android.support.v4.view;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ViewConfiguration;
import com.tencent.smtt.sdk.WebView;

public class PagerTabStrip extends PagerTitleStrip {
    private final Rect eK = new Rect();
    private int iY;
    private int xO = this.yr;
    private int xP;
    private int xQ;
    private int xR;
    private int xS;
    private int xT;
    private final Paint xU = new Paint();
    private int xV = 255;
    private boolean xW = false;
    private boolean xX = false;
    private int xY;
    private boolean xZ;
    private float ya;
    private float yb;

    public PagerTabStrip(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.xU.setColor(this.xO);
        float f = context.getResources().getDisplayMetrics().density;
        this.xP = (int) ((3.0f * f) + 0.5f);
        this.xQ = (int) ((6.0f * f) + 0.5f);
        this.xR = (int) (64.0f * f);
        this.xT = (int) ((16.0f * f) + 0.5f);
        this.xY = (int) ((1.0f * f) + 0.5f);
        this.xS = (int) ((f * 32.0f) + 0.5f);
        this.iY = ViewConfiguration.get(context).getScaledTouchSlop();
        setPadding(getPaddingLeft(), getPaddingTop(), getPaddingRight(), getPaddingBottom());
        ae(this.yj);
        setWillNotDraw(false);
        this.ye.setFocusable(true);
        this.ye.setOnClickListener(new PagerTabStrip$1(this));
        this.yg.setFocusable(true);
        this.yg.setOnClickListener(new PagerTabStrip$2(this));
        if (getBackground() == null) {
            this.xW = true;
        }
    }

    public void setPadding(int i, int i2, int i3, int i4) {
        if (i4 < this.xQ) {
            i4 = this.xQ;
        }
        super.setPadding(i, i2, i3, i4);
    }

    public final void ae(int i) {
        if (i < this.xR) {
            i = this.xR;
        }
        super.ae(i);
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        if (!this.xX) {
            this.xW = drawable == null;
        }
    }

    public void setBackgroundColor(int i) {
        super.setBackgroundColor(i);
        if (!this.xX) {
            this.xW = (WebView.NIGHT_MODE_COLOR & i) == 0;
        }
    }

    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        if (!this.xX) {
            this.xW = i == 0;
        }
    }

    final int getMinHeight() {
        return Math.max(super.getMinHeight(), this.xS);
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        int action = motionEvent.getAction();
        if (action != 0 && this.xZ) {
            return false;
        }
        float x = motionEvent.getX();
        float y = motionEvent.getY();
        switch (action) {
            case 0:
                this.ya = x;
                this.yb = y;
                this.xZ = false;
                break;
            case 1:
                if (x >= ((float) (this.yf.getLeft() - this.xT))) {
                    if (x > ((float) (this.yf.getRight() + this.xT))) {
                        this.yd.ai(this.yd.yQ + 1);
                        break;
                    }
                }
                this.yd.ai(this.yd.yQ - 1);
                break;
                break;
            case 2:
                if (Math.abs(x - this.ya) > ((float) this.iY) || Math.abs(y - this.yb) > ((float) this.iY)) {
                    this.xZ = true;
                    break;
                }
        }
        return true;
    }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int height = getHeight();
        int left = this.yf.getLeft() - this.xT;
        int right = this.yf.getRight() + this.xT;
        int i = height - this.xP;
        this.xU.setColor((this.xV << 24) | (this.xO & 16777215));
        canvas.drawRect((float) left, (float) i, (float) right, (float) height, this.xU);
        if (this.xW) {
            this.xU.setColor(WebView.NIGHT_MODE_COLOR | (this.xO & 16777215));
            canvas.drawRect((float) getPaddingLeft(), (float) (height - this.xY), (float) (getWidth() - getPaddingRight()), (float) height, this.xU);
        }
    }

    final void a(int i, float f, boolean z) {
        Rect rect = this.eK;
        int height = getHeight();
        int i2 = height - this.xP;
        rect.set(this.yf.getLeft() - this.xT, i2, this.yf.getRight() + this.xT, height);
        super.a(i, f, z);
        this.xV = (int) ((Math.abs(f - 0.5f) * 2.0f) * 255.0f);
        rect.union(this.yf.getLeft() - this.xT, i2, this.yf.getRight() + this.xT, height);
        invalidate(rect);
    }
}
