package android.support.v4.media;

import android.os.Bundle;
import android.os.RemoteException;
import java.util.List;

class MediaBrowserServiceCompat$1 extends MediaBrowserServiceCompat$c<List<MediaBrowserCompat$MediaItem>> {
    final /* synthetic */ MediaBrowserServiceCompat$b uH;
    final /* synthetic */ String uI;
    final /* synthetic */ Bundle uJ;
    final /* synthetic */ MediaBrowserServiceCompat uK;

    MediaBrowserServiceCompat$1(MediaBrowserServiceCompat mediaBrowserServiceCompat, Object obj, MediaBrowserServiceCompat$b mediaBrowserServiceCompat$b, String str, Bundle bundle) {
        this.uK = mediaBrowserServiceCompat;
        this.uH = mediaBrowserServiceCompat$b;
        this.uI = str;
        this.uJ = bundle;
        super(obj);
    }

    final /* synthetic */ void b(Object obj, int i) {
        List list = null;
        if (MediaBrowserServiceCompat.b(this.uK).get(this.uH.uP.asBinder()) == this.uH) {
            List list2;
            if ((i & 1) != 0) {
                Bundle bundle = this.uJ;
                int i2 = bundle.getInt("android.media.browse.extra.PAGE", -1);
                int i3 = bundle.getInt("android.media.browse.extra.PAGE_SIZE", -1);
                if (!(i2 == -1 && i3 == -1)) {
                    int i4 = i3 * (i2 - 1);
                    int i5 = i4 + i3;
                    if (i2 <= 0 || i3 <= 0 || i4 >= list.size()) {
                        list2 = list;
                        this.uH.uP.a(this.uI, list2, this.uJ);
                    }
                    if (i5 > list.size()) {
                        i5 = list.size();
                    }
                    list2 = list.subList(i4, i5);
                    this.uH.uP.a(this.uI, list2, this.uJ);
                }
            }
            list2 = list;
            try {
                this.uH.uP.a(this.uI, list2, this.uJ);
            } catch (RemoteException e) {
                new StringBuilder("Calling onLoadChildren() failed for id=").append(this.uI).append(" package=").append(this.uH.uN);
            }
        }
    }
}
