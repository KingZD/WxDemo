package android.support.design;

public final class a$g {
    public static final int bO = 2131237828;
}
