package android.support.design.widget;

import android.os.Build.VERSION;
import android.view.View;

final class aa {
    static final u$d mc = new aa$1();
    private static final aa$a md;

    static {
        if (VERSION.SDK_INT >= 21) {
            md = new aa$c((byte) 0);
        } else {
            md = new aa$b((byte) 0);
        }
    }

    static void u(View view) {
        md.u(view);
    }

    static u aJ() {
        return mc.aJ();
    }
}
