package android.support.v4.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.os.Build.VERSION;
import android.widget.EdgeEffect;

public final class i {
    private static final c CL;
    private Object CK;

    interface c {
        boolean I(Object obj);

        void J(Object obj);

        boolean K(Object obj);

        void a(Object obj, int i, int i2);

        boolean a(Object obj, float f);

        boolean a(Object obj, float f, float f2);

        boolean a(Object obj, Canvas canvas);

        boolean l(Object obj, int i);

        Object z(Context context);
    }

    static class a implements c {
        a() {
        }

        public final Object z(Context context) {
            return null;
        }

        public final void a(Object obj, int i, int i2) {
        }

        public final boolean I(Object obj) {
            return true;
        }

        public final void J(Object obj) {
        }

        public final boolean a(Object obj, float f) {
            return false;
        }

        public final boolean K(Object obj) {
            return false;
        }

        public final boolean l(Object obj, int i) {
            return false;
        }

        public final boolean a(Object obj, Canvas canvas) {
            return false;
        }

        public final boolean a(Object obj, float f, float f2) {
            return false;
        }
    }

    static class b implements c {
        b() {
        }

        public final Object z(Context context) {
            return new EdgeEffect(context);
        }

        public final void a(Object obj, int i, int i2) {
            ((EdgeEffect) obj).setSize(i, i2);
        }

        public final boolean I(Object obj) {
            return ((EdgeEffect) obj).isFinished();
        }

        public final void J(Object obj) {
            ((EdgeEffect) obj).finish();
        }

        public final boolean a(Object obj, float f) {
            return j.a(obj, f);
        }

        public final boolean K(Object obj) {
            EdgeEffect edgeEffect = (EdgeEffect) obj;
            edgeEffect.onRelease();
            return edgeEffect.isFinished();
        }

        public final boolean l(Object obj, int i) {
            ((EdgeEffect) obj).onAbsorb(i);
            return true;
        }

        public final boolean a(Object obj, Canvas canvas) {
            return ((EdgeEffect) obj).draw(canvas);
        }

        public boolean a(Object obj, float f, float f2) {
            return j.a(obj, f);
        }
    }

    static class d extends b {
        d() {
        }

        public final boolean a(Object obj, float f, float f2) {
            ((EdgeEffect) obj).onPull(f, f2);
            return true;
        }
    }

    static {
        if (VERSION.SDK_INT >= 21) {
            CL = new d();
        } else if (VERSION.SDK_INT >= 14) {
            CL = new b();
        } else {
            CL = new a();
        }
    }

    public i(Context context) {
        this.CK = CL.z(context);
    }

    public final void setSize(int i, int i2) {
        CL.a(this.CK, i, i2);
    }

    public final boolean isFinished() {
        return CL.I(this.CK);
    }

    public final void finish() {
        CL.J(this.CK);
    }

    public final boolean z(float f) {
        return CL.a(this.CK, f);
    }

    public final boolean s(float f, float f2) {
        return CL.a(this.CK, f, f2);
    }

    public final boolean cG() {
        return CL.K(this.CK);
    }

    public final boolean aq(int i) {
        return CL.l(this.CK, i);
    }

    public final boolean draw(Canvas canvas) {
        return CL.a(this.CK, canvas);
    }
}
