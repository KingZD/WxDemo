package android.support.v4.b;

import android.graphics.Bitmap;

class a$c extends a$a {
    a$c() {
    }

    public int e(Bitmap bitmap) {
        return bitmap.getByteCount();
    }
}
