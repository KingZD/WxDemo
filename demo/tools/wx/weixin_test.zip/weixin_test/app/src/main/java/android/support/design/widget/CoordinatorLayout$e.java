package android.support.design.widget;

import android.view.ViewTreeObserver.OnPreDrawListener;

class CoordinatorLayout$e implements OnPreDrawListener {
    final /* synthetic */ CoordinatorLayout hN;

    CoordinatorLayout$e(CoordinatorLayout coordinatorLayout) {
        this.hN = coordinatorLayout;
    }

    public final boolean onPreDraw() {
        this.hN.q(false);
        return true;
    }
}
