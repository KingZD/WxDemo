package android.support.v4.app;

import android.app.Notification;
import android.support.v4.app.z.l;

class z$o extends l {
    z$o() {
    }

    public final Notification b(z$d z_d) {
        return new ad$a(z_d.mContext, z_d.sG, z_d.si, z_d.sj, z_d.so, z_d.sm, z_d.sp, z_d.sk, z_d.sl, z_d.sn, z_d.su, z_d.sv, z_d.sw).build();
    }
}
