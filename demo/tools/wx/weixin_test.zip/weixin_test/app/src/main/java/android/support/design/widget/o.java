package android.support.design.widget;

import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.graphics.Path.FillType;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader.TileMode;
import android.graphics.drawable.Drawable;
import android.support.design.a$c;
import android.support.v7.c.a.a;

final class o extends a {
    static final double jm = Math.cos(Math.toRadians(45.0d));
    float fZ;
    boolean jA = true;
    private boolean jB = false;
    final Paint jn;
    final Paint jo;
    final RectF jp;
    float jq;
    Path jr;
    float js;
    float jt;
    float ju;
    float jv;
    private boolean jw = true;
    private final int jx;
    private final int jy;
    private final int jz;

    public o(Resources resources, Drawable drawable, float f, float f2, float f3) {
        super(drawable);
        this.jx = resources.getColor(a$c.bh);
        this.jy = resources.getColor(a$c.bg);
        this.jz = resources.getColor(a$c.bf);
        this.jn = new Paint(5);
        this.jn.setStyle(Style.FILL);
        this.jq = (float) Math.round(f);
        this.jp = new RectF();
        this.jo = new Paint(this.jn);
        this.jo.setAntiAlias(false);
        o(f2, f3);
    }

    private static int n(float f) {
        int round = Math.round(f);
        return round % 2 == 1 ? round - 1 : round;
    }

    public final void setAlpha(int i) {
        super.setAlpha(i);
        this.jn.setAlpha(i);
        this.jo.setAlpha(i);
    }

    protected final void onBoundsChange(Rect rect) {
        this.jw = true;
    }

    final void o(float f, float f2) {
        if (f < 0.0f || f2 < 0.0f) {
            throw new IllegalArgumentException("invalid shadow size");
        }
        float n = (float) n(f);
        float n2 = (float) n(f2);
        if (n > n2) {
            if (!this.jB) {
                this.jB = true;
            }
            n = n2;
        }
        if (this.jv != n || this.jt != n2) {
            this.jv = n;
            this.jt = n2;
            this.ju = (float) Math.round(n * 1.5f);
            this.js = n2;
            this.jw = true;
            invalidateSelf();
        }
    }

    public final boolean getPadding(Rect rect) {
        int ceil = (int) Math.ceil((double) c(this.jt, this.jq, this.jA));
        int ceil2 = (int) Math.ceil((double) d(this.jt, this.jq, this.jA));
        rect.set(ceil2, ceil, ceil2, ceil);
        return true;
    }

    public static float c(float f, float f2, boolean z) {
        if (z) {
            return (float) (((double) (1.5f * f)) + ((1.0d - jm) * ((double) f2)));
        }
        return 1.5f * f;
    }

    public static float d(float f, float f2, boolean z) {
        if (z) {
            return (float) (((double) f) + ((1.0d - jm) * ((double) f2)));
        }
        return f;
    }

    public final int getOpacity() {
        return -3;
    }

    public final void draw(Canvas canvas) {
        float f;
        if (this.jw) {
            Rect bounds = getBounds();
            float f2 = this.jt * 1.5f;
            this.jp.set(((float) bounds.left) + this.jt, ((float) bounds.top) + f2, ((float) bounds.right) - this.jt, ((float) bounds.bottom) - f2);
            this.mDrawable.setBounds((int) this.jp.left, (int) this.jp.top, (int) this.jp.right, (int) this.jp.bottom);
            RectF rectF = new RectF(-this.jq, -this.jq, this.jq, this.jq);
            RectF rectF2 = new RectF(rectF);
            rectF2.inset(-this.ju, -this.ju);
            if (this.jr == null) {
                this.jr = new Path();
            } else {
                this.jr.reset();
            }
            this.jr.setFillType(FillType.EVEN_ODD);
            this.jr.moveTo(-this.jq, 0.0f);
            this.jr.rLineTo(-this.ju, 0.0f);
            this.jr.arcTo(rectF2, 180.0f, 90.0f, false);
            this.jr.arcTo(rectF, 270.0f, -90.0f, false);
            this.jr.close();
            float f3 = -rectF2.top;
            if (f3 > 0.0f) {
                float f4 = this.jq / f3;
                f = f4 + ((1.0f - f4) / 2.0f);
                this.jn.setShader(new RadialGradient(0.0f, 0.0f, f3, new int[]{0, this.jx, this.jy, this.jz}, new float[]{0.0f, f4, f, 1.0f}, TileMode.CLAMP));
            }
            this.jo.setShader(new LinearGradient(0.0f, rectF.top, 0.0f, rectF2.top, new int[]{this.jx, this.jy, this.jz}, new float[]{0.0f, 0.5f, 1.0f}, TileMode.CLAMP));
            this.jo.setAntiAlias(false);
            this.jw = false;
        }
        int save = canvas.save();
        canvas.rotate(this.fZ, this.jp.centerX(), this.jp.centerY());
        float f5 = (-this.jq) - this.ju;
        f = this.jq;
        Object obj = this.jp.width() - (2.0f * f) > 0.0f ? 1 : null;
        Object obj2 = this.jp.height() - (2.0f * f) > 0.0f ? 1 : null;
        float f6 = f / ((this.jv - (this.jv * 0.5f)) + f);
        float f7 = f / ((this.jv - (this.jv * 0.25f)) + f);
        float f8 = f / (f + (this.jv - (this.jv * 1.0f)));
        int save2 = canvas.save();
        canvas.translate(this.jp.left + f, this.jp.top + f);
        canvas.scale(f6, f7);
        canvas.drawPath(this.jr, this.jn);
        if (obj != null) {
            canvas.scale(1.0f / f6, 1.0f);
            canvas.drawRect(0.0f, f5, this.jp.width() - (2.0f * f), -this.jq, this.jo);
        }
        canvas.restoreToCount(save2);
        save2 = canvas.save();
        canvas.translate(this.jp.right - f, this.jp.bottom - f);
        canvas.scale(f6, f8);
        canvas.rotate(180.0f);
        canvas.drawPath(this.jr, this.jn);
        if (obj != null) {
            canvas.scale(1.0f / f6, 1.0f);
            canvas.drawRect(0.0f, f5, this.jp.width() - (2.0f * f), this.ju + (-this.jq), this.jo);
        }
        canvas.restoreToCount(save2);
        int save3 = canvas.save();
        canvas.translate(this.jp.left + f, this.jp.bottom - f);
        canvas.scale(f6, f8);
        canvas.rotate(270.0f);
        canvas.drawPath(this.jr, this.jn);
        if (obj2 != null) {
            canvas.scale(1.0f / f8, 1.0f);
            canvas.drawRect(0.0f, f5, this.jp.height() - (2.0f * f), -this.jq, this.jo);
        }
        canvas.restoreToCount(save3);
        save3 = canvas.save();
        canvas.translate(this.jp.right - f, this.jp.top + f);
        canvas.scale(f6, f7);
        canvas.rotate(90.0f);
        canvas.drawPath(this.jr, this.jn);
        if (obj2 != null) {
            canvas.scale(1.0f / f7, 1.0f);
            canvas.drawRect(0.0f, f5, this.jp.height() - (2.0f * f), -this.jq, this.jo);
        }
        canvas.restoreToCount(save3);
        canvas.restoreToCount(save);
        super.draw(canvas);
    }
}
