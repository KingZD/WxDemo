package android.support.v4.view;

import android.view.View;
import android.view.View.OnClickListener;

class PagerTabStrip$1 implements OnClickListener {
    final /* synthetic */ PagerTabStrip yc;

    PagerTabStrip$1(PagerTabStrip pagerTabStrip) {
        this.yc = pagerTabStrip;
    }

    public final void onClick(View view) {
        this.yc.yd.ai(this.yc.yd.yQ - 1);
    }
}
