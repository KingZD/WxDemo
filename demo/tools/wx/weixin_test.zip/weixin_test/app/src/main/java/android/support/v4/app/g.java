package android.support.v4.app;

abstract class g extends f {
    g() {
    }

    void onBackPressedNotHandled() {
        super.onBackPressed();
    }
}
