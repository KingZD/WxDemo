package android.support.design.widget;

public abstract class BottomSheetBehavior$a {
    public abstract void g(float f);

    public abstract void v(int i);
}
