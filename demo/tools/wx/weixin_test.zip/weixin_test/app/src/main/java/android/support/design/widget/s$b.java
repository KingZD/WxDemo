package android.support.design.widget;

import android.support.v4.view.z;
import android.view.View;

class s$b implements Runnable {
    final /* synthetic */ s kh;
    private final boolean ki;
    private final View mView;

    s$b(s sVar, View view, boolean z) {
        this.kh = sVar;
        this.mView = view;
        this.ki = z;
    }

    public final void run() {
        if (s.b(this.kh) != null && s.b(this.kh).cW()) {
            z.a(this.mView, this);
        } else if (this.ki && s.a(this.kh) != null) {
            s.a(this.kh).onDismiss(this.mView);
        }
    }
}
