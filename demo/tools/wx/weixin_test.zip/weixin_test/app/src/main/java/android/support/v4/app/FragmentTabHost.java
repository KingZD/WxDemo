package android.support.v4.app;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.widget.TabHost;
import android.widget.TabHost.OnTabChangeListener;
import java.util.ArrayList;

public class FragmentTabHost extends TabHost implements OnTabChangeListener {
    private final ArrayList<FragmentTabHost$a> km = new ArrayList();
    private int mContainerId;
    private Context mContext;
    private m rj;
    private OnTabChangeListener rq;
    private FragmentTabHost$a rr;
    private boolean rs;

    public FragmentTabHost(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, new int[]{16842995}, 0, 0);
        this.mContainerId = obtainStyledAttributes.getResourceId(0, 0);
        obtainStyledAttributes.recycle();
        super.setOnTabChangedListener(this);
    }

    @Deprecated
    public void setup() {
        throw new IllegalStateException("Must call setup() that takes a Context and FragmentManager");
    }

    public void setOnTabChangedListener(OnTabChangeListener onTabChangeListener) {
        this.rq = onTabChangeListener;
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        String currentTabTag = getCurrentTabTag();
        q qVar = null;
        for (int i = 0; i < this.km.size(); i++) {
            FragmentTabHost$a fragmentTabHost$a = (FragmentTabHost$a) this.km.get(i);
            fragmentTabHost$a.pU = this.rj.s(fragmentTabHost$a.tag);
            if (!(fragmentTabHost$a.pU == null || fragmentTabHost$a.pU.isDetached())) {
                if (fragmentTabHost$a.tag.equals(currentTabTag)) {
                    this.rr = fragmentTabHost$a;
                } else {
                    if (qVar == null) {
                        qVar = this.rj.bd();
                    }
                    qVar.c(fragmentTabHost$a.pU);
                }
            }
        }
        this.rs = true;
        q a = a(currentTabTag, qVar);
        if (a != null) {
            a.commit();
            this.rj.executePendingTransactions();
        }
    }

    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.rs = false;
    }

    protected Parcelable onSaveInstanceState() {
        Parcelable fragmentTabHost$SavedState = new FragmentTabHost$SavedState(super.onSaveInstanceState());
        fragmentTabHost$SavedState.rt = getCurrentTabTag();
        return fragmentTabHost$SavedState;
    }

    protected void onRestoreInstanceState(Parcelable parcelable) {
        if (parcelable instanceof FragmentTabHost$SavedState) {
            FragmentTabHost$SavedState fragmentTabHost$SavedState = (FragmentTabHost$SavedState) parcelable;
            super.onRestoreInstanceState(fragmentTabHost$SavedState.getSuperState());
            setCurrentTabByTag(fragmentTabHost$SavedState.rt);
            return;
        }
        super.onRestoreInstanceState(parcelable);
    }

    public void onTabChanged(String str) {
        if (this.rs) {
            q a = a(str, null);
            if (a != null) {
                a.commit();
            }
        }
        if (this.rq != null) {
            this.rq.onTabChanged(str);
        }
    }

    private q a(String str, q qVar) {
        FragmentTabHost$a fragmentTabHost$a = null;
        int i = 0;
        while (i < this.km.size()) {
            FragmentTabHost$a fragmentTabHost$a2 = (FragmentTabHost$a) this.km.get(i);
            if (!fragmentTabHost$a2.tag.equals(str)) {
                fragmentTabHost$a2 = fragmentTabHost$a;
            }
            i++;
            fragmentTabHost$a = fragmentTabHost$a2;
        }
        if (fragmentTabHost$a == null) {
            throw new IllegalStateException("No tab known for tag " + str);
        }
        if (this.rr != fragmentTabHost$a) {
            if (qVar == null) {
                qVar = this.rj.bd();
            }
            if (!(this.rr == null || this.rr.pU == null)) {
                qVar.c(this.rr.pU);
            }
            if (fragmentTabHost$a != null) {
                if (fragmentTabHost$a.pU == null) {
                    fragmentTabHost$a.pU = Fragment.instantiate(this.mContext, fragmentTabHost$a.ru.getName(), fragmentTabHost$a.rv);
                    qVar.a(this.mContainerId, fragmentTabHost$a.pU, fragmentTabHost$a.tag);
                } else {
                    qVar.d(fragmentTabHost$a.pU);
                }
            }
            this.rr = fragmentTabHost$a;
        }
        return qVar;
    }
}
