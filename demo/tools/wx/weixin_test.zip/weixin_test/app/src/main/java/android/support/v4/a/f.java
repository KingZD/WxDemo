package android.support.v4.a;

import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.view.View;

final class f implements c {
    private TimeInterpolator pb;

    f() {
    }

    public final g aW() {
        return new f$b(ValueAnimator.ofFloat(new float[]{0.0f, 1.0f}));
    }

    public final void v(View view) {
        if (this.pb == null) {
            this.pb = new ValueAnimator().getInterpolator();
        }
        view.animate().setInterpolator(this.pb);
    }
}
