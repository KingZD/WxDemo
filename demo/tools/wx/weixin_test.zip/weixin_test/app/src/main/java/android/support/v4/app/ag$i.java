package android.support.v4.app;

interface ag$i {
    void a(s sVar);
}
