package android.support.v4.media;

class MediaBrowserServiceCompat$g$2 implements Runnable {
    final /* synthetic */ MediaBrowserServiceCompat$d uX;
    final /* synthetic */ MediaBrowserServiceCompat$g vb;

    MediaBrowserServiceCompat$g$2(MediaBrowserServiceCompat$g mediaBrowserServiceCompat$g, MediaBrowserServiceCompat$d mediaBrowserServiceCompat$d) {
        this.vb = mediaBrowserServiceCompat$g;
        this.uX = mediaBrowserServiceCompat$d;
    }

    public final void run() {
        MediaBrowserServiceCompat.b(this.vb.uK).remove(this.uX.asBinder());
    }
}
