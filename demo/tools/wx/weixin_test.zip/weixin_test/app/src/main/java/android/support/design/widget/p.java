package android.support.design.widget;

import android.graphics.drawable.Drawable;

interface p {
    float ai();

    boolean aj();

    void d(int i, int i2, int i3, int i4);

    void setBackgroundDrawable(Drawable drawable);
}
