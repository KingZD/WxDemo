package android.support.design.widget;

class j$2 extends b {
    final /* synthetic */ l$a iC;
    final /* synthetic */ j iD;

    j$2(j jVar, l$a l_a) {
        this.iD = jVar;
        this.iC = l_a;
    }
}
