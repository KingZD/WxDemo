package android.support.v4.app;

import android.app.PendingIntent;
import java.util.ArrayList;
import java.util.List;

public class z$f$a$a {
    public ah sK;
    public PendingIntent sL;
    public PendingIntent sM;
    public long sO;
    public final List<String> sQ = new ArrayList();
    public final String sR;

    public z$f$a$a(String str) {
        this.sR = str;
    }
}
