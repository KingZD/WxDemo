package android.support.v4.view;

public interface p {
    boolean isNestedScrollingEnabled();

    void stopNestedScroll();
}
