package android.support.design.internal;

import android.view.View;

class b$a extends b$j {
    public b$a(View view) {
        super(view);
    }
}
