package android.support.v4.a;

public interface b {
    void a(g gVar);

    void aX();
}
