package android.support.v4.media;

import android.app.Service;
import android.os.Bundle;
import android.os.IBinder;
import android.support.v4.e.a;
import android.support.v4.media.session.MediaSessionCompat.Token;
import android.support.v4.os.ResultReceiver;
import java.util.ArrayList;
import java.util.List;

public abstract class MediaBrowserServiceCompat extends Service {
    private final a<IBinder, MediaBrowserServiceCompat$b> uE = new a();
    private final MediaBrowserServiceCompat$f uF = new MediaBrowserServiceCompat$f(this, (byte) 0);
    Token uG;

    public abstract MediaBrowserServiceCompat$a bF();

    static /* synthetic */ void a(MediaBrowserServiceCompat mediaBrowserServiceCompat, String str, MediaBrowserServiceCompat$b mediaBrowserServiceCompat$b, Bundle bundle) {
        List list = (List) mediaBrowserServiceCompat$b.uR.get(str);
        List<Bundle> arrayList = list == null ? new ArrayList() : list;
        for (Bundle a : arrayList) {
            if (a.a(bundle, a)) {
                return;
            }
        }
        arrayList.add(bundle);
        mediaBrowserServiceCompat$b.uR.put(str, arrayList);
        MediaBrowserServiceCompat$c mediaBrowserServiceCompat$1 = new MediaBrowserServiceCompat$1(mediaBrowserServiceCompat, str, mediaBrowserServiceCompat$b, str, bundle);
        if (bundle != null) {
            mediaBrowserServiceCompat$1.uC = 1;
        }
        if (!mediaBrowserServiceCompat$1.isDone()) {
            throw new IllegalStateException("onLoadChildren must call detach() or sendResult() before returning for package=" + mediaBrowserServiceCompat$b.uN + " id=" + str);
        }
    }

    static /* synthetic */ void a(MediaBrowserServiceCompat mediaBrowserServiceCompat, String str, ResultReceiver resultReceiver) {
        MediaBrowserServiceCompat$c mediaBrowserServiceCompat$2 = new MediaBrowserServiceCompat$2(mediaBrowserServiceCompat, str, resultReceiver);
        if (mediaBrowserServiceCompat$2.uU) {
            throw new IllegalStateException("sendResult() called twice for: " + mediaBrowserServiceCompat$2.uS);
        }
        mediaBrowserServiceCompat$2.uU = true;
        mediaBrowserServiceCompat$2.b(null, mediaBrowserServiceCompat$2.uC);
        if (!mediaBrowserServiceCompat$2.isDone()) {
            throw new IllegalStateException("onLoadItem must call detach() or sendResult() before returning for id=" + str);
        }
    }

    static /* synthetic */ boolean a(MediaBrowserServiceCompat mediaBrowserServiceCompat, String str, int i) {
        if (str == null) {
            return false;
        }
        for (String equals : mediaBrowserServiceCompat.getPackageManager().getPackagesForUid(i)) {
            if (equals.equals(str)) {
                return true;
            }
        }
        return false;
    }

    static /* synthetic */ boolean a(String str, MediaBrowserServiceCompat$b mediaBrowserServiceCompat$b, Bundle bundle) {
        List<Bundle> list = (List) mediaBrowserServiceCompat$b.uR.get(str);
        if (list == null) {
            return false;
        }
        boolean z;
        for (Bundle bundle2 : list) {
            if (a.a(bundle, bundle2)) {
                list.remove(bundle2);
                z = true;
                break;
            }
        }
        z = false;
        if (list.size() != 0) {
            return z;
        }
        mediaBrowserServiceCompat$b.uR.remove(str);
        return z;
    }
}
