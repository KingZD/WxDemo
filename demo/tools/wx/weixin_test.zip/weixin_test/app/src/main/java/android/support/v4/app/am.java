package android.support.v4.app;

import android.util.AndroidRuntimeException;

final class am extends AndroidRuntimeException {
    public am(String str) {
        super(str);
    }
}
