package android.support.design.widget;

import android.content.Context;
import android.support.v4.view.o;
import android.support.v4.view.y;
import android.support.v4.view.z;
import android.support.v4.widget.q;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;

abstract class HeaderBehavior<V extends View> extends ViewOffsetBehavior<V> {
    private VelocityTracker fF;
    private int fG = -1;
    private Runnable iU;
    private q iV;
    private boolean iW;
    private int iX;
    private int iY = -1;

    public HeaderBehavior(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public final boolean a(CoordinatorLayout coordinatorLayout, V v, MotionEvent motionEvent) {
        if (this.iY < 0) {
            this.iY = ViewConfiguration.get(coordinatorLayout.getContext()).getScaledTouchSlop();
        }
        if (motionEvent.getAction() == 2 && this.iW) {
            return true;
        }
        int y;
        switch (o.d(motionEvent)) {
            case 0:
                this.iW = false;
                int x = (int) motionEvent.getX();
                y = (int) motionEvent.getY();
                if (d(v) && coordinatorLayout.b(v, x, y)) {
                    this.iX = y;
                    this.fG = o.c(motionEvent, 0);
                    ar();
                    break;
                }
            case 1:
            case 3:
                this.iW = false;
                this.fG = -1;
                if (this.fF != null) {
                    this.fF.recycle();
                    this.fF = null;
                    break;
                }
                break;
            case 2:
                y = this.fG;
                if (y != -1) {
                    y = o.b(motionEvent, y);
                    if (y != -1) {
                        y = (int) o.e(motionEvent, y);
                        if (Math.abs(y - this.iX) > this.iY) {
                            this.iW = true;
                            this.iX = y;
                            break;
                        }
                    }
                }
                break;
        }
        if (this.fF != null) {
            this.fF.addMovement(motionEvent);
        }
        return this.iW;
    }

    public final boolean b(CoordinatorLayout coordinatorLayout, V v, MotionEvent motionEvent) {
        if (this.iY < 0) {
            this.iY = ViewConfiguration.get(coordinatorLayout.getContext()).getScaledTouchSlop();
        }
        switch (o.d(motionEvent)) {
            case 0:
                int y = (int) motionEvent.getY();
                if (coordinatorLayout.b(v, (int) motionEvent.getX(), y) && d(v)) {
                    this.iX = y;
                    this.fG = o.c(motionEvent, 0);
                    ar();
                    break;
                }
                return false;
                break;
            case 1:
                if (this.fF != null) {
                    this.fF.addMovement(motionEvent);
                    this.fF.computeCurrentVelocity(1000);
                    a(coordinatorLayout, v, -b(v), y.b(this.fF, this.fG));
                    break;
                }
                break;
            case 2:
                int b = o.b(motionEvent, this.fG);
                if (b != -1) {
                    b = (int) o.e(motionEvent, b);
                    int i = this.iX - b;
                    if (!this.iW && Math.abs(i) > this.iY) {
                        this.iW = true;
                        i = i > 0 ? i - this.iY : i + this.iY;
                    }
                    if (this.iW) {
                        this.iX = b;
                        b(coordinatorLayout, v, i, c(v), 0);
                        break;
                    }
                }
                return false;
                break;
            case 3:
                break;
        }
        this.iW = false;
        this.fG = -1;
        if (this.fF != null) {
            this.fF.recycle();
            this.fF = null;
        }
        if (this.fF != null) {
            this.fF.addMovement(motionEvent);
        }
        return true;
    }

    final int c(CoordinatorLayout coordinatorLayout, V v, int i) {
        return a(coordinatorLayout, v, i, Integer.MIN_VALUE, Integer.MAX_VALUE);
    }

    int a(CoordinatorLayout coordinatorLayout, V v, int i, int i2, int i3) {
        int V = V();
        if (i2 == 0 || V < i2 || V > i3) {
            return 0;
        }
        int e = n.e(i, i2, i3);
        if (V == e) {
            return 0;
        }
        q(e);
        return V - e;
    }

    int U() {
        return V();
    }

    final int b(CoordinatorLayout coordinatorLayout, V v, int i, int i2, int i3) {
        return a(coordinatorLayout, v, U() - i, i2, i3);
    }

    final boolean a(CoordinatorLayout coordinatorLayout, V v, int i, float f) {
        if (this.iU != null) {
            v.removeCallbacks(this.iU);
            this.iU = null;
        }
        if (this.iV == null) {
            this.iV = q.a(v.getContext(), null);
        }
        this.iV.b(V(), 0, Math.round(f), 0, 0, i, 0);
        if (this.iV.computeScrollOffset()) {
            this.iU = new HeaderBehavior$a(this, coordinatorLayout, v);
            z.a((View) v, this.iU);
            return true;
        }
        a(coordinatorLayout, v);
        return false;
    }

    void a(CoordinatorLayout coordinatorLayout, V v) {
    }

    boolean d(V v) {
        return false;
    }

    int c(V v) {
        return -v.getHeight();
    }

    int b(V v) {
        return v.getHeight();
    }

    private void ar() {
        if (this.fF == null) {
            this.fF = VelocityTracker.obtain();
        }
    }
}
