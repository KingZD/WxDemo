package android.support.v4.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ProgressBar;

public class ContentLoadingProgressBar extends ProgressBar {
    private boolean BD = false;
    private boolean BE = false;
    private final Runnable BF = new Runnable(this) {
        final /* synthetic */ ContentLoadingProgressBar BH;

        {
            this.BH = r1;
        }

        public final void run() {
            this.BH.BD = false;
            this.BH.mStartTime = -1;
            this.BH.setVisibility(8);
        }
    };
    private final Runnable BG = new Runnable(this) {
        final /* synthetic */ ContentLoadingProgressBar BH;

        {
            this.BH = r1;
        }

        public final void run() {
            this.BH.BE = false;
            if (!this.BH.qm) {
                this.BH.mStartTime = System.currentTimeMillis();
                this.BH.setVisibility(0);
            }
        }
    };
    private long mStartTime = -1;
    private boolean qm = false;

    public ContentLoadingProgressBar(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        cy();
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        cy();
    }

    private void cy() {
        removeCallbacks(this.BF);
        removeCallbacks(this.BG);
    }
}
