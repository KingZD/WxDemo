package android.support.design.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.support.v4.view.z;
import android.view.View;
import android.view.View.MeasureSpec;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;

class TabLayout$a extends LinearLayout {
    final /* synthetic */ TabLayout kG;
    int kH;
    final Paint kI;
    int kJ = -1;
    float kK;
    private int kL = -1;
    private int kM = -1;
    u kN;

    TabLayout$a(TabLayout tabLayout, Context context) {
        this.kG = tabLayout;
        super(context);
        setWillNotDraw(false);
        this.kI = new Paint();
    }

    protected final void onMeasure(int i, int i2) {
        Object obj = null;
        super.onMeasure(i, i2);
        if (MeasureSpec.getMode(i) == 1073741824 && TabLayout.j(this.kG) == 1 && TabLayout.m(this.kG) == 1) {
            int childCount = getChildCount();
            int i3 = 0;
            int i4 = 0;
            while (i3 < childCount) {
                int max;
                View childAt = getChildAt(i3);
                if (childAt.getVisibility() == 0) {
                    max = Math.max(i4, childAt.getMeasuredWidth());
                } else {
                    max = i4;
                }
                i3++;
                i4 = max;
            }
            if (i4 > 0) {
                if (i4 * childCount <= getMeasuredWidth() - (TabLayout.a(this.kG, 16) * 2)) {
                    i3 = 0;
                    while (i3 < childCount) {
                        Object obj2;
                        LayoutParams layoutParams = (LayoutParams) getChildAt(i3).getLayoutParams();
                        if (layoutParams.width == i4 && layoutParams.weight == 0.0f) {
                            obj2 = obj;
                        } else {
                            layoutParams.width = i4;
                            layoutParams.weight = 0.0f;
                            obj2 = 1;
                        }
                        i3++;
                        obj = obj2;
                    }
                } else {
                    TabLayout.n(this.kG);
                    TabLayout.o(this.kG);
                    obj = 1;
                }
                if (obj != null) {
                    super.onMeasure(i, i2);
                }
            }
        }
    }

    protected final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        if (this.kN == null || !this.kN.lD.isRunning()) {
            aD();
            return;
        }
        this.kN.lD.cancel();
        h(this.kJ, Math.round(((float) this.kN.lD.getDuration()) * (1.0f - this.kN.lD.getAnimatedFraction())));
    }

    final void aD() {
        int i;
        int i2;
        View childAt = getChildAt(this.kJ);
        if (childAt == null || childAt.getWidth() <= 0) {
            i = -1;
            i2 = -1;
        } else {
            i = childAt.getLeft();
            i2 = childAt.getRight();
            if (this.kK > 0.0f && this.kJ < getChildCount() - 1) {
                View childAt2 = getChildAt(this.kJ + 1);
                i = (int) ((((float) i) * (1.0f - this.kK)) + (this.kK * ((float) childAt2.getLeft())));
                i2 = (int) ((((float) i2) * (1.0f - this.kK)) + (((float) childAt2.getRight()) * this.kK));
            }
        }
        g(i, i2);
    }

    private void g(int i, int i2) {
        if (i != this.kL || i2 != this.kM) {
            this.kL = i;
            this.kM = i2;
            z.E(this);
        }
    }

    final void h(int i, int i2) {
        if (this.kN != null && this.kN.lD.isRunning()) {
            this.kN.lD.cancel();
        }
        Object obj = z.I(this) == 1 ? 1 : null;
        View childAt = getChildAt(i);
        if (childAt == null) {
            aD();
            return;
        }
        int i3;
        int i4;
        int left = childAt.getLeft();
        int right = childAt.getRight();
        if (Math.abs(i - this.kJ) <= 1) {
            i3 = this.kL;
            i4 = this.kM;
        } else {
            int a = TabLayout.a(this.kG, 24);
            if (i < this.kJ) {
                if (obj == null) {
                    i4 = right + a;
                    i3 = i4;
                }
            } else if (obj != null) {
                i4 = right + a;
                i3 = i4;
            }
            i4 = left - a;
            i3 = i4;
        }
        if (i3 != left || i4 != right) {
            u aJ = aa.aJ();
            this.kN = aJ;
            aJ.setInterpolator(a.eN);
            aJ.setDuration(i2);
            aJ.p(0.0f, 1.0f);
            aJ.a(new TabLayout$a$1(this, i3, left, i4, right));
            aJ.lD.a(new u$2(aJ, new TabLayout$a$2(this, i)));
            aJ.lD.start();
        }
    }

    public final void draw(Canvas canvas) {
        super.draw(canvas);
        if (this.kL >= 0 && this.kM > this.kL) {
            canvas.drawRect((float) this.kL, (float) (getHeight() - this.kH), (float) this.kM, (float) getHeight(), this.kI);
        }
    }
}
