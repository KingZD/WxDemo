package android.support.v4.a;

import android.os.Build.VERSION;
import android.view.View;

public final class a {
    private static final c oT;

    static {
        if (VERSION.SDK_INT >= 12) {
            oT = new f();
        } else {
            oT = new e();
        }
    }

    public static g aW() {
        return oT.aW();
    }

    public static void v(View view) {
        oT.v(view);
    }
}
