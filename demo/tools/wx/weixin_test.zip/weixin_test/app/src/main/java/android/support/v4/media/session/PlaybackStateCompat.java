package android.support.v4.media.session;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import java.util.List;

public final class PlaybackStateCompat implements Parcelable {
    public static final Creator<PlaybackStateCompat> CREATOR = new Creator<PlaybackStateCompat>() {
        public final /* synthetic */ Object createFromParcel(Parcel parcel) {
            return new PlaybackStateCompat(parcel);
        }

        public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
            return new PlaybackStateCompat[i];
        }
    };
    private final Bundle mExtras;
    private final int mState;
    private final long vC;
    private final long vD;
    private final float vE;
    private final long vF;
    private final CharSequence vG;
    private final long vH;
    private List<PlaybackStateCompat$CustomAction> vI;
    private final long vJ;

    private PlaybackStateCompat(Parcel parcel) {
        this.mState = parcel.readInt();
        this.vC = parcel.readLong();
        this.vE = parcel.readFloat();
        this.vH = parcel.readLong();
        this.vD = parcel.readLong();
        this.vF = parcel.readLong();
        this.vG = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.vI = parcel.createTypedArrayList(PlaybackStateCompat$CustomAction.CREATOR);
        this.vJ = parcel.readLong();
        this.mExtras = parcel.readBundle();
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("PlaybackState {");
        stringBuilder.append("state=").append(this.mState);
        stringBuilder.append(", position=").append(this.vC);
        stringBuilder.append(", buffered position=").append(this.vD);
        stringBuilder.append(", speed=").append(this.vE);
        stringBuilder.append(", updated=").append(this.vH);
        stringBuilder.append(", actions=").append(this.vF);
        stringBuilder.append(", error=").append(this.vG);
        stringBuilder.append(", custom actions=").append(this.vI);
        stringBuilder.append(", active item id=").append(this.vJ);
        stringBuilder.append("}");
        return stringBuilder.toString();
    }

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.mState);
        parcel.writeLong(this.vC);
        parcel.writeFloat(this.vE);
        parcel.writeLong(this.vH);
        parcel.writeLong(this.vD);
        parcel.writeLong(this.vF);
        TextUtils.writeToParcel(this.vG, parcel, i);
        parcel.writeTypedList(this.vI);
        parcel.writeLong(this.vJ);
        parcel.writeBundle(this.mExtras);
    }
}
