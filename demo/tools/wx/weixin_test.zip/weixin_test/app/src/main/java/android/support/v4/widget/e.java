package android.support.v4.widget;

import android.content.Context;
import android.database.Cursor;
import android.database.DataSetObserver;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.FilterQueryProvider;
import android.widget.Filterable;

public abstract class e extends BaseAdapter implements f$a, Filterable {
    protected boolean BI;
    protected boolean BJ;
    public Cursor BK;
    protected int BL;
    protected e$a BM;
    protected DataSetObserver BN;
    protected f BO;
    protected FilterQueryProvider BP;
    public Context mContext;

    public abstract void a(View view, Cursor cursor);

    public abstract View newView(Context context, Cursor cursor, ViewGroup viewGroup);

    public final Cursor getCursor() {
        return this.BK;
    }

    public int getCount() {
        if (!this.BI || this.BK == null) {
            return 0;
        }
        return this.BK.getCount();
    }

    public Object getItem(int i) {
        if (!this.BI || this.BK == null) {
            return null;
        }
        this.BK.moveToPosition(i);
        return this.BK;
    }

    public long getItemId(int i) {
        if (this.BI && this.BK != null && this.BK.moveToPosition(i)) {
            return this.BK.getLong(this.BL);
        }
        return 0;
    }

    public boolean hasStableIds() {
        return true;
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        if (!this.BI) {
            throw new IllegalStateException("this should only be called when the cursor is valid");
        } else if (this.BK.moveToPosition(i)) {
            if (view == null) {
                view = newView(this.mContext, this.BK, viewGroup);
            }
            a(view, this.BK);
            return view;
        } else {
            throw new IllegalStateException("couldn't move cursor to position " + i);
        }
    }

    public View getDropDownView(int i, View view, ViewGroup viewGroup) {
        if (!this.BI) {
            return null;
        }
        this.BK.moveToPosition(i);
        if (view == null) {
            view = newDropDownView(this.mContext, this.BK, viewGroup);
        }
        a(view, this.BK);
        return view;
    }

    public View newDropDownView(Context context, Cursor cursor, ViewGroup viewGroup) {
        return newView(context, cursor, viewGroup);
    }

    public void changeCursor(Cursor cursor) {
        Cursor cursor2;
        if (cursor == this.BK) {
            cursor2 = null;
        } else {
            cursor2 = this.BK;
            if (cursor2 != null) {
                if (this.BM != null) {
                    cursor2.unregisterContentObserver(this.BM);
                }
                if (this.BN != null) {
                    cursor2.unregisterDataSetObserver(this.BN);
                }
            }
            this.BK = cursor;
            if (cursor != null) {
                if (this.BM != null) {
                    cursor.registerContentObserver(this.BM);
                }
                if (this.BN != null) {
                    cursor.registerDataSetObserver(this.BN);
                }
                this.BL = cursor.getColumnIndexOrThrow("_id");
                this.BI = true;
                notifyDataSetChanged();
            } else {
                this.BL = -1;
                this.BI = false;
                notifyDataSetInvalidated();
            }
        }
        if (cursor2 != null) {
            cursor2.close();
        }
    }

    public CharSequence convertToString(Cursor cursor) {
        return cursor == null ? "" : cursor.toString();
    }

    public Cursor runQueryOnBackgroundThread(CharSequence charSequence) {
        if (this.BP != null) {
            return this.BP.runQuery(charSequence);
        }
        return this.BK;
    }

    public Filter getFilter() {
        if (this.BO == null) {
            this.BO = new f(this);
        }
        return this.BO;
    }

    protected final void onContentChanged() {
        if (this.BJ && this.BK != null && !this.BK.isClosed()) {
            this.BI = this.BK.requery();
        }
    }
}
