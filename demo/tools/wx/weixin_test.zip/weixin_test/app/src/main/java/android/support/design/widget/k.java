package android.support.design.widget;

import android.support.v4.view.z;

class k extends j {
    private boolean iz;

    k(VisibilityAwareImageButton visibilityAwareImageButton, p pVar) {
        super(visibilityAwareImageButton, pVar);
    }

    boolean am() {
        return true;
    }

    final void an() {
        float rotation = this.iP.getRotation();
        if (this.iA != null) {
            o oVar = this.iA;
            float f = -rotation;
            if (oVar.fZ != f) {
                oVar.fZ = f;
                oVar.invalidateSelf();
            }
        }
        if (this.iK != null) {
            d dVar = this.iK;
            rotation = -rotation;
            if (rotation != dVar.fZ) {
                dVar.fZ = rotation;
                dVar.invalidateSelf();
            }
        }
    }

    final void a(l$a l_a, boolean z) {
        if (!this.iz && this.iP.getVisibility() == 0) {
            if (!z.ai(this.iP) || this.iP.isInEditMode()) {
                this.iP.i(8, false);
                if (l_a == null) {
                    return;
                }
                return;
            }
            this.iP.animate().cancel();
            this.iP.animate().scaleX(0.0f).scaleY(0.0f).alpha(0.0f).setDuration(200).setInterpolator(a.eO).setListener(new k$1(this, false, l_a));
        }
    }

    final void b(l$a l_a, boolean z) {
        if (!this.iz && this.iP.getVisibility() == 0) {
            return;
        }
        if (!z.ai(this.iP) || this.iP.isInEditMode()) {
            this.iP.i(0, false);
            this.iP.setAlpha(1.0f);
            this.iP.setScaleY(1.0f);
            this.iP.setScaleX(1.0f);
            return;
        }
        this.iP.animate().cancel();
        if (this.iP.getVisibility() != 0) {
            this.iP.setAlpha(0.0f);
            this.iP.setScaleY(0.0f);
            this.iP.setScaleX(0.0f);
        }
        this.iP.animate().scaleX(1.0f).scaleY(1.0f).alpha(1.0f).setDuration(200).setInterpolator(a.eP).setListener(new k$2(this, false, l_a));
    }
}
