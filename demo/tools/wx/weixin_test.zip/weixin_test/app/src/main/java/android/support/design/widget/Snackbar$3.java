package android.support.design.widget;

import android.support.design.widget.s.a;
import android.view.View;

class Snackbar$3 implements a {
    final /* synthetic */ Snackbar jH;

    Snackbar$3(Snackbar snackbar) {
        this.jH = snackbar;
    }

    public final void onDismiss(View view) {
        view.setVisibility(8);
        Snackbar.a(this.jH);
    }

    public final void H(int i) {
        switch (i) {
            case 0:
                q.aA().b(Snackbar.b(this.jH));
                return;
            case 1:
            case 2:
                q.aA().a(Snackbar.b(this.jH));
                return;
            default:
                return;
        }
    }
}
