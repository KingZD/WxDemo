package android.support.design.widget;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;

final class q {
    private static q jO;
    q$b jP;
    q$b jQ;
    private final Handler mHandler = new Handler(Looper.getMainLooper(), new q$1(this));
    final Object mLock = new Object();

    static q aA() {
        if (jO == null) {
            jO = new q();
        }
        return jO;
    }

    private q() {
    }

    public final void a(q$a q_a) {
        synchronized (this.mLock) {
            if (d(q_a)) {
                this.mHandler.removeCallbacksAndMessages(this.jP);
            }
        }
    }

    public final void b(q$a q_a) {
        synchronized (this.mLock) {
            if (d(q_a)) {
                b(this.jP);
            }
        }
    }

    public final boolean c(q$a q_a) {
        boolean z;
        synchronized (this.mLock) {
            z = d(q_a) || e(q_a);
        }
        return z;
    }

    final boolean a(q$b q_b) {
        if (((q$a) q_b.jS.get()) == null) {
            return false;
        }
        this.mHandler.removeCallbacksAndMessages(q_b);
        return true;
    }

    final boolean d(q$a q_a) {
        return this.jP != null && this.jP.f(q_a);
    }

    final boolean e(q$a q_a) {
        return this.jQ != null && this.jQ.f(q_a);
    }

    final void b(q$b q_b) {
        if (q_b.duration != -2) {
            int i = 2750;
            if (q_b.duration > 0) {
                i = q_b.duration;
            } else if (q_b.duration == -1) {
                i = 1500;
            }
            this.mHandler.removeCallbacksAndMessages(q_b);
            this.mHandler.sendMessageDelayed(Message.obtain(this.mHandler, 0, q_b), (long) i);
        }
    }
}
