package android.support.design.widget;

import android.graphics.Rect;
import android.os.Build.VERSION;
import android.view.View;
import android.view.ViewGroup;

final class x {
    private static final x$a lR;

    static {
        if (VERSION.SDK_INT >= 11) {
            lR = new x$c((byte) 0);
        } else {
            lR = new x$b((byte) 0);
        }
    }

    static void a(ViewGroup viewGroup, View view, Rect rect) {
        rect.set(0, 0, view.getWidth(), view.getHeight());
        lR.b(viewGroup, view, rect);
    }
}
