package android.support.v4.widget;

import android.view.animation.Animation;
import android.view.animation.Transformation;

class l$1 extends Animation {
    final /* synthetic */ l$a CV;
    final /* synthetic */ l CW;

    l$1(l lVar, l$a l_a) {
        this.CW = lVar;
        this.CV = l_a;
    }

    public final void applyTransformation(float f, Transformation transformation) {
        if (this.CW.CU) {
            l.a(this.CW, f, this.CV);
            return;
        }
        float b = l.b(this.CV);
        float f2 = this.CV.Df;
        float f3 = this.CV.De;
        float f4 = this.CV.Dg;
        l.b(this.CW, f, this.CV);
        if (f <= 0.5f) {
            float f5 = 0.8f - b;
            this.CV.C(f3 + (l.cH().getInterpolation(f / 0.5f) * f5));
        }
        if (f > 0.5f) {
            this.CV.D(((0.8f - b) * l.cH().getInterpolation((f - 0.5f) / 0.5f)) + f2);
        }
        this.CV.setRotation((0.25f * f) + f4);
        this.CW.setRotation((216.0f * f) + (1080.0f * (l.a(this.CW) / 5.0f)));
    }
}
