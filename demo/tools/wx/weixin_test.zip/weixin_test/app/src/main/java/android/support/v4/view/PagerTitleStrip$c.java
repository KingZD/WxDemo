package android.support.v4.view;

import android.widget.TextView;

class PagerTitleStrip$c implements PagerTitleStrip$b {
    PagerTitleStrip$c() {
    }

    public final void b(TextView textView) {
        textView.setSingleLine();
    }
}
