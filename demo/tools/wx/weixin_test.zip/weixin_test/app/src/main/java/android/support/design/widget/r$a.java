package android.support.design.widget;

import android.view.animation.Animation;

class r$a {
    final int[] jY;
    final Animation mAnimation;

    private r$a(int[] iArr, Animation animation) {
        this.jY = iArr;
        this.mAnimation = animation;
    }
}
