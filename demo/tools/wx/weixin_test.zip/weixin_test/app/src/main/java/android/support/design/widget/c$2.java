package android.support.design.widget;

class c$2 extends BottomSheetBehavior$a {
    final /* synthetic */ c fN;

    c$2(c cVar) {
        this.fN = cVar;
    }

    public final void v(int i) {
        if (i == 5) {
            this.fN.dismiss();
        }
    }

    public final void g(float f) {
    }
}
