package android.support.v4.media;

import android.os.Bundle;

public final class MediaBrowserServiceCompat$a {
    final Bundle mExtras;
    final String uM;
}
