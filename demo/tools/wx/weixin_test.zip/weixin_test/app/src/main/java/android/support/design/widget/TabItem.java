package android.support.design.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.design.a$i;
import android.support.v7.widget.ap;
import android.util.AttributeSet;
import android.view.View;

public final class TabItem extends View {
    final Drawable kj;
    final int kk;
    final CharSequence mText;

    public TabItem(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        ap a = ap.a(context, attributeSet, a$i.dw);
        this.mText = a.getText(a$i.dz);
        this.kj = a.getDrawable(a$i.dx);
        this.kk = a.getResourceId(a$i.dy, 0);
        a.ZE.recycle();
    }
}
