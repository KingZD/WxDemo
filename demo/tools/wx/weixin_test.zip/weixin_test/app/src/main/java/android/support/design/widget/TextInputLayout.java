package android.support.design.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff.Mode;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.ConstantState;
import android.graphics.drawable.DrawableContainer;
import android.os.Build.VERSION;
import android.os.Parcelable;
import android.support.design.a$c;
import android.support.design.a$g;
import android.support.design.a$i;
import android.support.design.a.h;
import android.support.v4.content.a;
import android.support.v4.view.z;
import android.support.v4.widget.Space;
import android.support.v7.widget.w;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.view.animation.AccelerateInterpolator;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class TextInputLayout extends LinearLayout {
    private u fd;
    private final f hb;
    private EditText le;
    boolean lf;
    CharSequence lg;
    private Paint lh;
    private LinearLayout li;
    private int lj;
    private boolean lk;
    private TextView ll;
    private int lm;
    private boolean ln;
    private CharSequence lo;
    private boolean lp;
    private TextView lq;
    private int lr;
    private int ls;
    private int lt;
    private boolean lu;
    private ColorStateList lv;
    private ColorStateList lw;
    private boolean lx;
    private boolean ly;

    public TextInputLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public TextInputLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet);
        this.hb = new f(this);
        t.p(context);
        setOrientation(1);
        setWillNotDraw(false);
        setAddStatesFromChildren(true);
        this.hb.b(a.eN);
        f fVar = this.hb;
        fVar.gH = new AccelerateInterpolator();
        fVar.aa();
        this.hb.y(8388659);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, a$i.dR, i, h.bZ);
        this.lf = obtainStyledAttributes.getBoolean(a$i.dV, true);
        setHint(obtainStyledAttributes.getText(a$i.dT));
        this.lx = obtainStyledAttributes.getBoolean(a$i.ec, true);
        if (obtainStyledAttributes.hasValue(a$i.dS)) {
            ColorStateList colorStateList = obtainStyledAttributes.getColorStateList(a$i.dS);
            this.lw = colorStateList;
            this.lv = colorStateList;
        }
        if (obtainStyledAttributes.getResourceId(a$i.dU, -1) != -1) {
            this.hb.z(obtainStyledAttributes.getResourceId(a$i.dU, 0));
            this.lw = ColorStateList.valueOf(this.hb.gm);
            if (this.le != null) {
                s(false);
                this.le.setLayoutParams(b(this.le.getLayoutParams()));
                this.le.requestLayout();
            }
        }
        this.lm = obtainStyledAttributes.getResourceId(a$i.dX, 0);
        boolean z = obtainStyledAttributes.getBoolean(a$i.dW, false);
        boolean z2 = obtainStyledAttributes.getBoolean(a$i.dY, false);
        int i2 = obtainStyledAttributes.getInt(a$i.dZ, -1);
        if (this.lr != i2) {
            if (i2 > 0) {
                this.lr = i2;
            } else {
                this.lr = -1;
            }
            if (this.lp) {
                M(this.le == null ? 0 : this.le.getText().length());
            }
        }
        this.ls = obtainStyledAttributes.getResourceId(a$i.ea, 0);
        this.lt = obtainStyledAttributes.getResourceId(a$i.eb, 0);
        obtainStyledAttributes.recycle();
        t(z);
        if (this.lp != z2) {
            if (z2) {
                this.lq = new TextView(getContext());
                this.lq.setMaxLines(1);
                try {
                    this.lq.setTextAppearance(getContext(), this.ls);
                } catch (Exception e) {
                    this.lq.setTextAppearance(getContext(), h.TextAppearance_AppCompat_Caption);
                    this.lq.setTextColor(a.d(getContext(), a$c.bm));
                }
                a(this.lq, -1);
                if (this.le == null) {
                    M(0);
                } else {
                    M(this.le.getText().length());
                }
            } else {
                a(this.lq);
                this.lq = null;
            }
            this.lp = z2;
        }
        if (z.F(this) == 0) {
            z.i(this, 1);
        }
        z.a(this, new TextInputLayout$a(this, (byte) 0));
    }

    public void addView(View view, int i, LayoutParams layoutParams) {
        if (view instanceof EditText) {
            EditText editText = (EditText) view;
            if (this.le != null) {
                throw new IllegalArgumentException("We already have an EditText, can only have one");
            }
            this.le = editText;
            f fVar = this.hb;
            Typeface typeface = this.le.getTypeface();
            fVar.gu = typeface;
            fVar.gt = typeface;
            fVar.aa();
            fVar = this.hb;
            float textSize = this.le.getTextSize();
            if (fVar.gj != textSize) {
                fVar.gj = textSize;
                fVar.aa();
            }
            int gravity = this.le.getGravity();
            this.hb.y((8388615 & gravity) | 48);
            this.hb.x(gravity);
            this.le.addTextChangedListener(new TextInputLayout$1(this));
            if (this.lv == null) {
                this.lv = this.le.getHintTextColors();
            }
            if (this.lf && TextUtils.isEmpty(this.lg)) {
                setHint(this.le.getHint());
                this.le.setHint(null);
            }
            if (this.lq != null) {
                M(this.le.getText().length());
            }
            if (this.li != null) {
                aG();
            }
            s(false);
            super.addView(view, 0, b(layoutParams));
            return;
        }
        super.addView(view, i, layoutParams);
    }

    private LinearLayout.LayoutParams b(LayoutParams layoutParams) {
        LinearLayout.LayoutParams layoutParams2 = layoutParams instanceof LinearLayout.LayoutParams ? (LinearLayout.LayoutParams) layoutParams : new LinearLayout.LayoutParams(layoutParams);
        if (this.lf) {
            if (this.lh == null) {
                this.lh = new Paint();
            }
            Paint paint = this.lh;
            f fVar = this.hb;
            paint.setTypeface(fVar.gt != null ? fVar.gt : Typeface.DEFAULT);
            this.lh.setTextSize(this.hb.gk);
            layoutParams2.topMargin = (int) (-this.lh.ascent());
        } else {
            layoutParams2.topMargin = 0;
        }
        return layoutParams2;
    }

    private void s(boolean z) {
        Object obj;
        Object obj2 = 1;
        Object obj3 = (this.le == null || TextUtils.isEmpty(this.le.getText())) ? null : 1;
        for (int i : getDrawableState()) {
            if (i == 16842908) {
                obj = 1;
                break;
            }
        }
        obj = null;
        if (TextUtils.isEmpty(getError())) {
            obj2 = null;
        }
        if (this.lv != null) {
            f fVar = this.hb;
            int defaultColor = this.lv.getDefaultColor();
            if (fVar.gl != defaultColor) {
                fVar.gl = defaultColor;
                fVar.aa();
            }
        }
        if (this.lu && this.lq != null) {
            this.hb.w(this.lq.getCurrentTextColor());
        } else if (obj != null && this.lw != null) {
            this.hb.w(this.lw.getDefaultColor());
        } else if (this.lv != null) {
            this.hb.w(this.lv.getDefaultColor());
        }
        if (obj3 == null && obj == null && obj2 == null) {
            if (this.fd != null && this.fd.lD.isRunning()) {
                this.fd.lD.cancel();
            }
            if (z && this.lx) {
                p(0.0f);
                return;
            } else {
                this.hb.h(0.0f);
                return;
            }
        }
        if (this.fd != null && this.fd.lD.isRunning()) {
            this.fd.lD.cancel();
        }
        if (z && this.lx) {
            p(1.0f);
        } else {
            this.hb.h(1.0f);
        }
    }

    private void setHint(CharSequence charSequence) {
        if (this.lf) {
            this.lg = charSequence;
            this.hb.setText(charSequence);
            sendAccessibilityEvent(2048);
        }
    }

    private void a(TextView textView, int i) {
        if (this.li == null) {
            this.li = new LinearLayout(getContext());
            this.li.setOrientation(0);
            addView(this.li, -1, -2);
            this.li.addView(new Space(getContext()), new LinearLayout.LayoutParams(0, 0, 1.0f));
            if (this.le != null) {
                aG();
            }
        }
        this.li.setVisibility(0);
        this.li.addView(textView, i);
        this.lj++;
    }

    private void aG() {
        z.c(this.li, z.O(this.le), 0, z.P(this.le), this.le.getPaddingBottom());
    }

    private void a(TextView textView) {
        if (this.li != null) {
            this.li.removeView(textView);
            int i = this.lj - 1;
            this.lj = i;
            if (i == 0) {
                this.li.setVisibility(8);
            }
        }
    }

    private void t(boolean z) {
        if (this.lk != z) {
            if (this.ll != null) {
                z.U(this.ll).cancel();
            }
            if (z) {
                this.ll = new TextView(getContext());
                try {
                    this.ll.setTextAppearance(getContext(), this.lm);
                } catch (Exception e) {
                    this.ll.setTextAppearance(getContext(), h.TextAppearance_AppCompat_Caption);
                    this.ll.setTextColor(a.d(getContext(), a$c.bm));
                }
                this.ll.setVisibility(4);
                z.N(this.ll);
                a(this.ll, 0);
            } else {
                this.ln = false;
                aH();
                a(this.ll);
                this.ll = null;
            }
            this.lk = z;
        }
    }

    private void M(int i) {
        boolean z = this.lu;
        if (this.lr == -1) {
            this.lq.setText(String.valueOf(i));
            this.lu = false;
        } else {
            this.lu = i > this.lr;
            if (z != this.lu) {
                this.lq.setTextAppearance(getContext(), this.lu ? this.lt : this.ls);
            }
            this.lq.setText(getContext().getString(a$g.bO, new Object[]{Integer.valueOf(i), Integer.valueOf(this.lr)}));
        }
        if (this.le != null && z != this.lu) {
            s(false);
            aH();
        }
    }

    private void aH() {
        Drawable background;
        int i = VERSION.SDK_INT;
        if (i == 21 && i == 22) {
            background = this.le.getBackground();
            if (!(background == null || this.ly)) {
                Drawable newDrawable = background.getConstantState().newDrawable();
                if (background instanceof DrawableContainer) {
                    DrawableContainer drawableContainer = (DrawableContainer) background;
                    ConstantState constantState = newDrawable.getConstantState();
                    this.ly = VERSION.SDK_INT >= 9 ? i.a(drawableContainer, constantState) : i.b(drawableContainer, constantState);
                }
                if (!this.ly) {
                    this.le.setBackgroundDrawable(newDrawable);
                    this.ly = true;
                }
            }
        }
        background = this.le.getBackground();
        if (background != null) {
            if (w.p(background)) {
                background = background.mutate();
            }
            if (this.ln && this.ll != null) {
                background.setColorFilter(android.support.v7.widget.h.a(this.ll.getCurrentTextColor(), Mode.SRC_IN));
            } else if (!this.lu || this.lq == null) {
                background.clearColorFilter();
                this.le.refreshDrawableState();
            } else {
                background.setColorFilter(android.support.v7.widget.h.a(this.lq.getCurrentTextColor(), Mode.SRC_IN));
            }
        }
    }

    public Parcelable onSaveInstanceState() {
        Parcelable textInputLayout$SavedState = new TextInputLayout$SavedState(super.onSaveInstanceState());
        if (this.ln) {
            textInputLayout$SavedState.lB = getError();
        }
        return textInputLayout$SavedState;
    }

    protected void onRestoreInstanceState(Parcelable parcelable) {
        if (parcelable instanceof TextInputLayout$SavedState) {
            TextInputLayout$SavedState textInputLayout$SavedState = (TextInputLayout$SavedState) parcelable;
            super.onRestoreInstanceState(textInputLayout$SavedState.getSuperState());
            CharSequence charSequence = textInputLayout$SavedState.lB;
            if (!TextUtils.equals(this.lo, charSequence)) {
                boolean z;
                this.lo = charSequence;
                if (!this.lk) {
                    if (!TextUtils.isEmpty(charSequence)) {
                        t(true);
                    }
                }
                boolean ai = z.ai(this);
                if (TextUtils.isEmpty(charSequence)) {
                    z = false;
                } else {
                    z = true;
                }
                this.ln = z;
                if (this.ln) {
                    this.ll.setText(charSequence);
                    this.ll.setVisibility(0);
                    if (ai) {
                        if (z.G(this.ll) == 1.0f) {
                            z.d(this.ll, 0.0f);
                        }
                        z.U(this.ll).s(1.0f).h(200).c(a.eP).a(new TextInputLayout$2(this)).start();
                    }
                } else if (this.ll.getVisibility() == 0) {
                    if (ai) {
                        z.U(this.ll).s(0.0f).h(200).c(a.eO).a(new TextInputLayout$3(this, charSequence)).start();
                    } else {
                        this.ll.setVisibility(4);
                    }
                }
                aH();
                s(true);
            }
            requestLayout();
            return;
        }
        super.onRestoreInstanceState(parcelable);
    }

    private CharSequence getError() {
        return this.lk ? this.lo : null;
    }

    public void draw(Canvas canvas) {
        super.draw(canvas);
        if (this.lf) {
            this.hb.draw(canvas);
        }
    }

    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        if (this.lf && this.le != null) {
            int left = this.le.getLeft() + this.le.getCompoundPaddingLeft();
            int right = this.le.getRight() - this.le.getCompoundPaddingRight();
            this.hb.b(left, this.le.getTop() + this.le.getCompoundPaddingTop(), right, this.le.getBottom() - this.le.getCompoundPaddingBottom());
            this.hb.c(left, getPaddingTop(), right, (i4 - i2) - getPaddingBottom());
            this.hb.aa();
        }
    }

    public void refreshDrawableState() {
        super.refreshDrawableState();
        s(z.ai(this));
    }

    private void p(float f) {
        if (this.hb.gd != f) {
            if (this.fd == null) {
                this.fd = aa.aJ();
                this.fd.setInterpolator(a.eM);
                this.fd.setDuration(200);
                this.fd.a(new u$c(this) {
                    final /* synthetic */ TextInputLayout lz;

                    {
                        this.lz = r1;
                    }

                    public final void a(u uVar) {
                        this.lz.hb.h(uVar.lD.aL());
                    }
                });
            }
            this.fd.p(this.hb.gd, f);
            this.fd.lD.start();
        }
    }
}
