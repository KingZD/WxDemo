package android.support.v4.a;

import android.view.View;
import java.util.ArrayList;
import java.util.List;

class e$a implements g {
    List<b> eY = new ArrayList();
    long mDuration = 200;
    long mStartTime;
    List<d> oU = new ArrayList();
    View oV;
    float oW = 0.0f;
    private boolean oX = false;
    private boolean oY = false;
    Runnable oZ = new Runnable(this) {
        final /* synthetic */ e$a pa;

        {
            this.pa = r1;
        }

        public final void run() {
            float drawingTime = (((float) (this.pa.oV.getDrawingTime() - this.pa.mStartTime)) * 1.0f) / ((float) this.pa.mDuration);
            if (drawingTime > 1.0f || this.pa.oV.getParent() == null) {
                drawingTime = 1.0f;
            }
            this.pa.oW = drawingTime;
            g gVar = this.pa;
            for (int size = gVar.oU.size() - 1; size >= 0; size--) {
                ((d) gVar.oU.get(size)).b(gVar);
            }
            if (this.pa.oW >= 1.0f) {
                this.pa.aY();
            } else {
                this.pa.oV.postDelayed(this.pa.oZ, 16);
            }
        }
    };

    public final void w(View view) {
        this.oV = view;
    }

    public final void a(b bVar) {
        this.eY.add(bVar);
    }

    public final void setDuration(long j) {
        if (!this.oX) {
            this.mDuration = j;
        }
    }

    public final void start() {
        if (!this.oX) {
            this.oX = true;
            for (int size = this.eY.size() - 1; size >= 0; size--) {
                this.eY.get(size);
            }
            this.oW = 0.0f;
            this.mStartTime = this.oV.getDrawingTime();
            this.oV.postDelayed(this.oZ, 16);
        }
    }

    final void aY() {
        for (int size = this.eY.size() - 1; size >= 0; size--) {
            ((b) this.eY.get(size)).a(this);
        }
    }

    public final void cancel() {
        if (!this.oY) {
            this.oY = true;
            if (this.oX) {
                for (int size = this.eY.size() - 1; size >= 0; size--) {
                    ((b) this.eY.get(size)).aX();
                }
            }
            aY();
        }
    }

    public final void a(d dVar) {
        this.oU.add(dVar);
    }

    public final float getAnimatedFraction() {
        return this.oW;
    }
}
