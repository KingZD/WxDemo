package android.support.v4.app;

import android.app.Notification;
import android.os.IInterface;

public interface s extends IInterface {
    void a(String str, int i, String str2, Notification notification);

    void b(String str, int i, String str2);

    void t(String str);
}
