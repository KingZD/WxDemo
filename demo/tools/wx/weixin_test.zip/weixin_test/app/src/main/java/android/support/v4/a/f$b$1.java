package android.support.v4.a;

import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;

class f$b$1 implements AnimatorUpdateListener {
    final /* synthetic */ d pf;
    final /* synthetic */ f$b pg;

    f$b$1(f$b f_b, d dVar) {
        this.pg = f_b;
        this.pf = dVar;
    }

    public final void onAnimationUpdate(ValueAnimator valueAnimator) {
        this.pf.b(this.pg);
    }
}
