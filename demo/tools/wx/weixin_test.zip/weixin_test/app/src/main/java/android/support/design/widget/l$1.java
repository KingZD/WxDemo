package android.support.design.widget;

import android.view.ViewTreeObserver.OnPreDrawListener;

class l$1 implements OnPreDrawListener {
    final /* synthetic */ l iS;

    l$1(l lVar) {
        this.iS = lVar;
    }

    public final boolean onPreDraw() {
        this.iS.an();
        return true;
    }
}
