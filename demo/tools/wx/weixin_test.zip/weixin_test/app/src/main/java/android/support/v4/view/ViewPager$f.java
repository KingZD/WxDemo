package android.support.v4.view;

import android.view.View;

public interface ViewPager$f {
    void h(View view, float f);
}
