package android.support.design.widget;

import android.view.animation.Interpolator;

abstract class u$e {
    abstract void a(u$e$a u_e_a);

    abstract void a(u$e$b u_e_b);

    abstract int aK();

    abstract float aL();

    abstract void cancel();

    abstract float getAnimatedFraction();

    abstract long getDuration();

    abstract void i(int i, int i2);

    abstract boolean isRunning();

    abstract void p(float f, float f2);

    abstract void setDuration(int i);

    abstract void setInterpolator(Interpolator interpolator);

    abstract void start();

    u$e() {
    }
}
