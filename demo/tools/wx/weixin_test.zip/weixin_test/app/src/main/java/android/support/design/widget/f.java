package android.support.design.widget;

import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Build.VERSION;
import android.support.design.a$i;
import android.support.v4.d.d;
import android.support.v4.d.e;
import android.support.v4.view.z;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.TextUtils.TruncateAt;
import android.view.View;
import android.view.animation.Interpolator;
import com.tencent.mm.plugin.gif.MMGIFException;
import org.xwalk.core.R$styleable;

final class f {
    private static final boolean ga = (VERSION.SDK_INT < 18);
    private static final Paint gb = null;
    private Paint gA;
    private float gB;
    private float gC;
    private float gD;
    private float gE;
    private boolean gF;
    private final TextPaint gG;
    Interpolator gH;
    private Interpolator gI;
    private float gJ;
    private float gK;
    private float gL;
    private int gM;
    private float gN;
    private float gO;
    private float gP;
    private int gQ;
    private boolean gc;
    float gd;
    private final Rect ge;
    private final Rect gf;
    private final RectF gg;
    private int gh = 16;
    private int gi = 16;
    float gj = 15.0f;
    float gk = 15.0f;
    int gl;
    int gm;
    private float gn;
    private float go;
    private float gp;
    private float gq;
    private float gr;
    private float gs;
    Typeface gt;
    Typeface gu;
    private Typeface gv;
    private CharSequence gw;
    private boolean gx;
    private boolean gy;
    private Bitmap gz;
    CharSequence mText;
    private final View mView;

    public f(View view) {
        this.mView = view;
        this.gG = new TextPaint(129);
        this.gf = new Rect();
        this.ge = new Rect();
        this.gg = new RectF();
    }

    final void b(Interpolator interpolator) {
        this.gI = interpolator;
        aa();
    }

    final void w(int i) {
        if (this.gm != i) {
            this.gm = i;
            aa();
        }
    }

    final void b(int i, int i2, int i3, int i4) {
        if (!a(this.ge, i, i2, i3, i4)) {
            this.ge.set(i, i2, i3, i4);
            this.gF = true;
            Y();
        }
    }

    final void c(int i, int i2, int i3, int i4) {
        if (!a(this.gf, i, i2, i3, i4)) {
            this.gf.set(i, i2, i3, i4);
            this.gF = true;
            Y();
        }
    }

    private void Y() {
        boolean z = this.gf.width() > 0 && this.gf.height() > 0 && this.ge.width() > 0 && this.ge.height() > 0;
        this.gc = z;
    }

    final void x(int i) {
        if (this.gh != i) {
            this.gh = i;
            aa();
        }
    }

    final void y(int i) {
        if (this.gi != i) {
            this.gi = i;
            aa();
        }
    }

    final void z(int i) {
        TypedArray obtainStyledAttributes = this.mView.getContext().obtainStyledAttributes(i, a$i.TextAppearance);
        if (obtainStyledAttributes.hasValue(a$i.TextAppearance_android_textColor)) {
            this.gm = obtainStyledAttributes.getColor(a$i.TextAppearance_android_textColor, this.gm);
        }
        if (obtainStyledAttributes.hasValue(a$i.TextAppearance_android_textSize)) {
            this.gk = (float) obtainStyledAttributes.getDimensionPixelSize(a$i.TextAppearance_android_textSize, (int) this.gk);
        }
        this.gM = obtainStyledAttributes.getInt(a$i.TextAppearance_android_shadowColor, 0);
        this.gK = obtainStyledAttributes.getFloat(a$i.TextAppearance_android_shadowDx, 0.0f);
        this.gL = obtainStyledAttributes.getFloat(a$i.TextAppearance_android_shadowDy, 0.0f);
        this.gJ = obtainStyledAttributes.getFloat(a$i.TextAppearance_android_shadowRadius, 0.0f);
        obtainStyledAttributes.recycle();
        if (VERSION.SDK_INT >= 16) {
            this.gt = B(i);
        }
        aa();
    }

    final void A(int i) {
        TypedArray obtainStyledAttributes = this.mView.getContext().obtainStyledAttributes(i, a$i.TextAppearance);
        if (obtainStyledAttributes.hasValue(a$i.TextAppearance_android_textColor)) {
            this.gl = obtainStyledAttributes.getColor(a$i.TextAppearance_android_textColor, this.gl);
        }
        if (obtainStyledAttributes.hasValue(a$i.TextAppearance_android_textSize)) {
            this.gj = (float) obtainStyledAttributes.getDimensionPixelSize(a$i.TextAppearance_android_textSize, (int) this.gj);
        }
        this.gQ = obtainStyledAttributes.getInt(a$i.TextAppearance_android_shadowColor, 0);
        this.gO = obtainStyledAttributes.getFloat(a$i.TextAppearance_android_shadowDx, 0.0f);
        this.gP = obtainStyledAttributes.getFloat(a$i.TextAppearance_android_shadowDy, 0.0f);
        this.gN = obtainStyledAttributes.getFloat(a$i.TextAppearance_android_shadowRadius, 0.0f);
        obtainStyledAttributes.recycle();
        if (VERSION.SDK_INT >= 16) {
            this.gu = B(i);
        }
        aa();
    }

    private Typeface B(int i) {
        TypedArray obtainStyledAttributes = this.mView.getContext().obtainStyledAttributes(i, new int[]{16843692});
        try {
            String string = obtainStyledAttributes.getString(0);
            if (string != null) {
                Typeface create = Typeface.create(string, 0);
                return create;
            }
            obtainStyledAttributes.recycle();
            return null;
        } finally {
            obtainStyledAttributes.recycle();
        }
    }

    final void h(float f) {
        if (f < 0.0f) {
            f = 0.0f;
        } else if (f > 1.0f) {
            f = 1.0f;
        }
        if (f != this.gd) {
            this.gd = f;
            Z();
        }
    }

    private void Z() {
        i(this.gd);
    }

    private void i(float f) {
        this.gg.left = a((float) this.ge.left, (float) this.gf.left, f, this.gH);
        this.gg.top = a(this.gn, this.go, f, this.gH);
        this.gg.right = a((float) this.ge.right, (float) this.gf.right, f, this.gH);
        this.gg.bottom = a((float) this.ge.bottom, (float) this.gf.bottom, f, this.gH);
        this.gr = a(this.gp, this.gq, f, this.gH);
        this.gs = a(this.gn, this.go, f, this.gH);
        j(a(this.gj, this.gk, f, this.gI));
        if (this.gm != this.gl) {
            this.gG.setColor(b(this.gl, this.gm, f));
        } else {
            this.gG.setColor(this.gm);
        }
        this.gG.setShadowLayer(a(this.gN, this.gJ, f, null), a(this.gO, this.gK, f, null), a(this.gP, this.gL, f, null), b(this.gQ, this.gM, f));
        z.E(this.mView);
    }

    public final void draw(Canvas canvas) {
        int save = canvas.save();
        if (this.gw != null && this.gc) {
            float f;
            float f2 = this.gr;
            float f3 = this.gs;
            int i = (!this.gy || this.gz == null) ? 0 : 1;
            if (i != 0) {
                f = this.gB * this.gD;
            } else {
                this.gG.ascent();
                f = 0.0f;
                this.gG.descent();
            }
            if (i != 0) {
                f3 += f;
            }
            if (this.gD != 1.0f) {
                canvas.scale(this.gD, this.gD, f2, f3);
            }
            if (i != 0) {
                canvas.drawBitmap(this.gz, f2, f3, this.gA);
            } else {
                canvas.drawText(this.gw, 0, this.gw.length(), f2, f3, this.gG);
            }
        }
        canvas.restoreToCount(save);
    }

    private void j(float f) {
        k(f);
        boolean z = ga && this.gD != 1.0f;
        this.gy = z;
        if (this.gy && this.gz == null && !this.ge.isEmpty() && !TextUtils.isEmpty(this.gw)) {
            i(0.0f);
            this.gB = this.gG.ascent();
            this.gC = this.gG.descent();
            int round = Math.round(this.gG.measureText(this.gw, 0, this.gw.length()));
            int round2 = Math.round(this.gC - this.gB);
            if (round > 0 && round2 > 0) {
                this.gz = Bitmap.createBitmap(round, round2, Config.ARGB_8888);
                new Canvas(this.gz).drawText(this.gw, 0, this.gw.length(), 0.0f, ((float) round2) - this.gG.descent(), this.gG);
                if (this.gA == null) {
                    this.gA = new Paint(3);
                }
            }
        }
        z.E(this.mView);
    }

    private void k(float f) {
        boolean z = true;
        if (this.mText != null) {
            float width;
            float f2;
            boolean z2;
            if (n(f, this.gk)) {
                width = (float) this.gf.width();
                float f3 = this.gk;
                this.gD = 1.0f;
                if (this.gv != this.gt) {
                    this.gv = this.gt;
                    f2 = width;
                    width = f3;
                    z2 = true;
                } else {
                    f2 = width;
                    width = f3;
                    z2 = false;
                }
            } else {
                f2 = (float) this.ge.width();
                width = this.gj;
                if (this.gv != this.gu) {
                    this.gv = this.gu;
                    z2 = true;
                } else {
                    z2 = false;
                }
                if (n(f, this.gj)) {
                    this.gD = 1.0f;
                } else {
                    this.gD = f / this.gj;
                }
            }
            if (f2 > 0.0f) {
                if (this.gE != width || this.gF || r0) {
                    z2 = true;
                } else {
                    z2 = false;
                }
                this.gE = width;
                this.gF = false;
            }
            if (this.gw == null || r0) {
                this.gG.setTextSize(this.gE);
                this.gG.setTypeface(this.gv);
                TextPaint textPaint = this.gG;
                if (this.gD != 1.0f) {
                    z2 = true;
                } else {
                    z2 = false;
                }
                textPaint.setLinearText(z2);
                CharSequence ellipsize = TextUtils.ellipsize(this.mText, this.gG, f2, TruncateAt.END);
                if (!TextUtils.equals(ellipsize, this.gw)) {
                    d dVar;
                    this.gw = ellipsize;
                    CharSequence charSequence = this.gw;
                    if (z.I(this.mView) != 1) {
                        z = false;
                    }
                    if (z) {
                        dVar = e.vZ;
                    } else {
                        dVar = e.vY;
                    }
                    this.gx = dVar.a(charSequence, charSequence.length());
                }
            }
        }
    }

    public final void aa() {
        int i = 1;
        float f = 0.0f;
        if (this.mView.getHeight() > 0 && this.mView.getWidth() > 0) {
            float measureText;
            float f2 = this.gE;
            k(this.gk);
            if (this.gw != null) {
                measureText = this.gG.measureText(this.gw, 0, this.gw.length());
            } else {
                measureText = 0.0f;
            }
            int absoluteGravity = android.support.v4.view.f.getAbsoluteGravity(this.gi, this.gx ? 1 : 0);
            switch (absoluteGravity & MMGIFException.D_GIF_ERR_IMAGE_DEFECT) {
                case R$styleable.AppCompatTheme_homeAsUpIndicator /*48*/:
                    this.go = ((float) this.gf.top) - this.gG.ascent();
                    break;
                case 80:
                    this.go = (float) this.gf.bottom;
                    break;
                default:
                    this.go = (((this.gG.descent() - this.gG.ascent()) / 2.0f) - this.gG.descent()) + ((float) this.gf.centerY());
                    break;
            }
            switch (absoluteGravity & 8388615) {
                case 1:
                    this.gq = ((float) this.gf.centerX()) - (measureText / 2.0f);
                    break;
                case 5:
                    this.gq = ((float) this.gf.right) - measureText;
                    break;
                default:
                    this.gq = (float) this.gf.left;
                    break;
            }
            k(this.gj);
            if (this.gw != null) {
                f = this.gG.measureText(this.gw, 0, this.gw.length());
            }
            int i2 = this.gh;
            if (!this.gx) {
                i = 0;
            }
            i2 = android.support.v4.view.f.getAbsoluteGravity(i2, i);
            switch (i2 & MMGIFException.D_GIF_ERR_IMAGE_DEFECT) {
                case R$styleable.AppCompatTheme_homeAsUpIndicator /*48*/:
                    this.gn = ((float) this.ge.top) - this.gG.ascent();
                    break;
                case 80:
                    this.gn = (float) this.ge.bottom;
                    break;
                default:
                    this.gn = (((this.gG.descent() - this.gG.ascent()) / 2.0f) - this.gG.descent()) + ((float) this.ge.centerY());
                    break;
            }
            switch (i2 & 8388615) {
                case 1:
                    this.gp = ((float) this.ge.centerX()) - (f / 2.0f);
                    break;
                case 5:
                    this.gp = ((float) this.ge.right) - f;
                    break;
                default:
                    this.gp = (float) this.ge.left;
                    break;
            }
            ab();
            j(f2);
            Z();
        }
    }

    final void setText(CharSequence charSequence) {
        if (charSequence == null || !charSequence.equals(this.mText)) {
            this.mText = charSequence;
            this.gw = null;
            ab();
            aa();
        }
    }

    private void ab() {
        if (this.gz != null) {
            this.gz.recycle();
            this.gz = null;
        }
    }

    private static boolean n(float f, float f2) {
        return Math.abs(f - f2) < 0.001f;
    }

    private static int b(int i, int i2, float f) {
        float f2 = 1.0f - f;
        return Color.argb((int) ((((float) Color.alpha(i)) * f2) + (((float) Color.alpha(i2)) * f)), (int) ((((float) Color.red(i)) * f2) + (((float) Color.red(i2)) * f)), (int) ((((float) Color.green(i)) * f2) + (((float) Color.green(i2)) * f)), (int) ((f2 * ((float) Color.blue(i))) + (((float) Color.blue(i2)) * f)));
    }

    private static float a(float f, float f2, float f3, Interpolator interpolator) {
        if (interpolator != null) {
            f3 = interpolator.getInterpolation(f3);
        }
        return a.b(f, f2, f3);
    }

    private static boolean a(Rect rect, int i, int i2, int i3, int i4) {
        return rect.left == i && rect.top == i2 && rect.right == i3 && rect.bottom == i4;
    }
}
