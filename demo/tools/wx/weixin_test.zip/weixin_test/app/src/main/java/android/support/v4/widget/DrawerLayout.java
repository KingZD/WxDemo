package android.support.v4.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.os.SystemClock;
import android.support.v4.view.af;
import android.support.v4.view.z;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.BaseSavedState;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import com.tencent.mm.plugin.gif.MMGIFException;
import com.tencent.smtt.sdk.WebView;
import java.util.ArrayList;
import java.util.List;

public class DrawerLayout extends ViewGroup implements h {
    private static final boolean BS = (VERSION.SDK_INT >= 19);
    private static final boolean BT;
    static final c Cv;
    private static final int[] yK = new int[]{16842931};
    private final b BU;
    private float BV;
    private int BW;
    private int BX;
    private float BY;
    private Paint BZ;
    final u Ca;
    final u Cb;
    private final g Cc;
    private final g Cd;
    int Ce;
    private int Cf;
    private int Cg;
    private int Ch;
    private int Ci;
    private boolean Cj;
    boolean Ck;
    private Drawable Cl;
    private Drawable Cm;
    CharSequence Cn;
    CharSequence Co;
    private Object Cp;
    private Drawable Cq;
    private Drawable Cr;
    private Drawable Cs;
    private Drawable Ct;
    private final ArrayList<View> Cu;
    List<f> eY;
    private boolean hJ;
    private Drawable hK;
    private boolean mInLayout;
    private float ya;
    private float yb;
    private boolean zv;

    public static class LayoutParams extends MarginLayoutParams {
        private float Cx;
        private boolean Cy;
        private int Cz;
        public int gravity = 0;

        static /* synthetic */ int b(LayoutParams layoutParams, int i) {
            int i2 = layoutParams.Cz | i;
            layoutParams.Cz = i2;
            return i2;
        }

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, DrawerLayout.yK);
            this.gravity = obtainStyledAttributes.getInt(0, 0);
            obtainStyledAttributes.recycle();
        }

        public LayoutParams() {
            super(-1, -1);
        }

        public LayoutParams(LayoutParams layoutParams) {
            super(layoutParams);
            this.gravity = layoutParams.gravity;
        }

        public LayoutParams(android.view.ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public LayoutParams(MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
        }
    }

    protected static class SavedState extends BaseSavedState {
        public static final Creator<SavedState> CREATOR = new Creator<SavedState>() {
            public final /* synthetic */ Object createFromParcel(Parcel parcel) {
                return new SavedState(parcel);
            }

            public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
                return new SavedState[i];
            }
        };
        int CA = 0;
        int CB;
        int CC;
        int CD;
        int CE;

        public SavedState(Parcel parcel) {
            super(parcel);
            this.CA = parcel.readInt();
            this.CB = parcel.readInt();
            this.CC = parcel.readInt();
            this.CD = parcel.readInt();
            this.CE = parcel.readInt();
        }

        public SavedState(Parcelable parcelable) {
            super(parcelable);
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.CA);
            parcel.writeInt(this.CB);
            parcel.writeInt(this.CC);
            parcel.writeInt(this.CD);
            parcel.writeInt(this.CE);
        }
    }

    interface c {
        int H(Object obj);

        void a(View view, Object obj, int i);

        void a(MarginLayoutParams marginLayoutParams, Object obj, int i);

        void aA(View view);

        Drawable y(Context context);
    }

    public interface f {
        void cC();

        void cD();

        void y(float f);
    }

    class a extends android.support.v4.view.a {
        final /* synthetic */ DrawerLayout Cw;
        private final Rect ha = new Rect();

        a(DrawerLayout drawerLayout) {
            this.Cw = drawerLayout;
        }

        public final void a(View view, android.support.v4.view.a.b bVar) {
            if (DrawerLayout.BS) {
                super.a(view, bVar);
            } else {
                android.support.v4.view.a.b a = android.support.v4.view.a.b.a(bVar);
                super.a(view, a);
                bVar.setSource(view);
                ViewParent J = z.J(view);
                if (J instanceof View) {
                    bVar.setParent((View) J);
                }
                Rect rect = this.ha;
                a.getBoundsInParent(rect);
                bVar.setBoundsInParent(rect);
                a.getBoundsInScreen(rect);
                bVar.setBoundsInScreen(rect);
                bVar.setVisibleToUser(a.isVisibleToUser());
                bVar.setPackageName(a.getPackageName());
                bVar.setClassName(a.getClassName());
                bVar.setContentDescription(a.getContentDescription());
                bVar.setEnabled(a.isEnabled());
                bVar.setClickable(a.isClickable());
                bVar.setFocusable(a.isFocusable());
                bVar.setFocused(a.isFocused());
                bVar.setAccessibilityFocused(a.isAccessibilityFocused());
                bVar.setSelected(a.isSelected());
                bVar.setLongClickable(a.isLongClickable());
                bVar.addAction(a.getActions());
                a.recycle();
                ViewGroup viewGroup = (ViewGroup) view;
                int childCount = viewGroup.getChildCount();
                for (int i = 0; i < childCount; i++) {
                    View childAt = viewGroup.getChildAt(i);
                    if (DrawerLayout.az(childAt)) {
                        bVar.addChild(childAt);
                    }
                }
            }
            bVar.setClassName(DrawerLayout.class.getName());
            bVar.setFocusable(false);
            bVar.setFocused(false);
            bVar.a(android.support.v4.view.a.b.a.Ai);
            bVar.a(android.support.v4.view.a.b.a.Aj);
        }

        public final void onInitializeAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
            super.onInitializeAccessibilityEvent(view, accessibilityEvent);
            accessibilityEvent.setClassName(DrawerLayout.class.getName());
        }

        public final boolean dispatchPopulateAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
            if (accessibilityEvent.getEventType() != 32) {
                return super.dispatchPopulateAccessibilityEvent(view, accessibilityEvent);
            }
            List text = accessibilityEvent.getText();
            View a = this.Cw.cA();
            if (a != null) {
                int au = this.Cw.au(a);
                View view2 = this.Cw;
                au = android.support.v4.view.f.getAbsoluteGravity(au, z.I(view2));
                Object obj = au == 3 ? view2.Cn : au == 5 ? view2.Co : null;
                if (obj != null) {
                    text.add(obj);
                }
            }
            return true;
        }

        public final boolean onRequestSendAccessibilityEvent(ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent) {
            if (DrawerLayout.BS || DrawerLayout.az(view)) {
                return super.onRequestSendAccessibilityEvent(viewGroup, view, accessibilityEvent);
            }
            return false;
        }
    }

    final class b extends android.support.v4.view.a {
        final /* synthetic */ DrawerLayout Cw;

        b(DrawerLayout drawerLayout) {
            this.Cw = drawerLayout;
        }

        public final void a(View view, android.support.v4.view.a.b bVar) {
            super.a(view, bVar);
            if (!DrawerLayout.az(view)) {
                bVar.setParent(null);
            }
        }
    }

    static class d implements c {
        d() {
        }

        public final void aA(View view) {
            g.aA(view);
        }

        public final void a(View view, Object obj, int i) {
            g.a(view, obj, i);
        }

        public final void a(MarginLayoutParams marginLayoutParams, Object obj, int i) {
            g.a(marginLayoutParams, obj, i);
        }

        public final int H(Object obj) {
            return g.H(obj);
        }

        public final Drawable y(Context context) {
            return g.y(context);
        }
    }

    static class e implements c {
        e() {
        }

        public final void aA(View view) {
        }

        public final void a(View view, Object obj, int i) {
        }

        public final void a(MarginLayoutParams marginLayoutParams, Object obj, int i) {
        }

        public final int H(Object obj) {
            return 0;
        }

        public final Drawable y(Context context) {
            return null;
        }
    }

    private class g extends android.support.v4.widget.u.a {
        final int CF;
        u CG;
        private final Runnable CH = new Runnable(this) {
            final /* synthetic */ g CI;

            {
                this.CI = r1;
            }

            public final void run() {
                View view;
                int i;
                int i2 = 0;
                g gVar = this.CI;
                int i3 = gVar.CG.Fq;
                boolean z = gVar.CF == 3;
                int i4;
                if (z) {
                    View ap = gVar.Cw.ap(3);
                    i4 = (ap != null ? -ap.getWidth() : 0) + i3;
                    view = ap;
                    i = i4;
                } else {
                    i4 = gVar.Cw.getWidth() - i3;
                    view = gVar.Cw.ap(5);
                    i = i4;
                }
                if (view == null) {
                    return;
                }
                if (((z && view.getLeft() < i) || (!z && view.getLeft() > i)) && gVar.Cw.as(view) == 0) {
                    LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
                    gVar.CG.e(view, i, view.getTop());
                    layoutParams.Cy = true;
                    gVar.Cw.invalidate();
                    gVar.cE();
                    DrawerLayout drawerLayout = gVar.Cw;
                    if (!drawerLayout.Ck) {
                        long uptimeMillis = SystemClock.uptimeMillis();
                        MotionEvent obtain = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
                        i = drawerLayout.getChildCount();
                        while (i2 < i) {
                            drawerLayout.getChildAt(i2).dispatchTouchEvent(obtain);
                            i2++;
                        }
                        obtain.recycle();
                        drawerLayout.Ck = true;
                    }
                }
            }
        };
        final /* synthetic */ DrawerLayout Cw;

        public g(DrawerLayout drawerLayout, int i) {
            this.Cw = drawerLayout;
            this.CF = i;
        }

        public final void cy() {
            this.Cw.removeCallbacks(this.CH);
        }

        public final boolean b(View view, int i) {
            return DrawerLayout.aw(view) && this.Cw.m(view, this.CF) && this.Cw.as(view) == 0;
        }

        public final void u(int i) {
            DrawerLayout drawerLayout = this.Cw;
            View view = this.CG.Ft;
            int i2 = drawerLayout.Ca.Ff;
            int i3 = drawerLayout.Cb.Ff;
            i3 = (i2 == 1 || i3 == 1) ? 1 : (i2 == 2 || i3 == 2) ? 2 : 0;
            if (view != null && i == 0) {
                LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
                if (layoutParams.Cx == 0.0f) {
                    layoutParams = (LayoutParams) view.getLayoutParams();
                    if ((layoutParams.Cz & 1) == 1) {
                        layoutParams.Cz = 0;
                        if (drawerLayout.eY != null) {
                            for (i2 = drawerLayout.eY.size() - 1; i2 >= 0; i2--) {
                                ((f) drawerLayout.eY.get(i2)).cD();
                            }
                        }
                        drawerLayout.d(view, false);
                        if (drawerLayout.hasWindowFocus()) {
                            View rootView = drawerLayout.getRootView();
                            if (rootView != null) {
                                rootView.sendAccessibilityEvent(32);
                            }
                        }
                    }
                } else if (layoutParams.Cx == 1.0f) {
                    layoutParams = (LayoutParams) view.getLayoutParams();
                    if ((layoutParams.Cz & 1) == 0) {
                        layoutParams.Cz = 1;
                        if (drawerLayout.eY != null) {
                            for (i2 = drawerLayout.eY.size() - 1; i2 >= 0; i2--) {
                                ((f) drawerLayout.eY.get(i2)).cC();
                            }
                        }
                        drawerLayout.d(view, true);
                        if (drawerLayout.hasWindowFocus()) {
                            drawerLayout.sendAccessibilityEvent(32);
                        }
                        view.requestFocus();
                    }
                }
            }
            if (i3 != drawerLayout.Ce) {
                drawerLayout.Ce = i3;
                if (drawerLayout.eY != null) {
                    for (int size = drawerLayout.eY.size() - 1; size >= 0; size--) {
                        drawerLayout.eY.get(size);
                    }
                }
            }
        }

        public final void a(View view, int i, int i2) {
            float f;
            int width = view.getWidth();
            if (this.Cw.m(view, 3)) {
                f = ((float) (width + i)) / ((float) width);
            } else {
                f = ((float) (this.Cw.getWidth() - i)) / ((float) width);
            }
            this.Cw.i(view, f);
            view.setVisibility(f == 0.0f ? 4 : 0);
            this.Cw.invalidate();
        }

        public final void f(View view, int i) {
            ((LayoutParams) view.getLayoutParams()).Cy = false;
            cE();
        }

        final void cE() {
            int i = 3;
            if (this.CF == 3) {
                i = 5;
            }
            View ap = this.Cw.ap(i);
            if (ap != null) {
                this.Cw.ay(ap);
            }
        }

        public final void a(View view, float f, float f2) {
            int i;
            float at = DrawerLayout.at(view);
            int width = view.getWidth();
            if (this.Cw.m(view, 3)) {
                i = (f > 0.0f || (f == 0.0f && at > 0.5f)) ? 0 : -width;
            } else {
                i = this.Cw.getWidth();
                if (f < 0.0f || (f == 0.0f && at > 0.5f)) {
                    i -= width;
                }
            }
            this.CG.v(i, view.getTop());
            this.Cw.invalidate();
        }

        public final void cF() {
            this.Cw.postDelayed(this.CH, 160);
        }

        public final void s(int i, int i2) {
            View ap;
            if ((i & 1) == 1) {
                ap = this.Cw.ap(3);
            } else {
                ap = this.Cw.ap(5);
            }
            if (ap != null && this.Cw.as(ap) == 0) {
                this.CG.n(ap, i2);
            }
        }

        public final int s(View view) {
            return DrawerLayout.aw(view) ? view.getWidth() : 0;
        }

        public final int d(View view, int i) {
            if (this.Cw.m(view, 3)) {
                return Math.max(-view.getWidth(), Math.min(i, 0));
            }
            int width = this.Cw.getWidth();
            return Math.max(width - view.getWidth(), Math.min(i, width));
        }

        public final int c(View view, int i) {
            return view.getTop();
        }
    }

    static /* synthetic */ boolean az(View view) {
        return (z.F(view) == 4 || z.F(view) == 2) ? false : true;
    }

    static {
        boolean z = true;
        if (VERSION.SDK_INT < 21) {
            z = false;
        }
        BT = z;
        if (VERSION.SDK_INT >= 21) {
            Cv = new d();
        } else {
            Cv = new e();
        }
    }

    public DrawerLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public DrawerLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.BU = new b(this);
        this.BX = -1728053248;
        this.BZ = new Paint();
        this.zv = true;
        this.Cf = 3;
        this.Cg = 3;
        this.Ch = 3;
        this.Ci = 3;
        this.Cq = null;
        this.Cr = null;
        this.Cs = null;
        this.Ct = null;
        setDescendantFocusability(262144);
        float f = getResources().getDisplayMetrics().density;
        this.BW = (int) ((64.0f * f) + 0.5f);
        float f2 = 400.0f * f;
        this.Cc = new g(this, 3);
        this.Cd = new g(this, 5);
        this.Ca = u.a((ViewGroup) this, 1.0f, this.Cc);
        this.Ca.Fr = 1;
        this.Ca.Fp = f2;
        this.Cc.CG = this.Ca;
        this.Cb = u.a((ViewGroup) this, 1.0f, this.Cd);
        this.Cb.Fr = 2;
        this.Cb.Fp = f2;
        this.Cd.CG = this.Cb;
        setFocusableInTouchMode(true);
        z.i(this, 1);
        z.a((View) this, new a(this));
        af.d(this);
        if (z.Z(this)) {
            Cv.aA(this);
            this.hK = Cv.y(context);
        }
        this.BV = f * 10.0f;
        this.Cu = new ArrayList();
    }

    public final void l(Object obj, boolean z) {
        this.Cp = obj;
        this.hJ = z;
        boolean z2 = !z && getBackground() == null;
        setWillNotDraw(z2);
        requestLayout();
    }

    private void r(int i, int i2) {
        int absoluteGravity = android.support.v4.view.f.getAbsoluteGravity(i2, z.I(this));
        switch (i2) {
            case 3:
                this.Cf = i;
                break;
            case 5:
                this.Cg = i;
                break;
            case 8388611:
                this.Ch = i;
                break;
            case 8388613:
                this.Ci = i;
                break;
        }
        if (i != 0) {
            (absoluteGravity == 3 ? this.Ca : this.Cb).cancel();
        }
        View ap;
        switch (i) {
            case 1:
                ap = ap(absoluteGravity);
                if (ap != null) {
                    ay(ap);
                    return;
                }
                return;
            case 2:
                ap = ap(absoluteGravity);
                if (ap != null) {
                    ax(ap);
                    return;
                }
                return;
            default:
                return;
        }
    }

    public final int as(View view) {
        if (aw(view)) {
            int i = ((LayoutParams) view.getLayoutParams()).gravity;
            int I = z.I(this);
            switch (i) {
                case 3:
                    if (this.Cf != 3) {
                        return this.Cf;
                    }
                    i = I == 0 ? this.Ch : this.Ci;
                    if (i != 3) {
                        return i;
                    }
                    break;
                case 5:
                    if (this.Cg != 3) {
                        return this.Cg;
                    }
                    i = I == 0 ? this.Ci : this.Ch;
                    if (i != 3) {
                        return i;
                    }
                    break;
                case 8388611:
                    if (this.Ch != 3) {
                        return this.Ch;
                    }
                    i = I == 0 ? this.Cf : this.Cg;
                    if (i != 3) {
                        return i;
                    }
                    break;
                case 8388613:
                    if (this.Ci != 3) {
                        return this.Ci;
                    }
                    i = I == 0 ? this.Cg : this.Cf;
                    if (i != 3) {
                        return i;
                    }
                    break;
            }
            return 0;
        }
        throw new IllegalArgumentException("View " + view + " is not a drawer");
    }

    final void d(View view, boolean z) {
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            if ((z || aw(childAt)) && !(z && childAt == view)) {
                z.i(childAt, 4);
            } else {
                z.i(childAt, 1);
            }
        }
    }

    final void i(View view, float f) {
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        if (f != layoutParams.Cx) {
            layoutParams.Cx = f;
            if (this.eY != null) {
                for (int size = this.eY.size() - 1; size >= 0; size--) {
                    ((f) this.eY.get(size)).y(f);
                }
            }
        }
    }

    static float at(View view) {
        return ((LayoutParams) view.getLayoutParams()).Cx;
    }

    final int au(View view) {
        return android.support.v4.view.f.getAbsoluteGravity(((LayoutParams) view.getLayoutParams()).gravity, z.I(this));
    }

    final boolean m(View view, int i) {
        return (au(view) & i) == i;
    }

    private View cz() {
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            if ((((LayoutParams) childAt.getLayoutParams()).Cz & 1) == 1) {
                return childAt;
            }
        }
        return null;
    }

    final View ap(int i) {
        int absoluteGravity = android.support.v4.view.f.getAbsoluteGravity(i, z.I(this)) & 7;
        int childCount = getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            if ((au(childAt) & 7) == absoluteGravity) {
                return childAt;
            }
        }
        return null;
    }

    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.zv = true;
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.zv = true;
    }

    protected void onMeasure(int i, int i2) {
        Object obj;
        int I;
        Object obj2;
        Object obj3;
        int childCount;
        int i3;
        View childAt;
        MarginLayoutParams marginLayoutParams;
        int absoluteGravity;
        int au;
        Object obj4;
        int mode = MeasureSpec.getMode(i);
        int mode2 = MeasureSpec.getMode(i2);
        int size = MeasureSpec.getSize(i);
        int size2 = MeasureSpec.getSize(i2);
        if (!(mode == 1073741824 && mode2 == 1073741824)) {
            if (isInEditMode()) {
                if (mode != Integer.MIN_VALUE && mode == 0) {
                    size = 300;
                }
                if (mode2 != Integer.MIN_VALUE && mode2 == 0) {
                    mode = size;
                    size = 300;
                    setMeasuredDimension(mode, size);
                    if (this.Cp == null && z.Z(this)) {
                        obj = 1;
                    } else {
                        obj = null;
                    }
                    I = z.I(this);
                    obj2 = null;
                    obj3 = null;
                    childCount = getChildCount();
                    for (i3 = 0; i3 < childCount; i3++) {
                        childAt = getChildAt(i3);
                        if (childAt.getVisibility() != 8) {
                            marginLayoutParams = (LayoutParams) childAt.getLayoutParams();
                            if (obj != null) {
                                absoluteGravity = android.support.v4.view.f.getAbsoluteGravity(marginLayoutParams.gravity, I);
                                if (z.Z(childAt)) {
                                    Cv.a(marginLayoutParams, this.Cp, absoluteGravity);
                                } else {
                                    Cv.a(childAt, this.Cp, absoluteGravity);
                                }
                            }
                            if (av(childAt)) {
                                childAt.measure(MeasureSpec.makeMeasureSpec((mode - marginLayoutParams.leftMargin) - marginLayoutParams.rightMargin, 1073741824), MeasureSpec.makeMeasureSpec((size - marginLayoutParams.topMargin) - marginLayoutParams.bottomMargin, 1073741824));
                            } else if (aw(childAt)) {
                                throw new IllegalStateException("Child " + childAt + " at index " + i3 + " does not have a valid layout_gravity - must be Gravity.LEFT, Gravity.RIGHT or Gravity.NO_GRAVITY");
                            } else {
                                if (BT && z.W(childAt) != this.BV) {
                                    z.g(childAt, this.BV);
                                }
                                au = au(childAt) & 7;
                                obj4 = au != 3 ? 1 : null;
                                if ((obj4 != null || obj2 == null) && (obj4 != null || obj3 == null)) {
                                    if (obj4 == null) {
                                        obj2 = 1;
                                    } else {
                                        obj3 = 1;
                                    }
                                    childAt.measure(getChildMeasureSpec(i, (this.BW + marginLayoutParams.leftMargin) + marginLayoutParams.rightMargin, marginLayoutParams.width), getChildMeasureSpec(i2, marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, marginLayoutParams.height));
                                } else {
                                    StringBuilder stringBuilder = new StringBuilder("Child drawer has absolute gravity ");
                                    String toHexString = (au & 3) == 3 ? "LEFT" : (au & 5) == 5 ? "RIGHT" : Integer.toHexString(au);
                                    throw new IllegalStateException(stringBuilder.append(toHexString).append(" but this DrawerLayout already has a drawer view along that edge").toString());
                                }
                            }
                        }
                    }
                }
            }
            throw new IllegalArgumentException("DrawerLayout must be measured with MeasureSpec.EXACTLY.");
        }
        mode = size;
        size = size2;
        setMeasuredDimension(mode, size);
        if (this.Cp == null) {
        }
        obj = null;
        I = z.I(this);
        obj2 = null;
        obj3 = null;
        childCount = getChildCount();
        for (i3 = 0; i3 < childCount; i3++) {
            childAt = getChildAt(i3);
            if (childAt.getVisibility() != 8) {
                marginLayoutParams = (LayoutParams) childAt.getLayoutParams();
                if (obj != null) {
                    absoluteGravity = android.support.v4.view.f.getAbsoluteGravity(marginLayoutParams.gravity, I);
                    if (z.Z(childAt)) {
                        Cv.a(marginLayoutParams, this.Cp, absoluteGravity);
                    } else {
                        Cv.a(childAt, this.Cp, absoluteGravity);
                    }
                }
                if (av(childAt)) {
                    childAt.measure(MeasureSpec.makeMeasureSpec((mode - marginLayoutParams.leftMargin) - marginLayoutParams.rightMargin, 1073741824), MeasureSpec.makeMeasureSpec((size - marginLayoutParams.topMargin) - marginLayoutParams.bottomMargin, 1073741824));
                } else if (aw(childAt)) {
                    throw new IllegalStateException("Child " + childAt + " at index " + i3 + " does not have a valid layout_gravity - must be Gravity.LEFT, Gravity.RIGHT or Gravity.NO_GRAVITY");
                } else {
                    z.g(childAt, this.BV);
                    au = au(childAt) & 7;
                    if (au != 3) {
                    }
                    if (obj4 != null) {
                    }
                    if (obj4 == null) {
                        obj3 = 1;
                    } else {
                        obj2 = 1;
                    }
                    childAt.measure(getChildMeasureSpec(i, (this.BW + marginLayoutParams.leftMargin) + marginLayoutParams.rightMargin, marginLayoutParams.width), getChildMeasureSpec(i2, marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, marginLayoutParams.height));
                }
            }
        }
    }

    private static boolean c(Drawable drawable, int i) {
        if (drawable == null || !android.support.v4.b.a.a.d(drawable)) {
            return false;
        }
        android.support.v4.b.a.a.b(drawable, i);
        return true;
    }

    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        this.mInLayout = true;
        int i5 = i3 - i;
        int childCount = getChildCount();
        for (int i6 = 0; i6 < childCount; i6++) {
            View childAt = getChildAt(i6);
            if (childAt.getVisibility() != 8) {
                LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
                if (av(childAt)) {
                    childAt.layout(layoutParams.leftMargin, layoutParams.topMargin, layoutParams.leftMargin + childAt.getMeasuredWidth(), layoutParams.topMargin + childAt.getMeasuredHeight());
                } else {
                    int a;
                    float f;
                    int measuredWidth = childAt.getMeasuredWidth();
                    int measuredHeight = childAt.getMeasuredHeight();
                    if (m(childAt, 3)) {
                        a = ((int) (((float) measuredWidth) * layoutParams.Cx)) + (-measuredWidth);
                        f = ((float) (measuredWidth + a)) / ((float) measuredWidth);
                    } else {
                        a = i5 - ((int) (((float) measuredWidth) * layoutParams.Cx));
                        f = ((float) (i5 - a)) / ((float) measuredWidth);
                    }
                    Object obj = f != layoutParams.Cx ? 1 : null;
                    int i7;
                    switch (layoutParams.gravity & MMGIFException.D_GIF_ERR_IMAGE_DEFECT) {
                        case 16:
                            int i8 = i4 - i2;
                            i7 = (i8 - measuredHeight) / 2;
                            if (i7 < layoutParams.topMargin) {
                                i7 = layoutParams.topMargin;
                            } else if (i7 + measuredHeight > i8 - layoutParams.bottomMargin) {
                                i7 = (i8 - layoutParams.bottomMargin) - measuredHeight;
                            }
                            childAt.layout(a, i7, measuredWidth + a, measuredHeight + i7);
                            break;
                        case 80:
                            i7 = i4 - i2;
                            childAt.layout(a, (i7 - layoutParams.bottomMargin) - childAt.getMeasuredHeight(), measuredWidth + a, i7 - layoutParams.bottomMargin);
                            break;
                        default:
                            childAt.layout(a, layoutParams.topMargin, measuredWidth + a, measuredHeight + layoutParams.topMargin);
                            break;
                    }
                    if (obj != null) {
                        i(childAt, f);
                    }
                    int i9 = layoutParams.Cx > 0.0f ? 0 : 4;
                    if (childAt.getVisibility() != i9) {
                        childAt.setVisibility(i9);
                    }
                }
            }
        }
        this.mInLayout = false;
        this.zv = false;
    }

    public void requestLayout() {
        if (!this.mInLayout) {
            super.requestLayout();
        }
    }

    public void computeScroll() {
        int childCount = getChildCount();
        float f = 0.0f;
        for (int i = 0; i < childCount; i++) {
            f = Math.max(f, ((LayoutParams) getChildAt(i).getLayoutParams()).Cx);
        }
        this.BY = f;
        if ((this.Ca.cW() | this.Cb.cW()) != 0) {
            z.E(this);
        }
    }

    public void onRtlPropertiesChanged(int i) {
        if (!BT) {
            Drawable drawable;
            int I = z.I(this);
            if (I == 0) {
                if (this.Cq != null) {
                    c(this.Cq, I);
                    drawable = this.Cq;
                }
                drawable = this.Cs;
            } else {
                if (this.Cr != null) {
                    c(this.Cr, I);
                    drawable = this.Cr;
                }
                drawable = this.Cs;
            }
            this.Cl = drawable;
            I = z.I(this);
            if (I == 0) {
                if (this.Cr != null) {
                    c(this.Cr, I);
                    drawable = this.Cr;
                }
                drawable = this.Ct;
            } else {
                if (this.Cq != null) {
                    c(this.Cq, I);
                    drawable = this.Cq;
                }
                drawable = this.Ct;
            }
            this.Cm = drawable;
        }
    }

    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.hJ && this.hK != null) {
            int H = Cv.H(this.Cp);
            if (H > 0) {
                this.hK.setBounds(0, 0, getWidth(), H);
                this.hK.draw(canvas);
            }
        }
    }

    protected boolean drawChild(Canvas canvas, View view, long j) {
        int right;
        int height = getHeight();
        boolean av = av(view);
        int i = 0;
        int width = getWidth();
        int save = canvas.save();
        if (av) {
            int childCount = getChildCount();
            int i2 = 0;
            while (i2 < childCount) {
                View childAt = getChildAt(i2);
                if (childAt != view && childAt.getVisibility() == 0) {
                    Drawable background = childAt.getBackground();
                    Object obj = background != null ? background.getOpacity() == -1 ? 1 : null : null;
                    if (obj != null && aw(childAt) && childAt.getHeight() >= height) {
                        if (m(childAt, 3)) {
                            right = childAt.getRight();
                            if (right <= i) {
                                right = i;
                            }
                            i = right;
                            right = width;
                        } else {
                            right = childAt.getLeft();
                            if (right < width) {
                            }
                        }
                        i2++;
                        width = right;
                    }
                }
                right = width;
                i2++;
                width = right;
            }
            canvas.clipRect(i, 0, width, getHeight());
        }
        right = width;
        boolean drawChild = super.drawChild(canvas, view, j);
        canvas.restoreToCount(save);
        if (this.BY > 0.0f && av) {
            this.BZ.setColor((((int) (((float) ((this.BX & WebView.NIGHT_MODE_COLOR) >>> 24)) * this.BY)) << 24) | (this.BX & 16777215));
            canvas.drawRect((float) i, 0.0f, (float) right, (float) getHeight(), this.BZ);
        } else if (this.Cl != null && m(view, 3)) {
            right = this.Cl.getIntrinsicWidth();
            i = view.getRight();
            r2 = Math.max(0.0f, Math.min(((float) i) / ((float) this.Ca.Fq), 1.0f));
            this.Cl.setBounds(i, view.getTop(), right + i, view.getBottom());
            this.Cl.setAlpha((int) (255.0f * r2));
            this.Cl.draw(canvas);
        } else if (this.Cm != null && m(view, 5)) {
            right = this.Cm.getIntrinsicWidth();
            i = view.getLeft();
            r2 = Math.max(0.0f, Math.min(((float) (getWidth() - i)) / ((float) this.Cb.Fq), 1.0f));
            this.Cm.setBounds(i - right, view.getTop(), i, view.getBottom());
            this.Cm.setAlpha((int) (255.0f * r2));
            this.Cm.draw(canvas);
        }
        return drawChild;
    }

    private static boolean av(View view) {
        return ((LayoutParams) view.getLayoutParams()).gravity == 0;
    }

    static boolean aw(View view) {
        int absoluteGravity = android.support.v4.view.f.getAbsoluteGravity(((LayoutParams) view.getLayoutParams()).gravity, z.I(view));
        if ((absoluteGravity & 3) != 0) {
            return true;
        }
        if ((absoluteGravity & 5) != 0) {
            return true;
        }
        return false;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onInterceptTouchEvent(android.view.MotionEvent r10) {
        /*
        r9 = this;
        r1 = 1;
        r2 = 0;
        r0 = android.support.v4.view.o.d(r10);
        r3 = r9.Ca;
        r3 = r3.j(r10);
        r4 = r9.Cb;
        r4 = r4.j(r10);
        r4 = r4 | r3;
        switch(r0) {
            case 0: goto L_0x003b;
            case 1: goto L_0x00ad;
            case 2: goto L_0x0064;
            case 3: goto L_0x00ad;
            default: goto L_0x0016;
        };
    L_0x0016:
        r0 = r2;
    L_0x0017:
        if (r4 != 0) goto L_0x0039;
    L_0x0019:
        if (r0 != 0) goto L_0x0039;
    L_0x001b:
        r4 = r9.getChildCount();
        r3 = r2;
    L_0x0020:
        if (r3 >= r4) goto L_0x00bb;
    L_0x0022:
        r0 = r9.getChildAt(r3);
        r0 = r0.getLayoutParams();
        r0 = (android.support.v4.widget.DrawerLayout.LayoutParams) r0;
        r0 = r0.Cy;
        if (r0 == 0) goto L_0x00b6;
    L_0x0032:
        r0 = r1;
    L_0x0033:
        if (r0 != 0) goto L_0x0039;
    L_0x0035:
        r0 = r9.Ck;
        if (r0 == 0) goto L_0x003a;
    L_0x0039:
        r2 = r1;
    L_0x003a:
        return r2;
    L_0x003b:
        r0 = r10.getX();
        r3 = r10.getY();
        r9.ya = r0;
        r9.yb = r3;
        r5 = r9.BY;
        r6 = 0;
        r5 = (r5 > r6 ? 1 : (r5 == r6 ? 0 : -1));
        if (r5 <= 0) goto L_0x00be;
    L_0x004e:
        r5 = r9.Ca;
        r0 = (int) r0;
        r3 = (int) r3;
        r0 = r5.w(r0, r3);
        if (r0 == 0) goto L_0x00be;
    L_0x0058:
        r0 = av(r0);
        if (r0 == 0) goto L_0x00be;
    L_0x005e:
        r0 = r1;
    L_0x005f:
        r9.Cj = r2;
        r9.Ck = r2;
        goto L_0x0017;
    L_0x0064:
        r5 = r9.Ca;
        r0 = r5.Fg;
        r6 = r0.length;
        r0 = r2;
    L_0x006a:
        if (r0 >= r6) goto L_0x00ab;
    L_0x006c:
        r3 = r5.ax(r0);
        if (r3 == 0) goto L_0x00a6;
    L_0x0072:
        r3 = r5.Fi;
        r3 = r3[r0];
        r7 = r5.Fg;
        r7 = r7[r0];
        r3 = r3 - r7;
        r7 = r5.Fj;
        r7 = r7[r0];
        r8 = r5.Fh;
        r8 = r8[r0];
        r7 = r7 - r8;
        r3 = r3 * r3;
        r7 = r7 * r7;
        r3 = r3 + r7;
        r7 = r5.iY;
        r8 = r5.iY;
        r7 = r7 * r8;
        r7 = (float) r7;
        r3 = (r3 > r7 ? 1 : (r3 == r7 ? 0 : -1));
        if (r3 <= 0) goto L_0x00a4;
    L_0x0091:
        r3 = r1;
    L_0x0092:
        if (r3 == 0) goto L_0x00a8;
    L_0x0094:
        r0 = r1;
    L_0x0095:
        if (r0 == 0) goto L_0x0016;
    L_0x0097:
        r0 = r9.Cc;
        r0.cy();
        r0 = r9.Cd;
        r0.cy();
        r0 = r2;
        goto L_0x0017;
    L_0x00a4:
        r3 = r2;
        goto L_0x0092;
    L_0x00a6:
        r3 = r2;
        goto L_0x0092;
    L_0x00a8:
        r0 = r0 + 1;
        goto L_0x006a;
    L_0x00ab:
        r0 = r2;
        goto L_0x0095;
    L_0x00ad:
        r9.A(r1);
        r9.Cj = r2;
        r9.Ck = r2;
        goto L_0x0016;
    L_0x00b6:
        r0 = r3 + 1;
        r3 = r0;
        goto L_0x0020;
    L_0x00bb:
        r0 = r2;
        goto L_0x0033;
    L_0x00be:
        r0 = r2;
        goto L_0x005f;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.widget.DrawerLayout.onInterceptTouchEvent(android.view.MotionEvent):boolean");
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        this.Ca.k(motionEvent);
        this.Cb.k(motionEvent);
        float x;
        float y;
        switch (motionEvent.getAction() & 255) {
            case 0:
                x = motionEvent.getX();
                y = motionEvent.getY();
                this.ya = x;
                this.yb = y;
                this.Cj = false;
                this.Ck = false;
                break;
            case 1:
                boolean z;
                x = motionEvent.getX();
                y = motionEvent.getY();
                View w = this.Ca.w((int) x, (int) y);
                if (w != null && av(w)) {
                    x -= this.ya;
                    y -= this.yb;
                    int i = this.Ca.iY;
                    if ((x * x) + (y * y) < ((float) (i * i))) {
                        View cz = cz();
                        if (cz != null) {
                            z = as(cz) == 2;
                            A(z);
                            this.Cj = false;
                            break;
                        }
                    }
                }
                z = true;
                A(z);
                this.Cj = false;
            case 3:
                A(true);
                this.Cj = false;
                this.Ck = false;
                break;
        }
        return true;
    }

    public void requestDisallowInterceptTouchEvent(boolean z) {
        super.requestDisallowInterceptTouchEvent(z);
        this.Cj = z;
        if (z) {
            A(true);
        }
    }

    private void A(boolean z) {
        int childCount = getChildCount();
        int i = 0;
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
            if (aw(childAt) && (!z || layoutParams.Cy)) {
                int width = childAt.getWidth();
                if (m(childAt, 3)) {
                    i |= this.Ca.e(childAt, -width, childAt.getTop());
                } else {
                    i |= this.Cb.e(childAt, getWidth(), childAt.getTop());
                }
                layoutParams.Cy = false;
            }
        }
        this.Cc.cy();
        this.Cd.cy();
        if (i != 0) {
            invalidate();
        }
    }

    private void ax(View view) {
        if (aw(view)) {
            LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
            if (this.zv) {
                layoutParams.Cx = 1.0f;
                layoutParams.Cz = 1;
                d(view, true);
            } else {
                LayoutParams.b(layoutParams, 2);
                if (m(view, 3)) {
                    this.Ca.e(view, 0, view.getTop());
                } else {
                    this.Cb.e(view, getWidth() - view.getWidth(), view.getTop());
                }
            }
            invalidate();
            return;
        }
        throw new IllegalArgumentException("View " + view + " is not a sliding drawer");
    }

    public final void ay(View view) {
        if (aw(view)) {
            LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
            if (this.zv) {
                layoutParams.Cx = 0.0f;
                layoutParams.Cz = 0;
            } else {
                LayoutParams.b(layoutParams, 4);
                if (m(view, 3)) {
                    this.Ca.e(view, -view.getWidth(), view.getTop());
                } else {
                    this.Cb.e(view, getWidth(), view.getTop());
                }
            }
            invalidate();
            return;
        }
        throw new IllegalArgumentException("View " + view + " is not a sliding drawer");
    }

    protected android.view.ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new LayoutParams();
    }

    protected android.view.ViewGroup.LayoutParams generateLayoutParams(android.view.ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof LayoutParams) {
            return new LayoutParams((LayoutParams) layoutParams);
        }
        return layoutParams instanceof MarginLayoutParams ? new LayoutParams((MarginLayoutParams) layoutParams) : new LayoutParams(layoutParams);
    }

    protected boolean checkLayoutParams(android.view.ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof LayoutParams) && super.checkLayoutParams(layoutParams);
    }

    public android.view.ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new LayoutParams(getContext(), attributeSet);
    }

    public void addFocusables(ArrayList<View> arrayList, int i, int i2) {
        if (getDescendantFocusability() != 393216) {
            int childCount = getChildCount();
            int i3 = 0;
            Object obj = null;
            while (i3 < childCount) {
                Object obj2;
                View childAt = getChildAt(i3);
                if (!aw(childAt)) {
                    this.Cu.add(childAt);
                    obj2 = obj;
                } else if (aw(childAt)) {
                    if ((((LayoutParams) childAt.getLayoutParams()).Cz & 1) == 1) {
                        obj2 = 1;
                    } else {
                        obj2 = null;
                    }
                    if (obj2 != null) {
                        childAt.addFocusables(arrayList, i, i2);
                        obj2 = 1;
                    }
                    obj2 = obj;
                } else {
                    throw new IllegalArgumentException("View " + childAt + " is not a drawer");
                }
                i3++;
                obj = obj2;
            }
            if (obj == null) {
                int size = this.Cu.size();
                for (int i4 = 0; i4 < size; i4++) {
                    View view = (View) this.Cu.get(i4);
                    if (view.getVisibility() == 0) {
                        view.addFocusables(arrayList, i, i2);
                    }
                }
            }
            this.Cu.clear();
        }
    }

    private View cA() {
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            if (aw(childAt)) {
                if (aw(childAt)) {
                    Object obj;
                    if (((LayoutParams) childAt.getLayoutParams()).Cx > 0.0f) {
                        obj = 1;
                    } else {
                        obj = null;
                    }
                    if (obj != null) {
                        return childAt;
                    }
                } else {
                    throw new IllegalArgumentException("View " + childAt + " is not a drawer");
                }
            }
        }
        return null;
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (i == 4) {
            if (cA() != null) {
                android.support.v4.view.g.b(keyEvent);
                return true;
            }
        }
        return super.onKeyDown(i, keyEvent);
    }

    public boolean onKeyUp(int i, KeyEvent keyEvent) {
        if (i != 4) {
            return super.onKeyUp(i, keyEvent);
        }
        View cA = cA();
        if (cA != null && as(cA) == 0) {
            A(false);
        }
        if (cA != null) {
            return true;
        }
        return false;
    }

    protected void onRestoreInstanceState(Parcelable parcelable) {
        if (parcelable instanceof SavedState) {
            SavedState savedState = (SavedState) parcelable;
            super.onRestoreInstanceState(savedState.getSuperState());
            if (savedState.CA != 0) {
                View ap = ap(savedState.CA);
                if (ap != null) {
                    ax(ap);
                }
            }
            if (savedState.CB != 3) {
                r(savedState.CB, 3);
            }
            if (savedState.CC != 3) {
                r(savedState.CC, 5);
            }
            if (savedState.CD != 3) {
                r(savedState.CD, 8388611);
            }
            if (savedState.CE != 3) {
                r(savedState.CE, 8388613);
                return;
            }
            return;
        }
        super.onRestoreInstanceState(parcelable);
    }

    protected Parcelable onSaveInstanceState() {
        Parcelable savedState = new SavedState(super.onSaveInstanceState());
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            LayoutParams layoutParams = (LayoutParams) getChildAt(i).getLayoutParams();
            Object obj = layoutParams.Cz == 1 ? 1 : null;
            Object obj2;
            if (layoutParams.Cz == 2) {
                obj2 = 1;
            } else {
                obj2 = null;
            }
            if (obj != null || obj2 != null) {
                savedState.CA = layoutParams.gravity;
                break;
            }
        }
        savedState.CB = this.Cf;
        savedState.CC = this.Cg;
        savedState.CD = this.Ch;
        savedState.CE = this.Ci;
        return savedState;
    }

    public void addView(View view, int i, android.view.ViewGroup.LayoutParams layoutParams) {
        super.addView(view, i, layoutParams);
        if (cz() != null || aw(view)) {
            z.i(view, 4);
        } else {
            z.i(view, 1);
        }
        if (!BS) {
            z.a(view, this.BU);
        }
    }
}
