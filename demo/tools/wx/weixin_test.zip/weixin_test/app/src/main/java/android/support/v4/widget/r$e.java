package android.support.v4.widget;

import android.support.v4.widget.r.b;
import android.widget.TextView;

class r$e extends b {
    r$e() {
    }

    public final int c(TextView textView) {
        return textView.getMaxLines();
    }
}
