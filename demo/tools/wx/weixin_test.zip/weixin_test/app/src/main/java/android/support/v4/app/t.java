package android.support.v4.app;

import android.support.v4.content.c;

public abstract class t {

    public interface a<D> {
        c<D> U(int i);

        void a(c<D> cVar, D d);
    }

    public abstract <D> c<D> T(int i);

    public abstract <D> c<D> a(int i, a<D> aVar);

    public abstract <D> c<D> b(int i, a<D> aVar);

    public abstract void destroyLoader(int i);

    public boolean bk() {
        return false;
    }
}
