package android.support.v4.app;

import android.os.Bundle;

final class FragmentTabHost$a {
    Fragment pU;
    final Class<?> ru;
    final Bundle rv;
    final String tag;
}
