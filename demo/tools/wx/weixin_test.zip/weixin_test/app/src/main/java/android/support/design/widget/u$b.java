package android.support.design.widget;

import android.support.design.widget.u.a;

class u$b implements a {
    u$b() {
    }

    public void aE() {
    }
}
