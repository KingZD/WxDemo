package android.support.v4.content;

import android.content.BroadcastReceiver;
import android.content.IntentFilter;

class d$b {
    final IntentFilter filter;
    final BroadcastReceiver tZ;
    boolean ua;

    d$b(IntentFilter intentFilter, BroadcastReceiver broadcastReceiver) {
        this.filter = intentFilter;
        this.tZ = broadcastReceiver;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder(128);
        stringBuilder.append("Receiver{");
        stringBuilder.append(this.tZ);
        stringBuilder.append(" filter=");
        stringBuilder.append(this.filter);
        stringBuilder.append("}");
        return stringBuilder.toString();
    }
}
