package android.support.v4.a;

import android.view.View;

final class e implements c {
    e() {
    }

    public final g aW() {
        return new e$a();
    }

    public final void v(View view) {
    }
}
