package android.support.v4.b;

import android.graphics.Bitmap;

class a$e extends a$d {
    a$e() {
    }

    public final int e(Bitmap bitmap) {
        return bitmap.getAllocationByteCount();
    }
}
