package android.support.v4.widget;

import android.view.animation.Animation;
import android.view.animation.Transformation;

class SwipeRefreshLayout$7 extends Animation {
    final /* synthetic */ SwipeRefreshLayout EX;

    SwipeRefreshLayout$7(SwipeRefreshLayout swipeRefreshLayout) {
        this.EX = swipeRefreshLayout;
    }

    public final void applyTransformation(float f, Transformation transformation) {
        SwipeRefreshLayout.a(this.EX, SwipeRefreshLayout.k(this.EX) + ((-SwipeRefreshLayout.k(this.EX)) * f));
        SwipeRefreshLayout.b(this.EX, f);
    }
}
