package android.support.v4.view;

import android.view.View;
import java.util.Comparator;

class ViewPager$i implements Comparator<View> {
    ViewPager$i() {
    }

    public final /* synthetic */ int compare(Object obj, Object obj2) {
        ViewPager$LayoutParams viewPager$LayoutParams = (ViewPager$LayoutParams) ((View) obj).getLayoutParams();
        ViewPager$LayoutParams viewPager$LayoutParams2 = (ViewPager$LayoutParams) ((View) obj2).getLayoutParams();
        if (viewPager$LayoutParams.zM != viewPager$LayoutParams2.zM) {
            return viewPager$LayoutParams.zM ? 1 : -1;
        } else {
            return viewPager$LayoutParams.position - viewPager$LayoutParams2.position;
        }
    }
}
