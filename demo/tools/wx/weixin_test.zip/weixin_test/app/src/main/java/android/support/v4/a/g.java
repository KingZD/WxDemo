package android.support.v4.a;

import android.view.View;

public interface g {
    void a(b bVar);

    void a(d dVar);

    void cancel();

    float getAnimatedFraction();

    void setDuration(long j);

    void start();

    void w(View view);
}
