package android.support.design.widget;

import android.support.v4.view.an;
import android.view.View;

class TextInputLayout$3 extends an {
    final /* synthetic */ CharSequence lA;
    final /* synthetic */ TextInputLayout lz;

    TextInputLayout$3(TextInputLayout textInputLayout, CharSequence charSequence) {
        this.lz = textInputLayout;
        this.lA = charSequence;
    }

    public final void q(View view) {
        TextInputLayout.c(this.lz).setText(this.lA);
        view.setVisibility(4);
    }
}
