package android.support.v4.app;

import android.content.Intent;
import android.os.Bundle;

class ah$d implements ah$b {
    ah$d() {
    }

    public final Bundle getResultsFromIntent(Intent intent) {
        return null;
    }
}
