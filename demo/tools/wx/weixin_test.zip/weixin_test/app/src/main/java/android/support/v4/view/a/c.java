package android.support.v4.view.a;

import android.os.Build.VERSION;
import java.util.ArrayList;
import java.util.List;

public final class c {
    private static final a AF;
    public final Object AG;

    interface a {
        Object a(c cVar);
    }

    static class d implements a {
        d() {
        }

        public Object a(c cVar) {
            return null;
        }
    }

    static class b extends d {
        b() {
        }

        public final Object a(final c cVar) {
            return new android.support.v4.view.a.d.AnonymousClass1(new a(this) {
                final /* synthetic */ b AI;

                public final boolean cp() {
                    return c.cp();
                }

                public final List<Object> cq() {
                    List list = null;
                    c.cq();
                    List<Object> arrayList = new ArrayList();
                    int size = list.size();
                    for (int i = 0; i < size; i++) {
                        arrayList.add(((b) list.get(i)).Ah);
                    }
                    return arrayList;
                }

                public final Object cs() {
                    c.co();
                    return null;
                }
            });
        }
    }

    static class c extends d {
        c() {
        }

        public final Object a(final c cVar) {
            return new android.support.v4.view.a.e.AnonymousClass1(new a(this) {
                final /* synthetic */ c AJ;

                public final boolean cp() {
                    return c.cp();
                }

                public final List<Object> cq() {
                    List list = null;
                    c.cq();
                    List<Object> arrayList = new ArrayList();
                    int size = list.size();
                    for (int i = 0; i < size; i++) {
                        arrayList.add(((b) list.get(i)).Ah);
                    }
                    return arrayList;
                }

                public final Object cs() {
                    c.co();
                    return null;
                }

                public final Object ct() {
                    c.cr();
                    return null;
                }
            });
        }
    }

    static {
        if (VERSION.SDK_INT >= 19) {
            AF = new c();
        } else if (VERSION.SDK_INT >= 16) {
            AF = new b();
        } else {
            AF = new d();
        }
    }

    public c() {
        this.AG = AF.a(this);
    }

    public c(Object obj) {
        this.AG = obj;
    }

    public static b co() {
        return null;
    }

    public static boolean cp() {
        return false;
    }

    public static List<b> cq() {
        return null;
    }

    public static b cr() {
        return null;
    }
}
