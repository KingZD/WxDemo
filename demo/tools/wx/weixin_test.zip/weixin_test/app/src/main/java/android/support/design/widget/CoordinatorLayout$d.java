package android.support.design.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.support.design.a$i;
import android.support.design.widget.CoordinatorLayout.Behavior;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;

public class CoordinatorLayout$d extends MarginLayoutParams {
    public int anchorGravity = 0;
    public int gravity = 0;
    Behavior hO;
    boolean hP = false;
    public int hQ = -1;
    int hR = -1;
    View hS;
    View hT;
    boolean hU;
    boolean hV;
    boolean hW;
    final Rect hX = new Rect();
    Object hY;

    public CoordinatorLayout$d() {
        super(-2, -2);
    }

    CoordinatorLayout$d(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, a$i.cH);
        this.gravity = obtainStyledAttributes.getInteger(a$i.cI, 0);
        this.hR = obtainStyledAttributes.getResourceId(a$i.cK, -1);
        this.anchorGravity = obtainStyledAttributes.getInteger(a$i.cM, 0);
        this.hQ = obtainStyledAttributes.getInteger(a$i.cL, -1);
        this.hP = obtainStyledAttributes.hasValue(a$i.cJ);
        if (this.hP) {
            this.hO = CoordinatorLayout.a(context, attributeSet, obtainStyledAttributes.getString(a$i.cJ));
        }
        obtainStyledAttributes.recycle();
    }

    public CoordinatorLayout$d(CoordinatorLayout$d coordinatorLayout$d) {
        super(coordinatorLayout$d);
    }

    public CoordinatorLayout$d(MarginLayoutParams marginLayoutParams) {
        super(marginLayoutParams);
    }

    public CoordinatorLayout$d(LayoutParams layoutParams) {
        super(layoutParams);
    }

    public final void a(Behavior behavior) {
        if (this.hO != behavior) {
            this.hO = behavior;
            this.hY = null;
            this.hP = true;
        }
    }

    final boolean c(CoordinatorLayout coordinatorLayout, View view, View view2) {
        return view2 == this.hT || (this.hO != null && this.hO.e(view2));
    }
}
