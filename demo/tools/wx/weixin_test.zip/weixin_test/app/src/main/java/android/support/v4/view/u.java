package android.support.v4.view;

import android.database.DataSetObservable;
import android.database.DataSetObserver;
import android.os.Parcelable;
import android.view.View;
import android.view.ViewGroup;

public abstract class u {
    private final DataSetObservable xM = new DataSetObservable();
    private DataSetObserver xN;

    public abstract boolean a(View view, Object obj);

    public abstract int getCount();

    public Object b(ViewGroup viewGroup, int i) {
        throw new UnsupportedOperationException("Required method instantiateItem was not overridden");
    }

    public void a(ViewGroup viewGroup, int i, Object obj) {
        throw new UnsupportedOperationException("Required method destroyItem was not overridden");
    }

    public void e(Object obj) {
    }

    public void bi() {
    }

    public Parcelable bj() {
        return null;
    }

    public void a(Parcelable parcelable, ClassLoader classLoader) {
    }

    public int k(Object obj) {
        return -1;
    }

    public void notifyDataSetChanged() {
        synchronized (this) {
            if (this.xN != null) {
                this.xN.onChanged();
            }
        }
        this.xM.notifyChanged();
    }

    public final void registerDataSetObserver(DataSetObserver dataSetObserver) {
        this.xM.registerObserver(dataSetObserver);
    }

    public final void unregisterDataSetObserver(DataSetObserver dataSetObserver) {
        this.xM.unregisterObserver(dataSetObserver);
    }

    final void a(DataSetObserver dataSetObserver) {
        synchronized (this) {
            this.xN = dataSetObserver;
        }
    }

    public CharSequence bW() {
        return null;
    }
}
