package android.support.b;

import java.io.FilterOutputStream;
import java.io.OutputStream;
import java.nio.ByteOrder;

class a$b extends FilterOutputStream {
    ByteOrder oF;
    private final OutputStream oG;

    public a$b(OutputStream outputStream, ByteOrder byteOrder) {
        super(outputStream);
        this.oG = outputStream;
        this.oF = byteOrder;
    }

    public final void write(byte[] bArr) {
        this.oG.write(bArr);
    }

    public final void write(byte[] bArr, int i, int i2) {
        this.oG.write(bArr, i, i2);
    }

    public final void writeByte(int i) {
        this.oG.write(i);
    }

    public final void writeShort(short s) {
        if (this.oF == ByteOrder.LITTLE_ENDIAN) {
            this.oG.write((s >>> 0) & 255);
            this.oG.write((s >>> 8) & 255);
        } else if (this.oF == ByteOrder.BIG_ENDIAN) {
            this.oG.write((s >>> 8) & 255);
            this.oG.write((s >>> 0) & 255);
        }
    }

    public final void writeInt(int i) {
        if (this.oF == ByteOrder.LITTLE_ENDIAN) {
            this.oG.write((i >>> 0) & 255);
            this.oG.write((i >>> 8) & 255);
            this.oG.write((i >>> 16) & 255);
            this.oG.write((i >>> 24) & 255);
        } else if (this.oF == ByteOrder.BIG_ENDIAN) {
            this.oG.write((i >>> 24) & 255);
            this.oG.write((i >>> 16) & 255);
            this.oG.write((i >>> 8) & 255);
            this.oG.write((i >>> 0) & 255);
        }
    }
}
