package android.support.design.widget;

import android.view.View;

class aa$b implements aa$a {
    private aa$b() {
    }

    public final void u(View view) {
    }
}
