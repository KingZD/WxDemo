package android.support.v4.media;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public final class RatingCompat implements Parcelable {
    public static final Creator<RatingCompat> CREATOR = new RatingCompat$1();
    private final int vr;
    private final float vs;

    private RatingCompat(int i, float f) {
        this.vr = i;
        this.vs = f;
    }

    public final String toString() {
        return "Rating:style=" + this.vr + " rating=" + (this.vs < 0.0f ? "unrated" : String.valueOf(this.vs));
    }

    public final int describeContents() {
        return this.vr;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.vr);
        parcel.writeFloat(this.vs);
    }
}
