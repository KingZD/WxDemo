package android.support.v4.app;

import android.content.ComponentName;
import java.util.LinkedList;

class ag$h$a {
    public int retryCount = 0;
    public final ComponentName tm;
    public boolean tq = false;
    public s tr;
    public LinkedList<ag$i> tt = new LinkedList();

    public ag$h$a(ComponentName componentName) {
        this.tm = componentName;
    }
}
