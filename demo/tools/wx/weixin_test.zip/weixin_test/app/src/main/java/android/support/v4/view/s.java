package android.support.v4.view;

import android.view.ViewGroup;

public final class s {
    private final ViewGroup xK;
    public int xL;

    public s(ViewGroup viewGroup) {
        this.xK = viewGroup;
    }
}
