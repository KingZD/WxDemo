package android.support.design.widget;

import android.support.v4.view.z;

class HeaderBehavior$a implements Runnable {
    private final CoordinatorLayout iZ;
    private final V ja;
    final /* synthetic */ HeaderBehavior jb;

    HeaderBehavior$a(HeaderBehavior headerBehavior, CoordinatorLayout coordinatorLayout, V v) {
        this.jb = headerBehavior;
        this.iZ = coordinatorLayout;
        this.ja = v;
    }

    public final void run() {
        if (this.ja != null && HeaderBehavior.a(this.jb) != null) {
            if (HeaderBehavior.a(this.jb).computeScrollOffset()) {
                this.jb.c(this.iZ, this.ja, HeaderBehavior.a(this.jb).getCurrY());
                z.a(this.ja, this);
                return;
            }
            this.jb.a(this.iZ, this.ja);
        }
    }
}
