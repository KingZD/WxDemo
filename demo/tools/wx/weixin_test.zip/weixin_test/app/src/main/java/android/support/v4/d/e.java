package android.support.v4.d;

public final class e {
    public static final d vW = new e$e(null, false, (byte) 0);
    public static final d vX = new e$e(null, true, (byte) 0);
    public static final d vY = new e$e(b.wf, false, (byte) 0);
    public static final d vZ = new e$e(b.wf, true, (byte) 0);
    public static final d wa = new e$e(a.wd, false, (byte) 0);
    public static final d wb = e$f.wi;

    private static class a implements e$c {
        public static final a wd = new a(true);
        public static final a we = new a(false);
        private final boolean wc;

        public final int a(CharSequence charSequence, int i, int i2) {
            int i3 = i2 + 0;
            int i4 = 0;
            for (int i5 = 0; i5 < i3; i5++) {
                switch (e.X(Character.getDirectionality(charSequence.charAt(i5)))) {
                    case 0:
                        if (!this.wc) {
                            i4 = 1;
                            break;
                        }
                        return 0;
                    case 1:
                        if (this.wc) {
                            i4 = 1;
                            break;
                        }
                        return 1;
                    default:
                        break;
                }
            }
            if (i4 == 0) {
                return 2;
            }
            if (this.wc) {
                return 1;
            }
            return 0;
        }

        private a(boolean z) {
            this.wc = z;
        }
    }

    private static class b implements e$c {
        public static final b wf = new b();

        public final int a(CharSequence charSequence, int i, int i2) {
            int i3 = i2 + 0;
            int i4 = 2;
            for (int i5 = 0; i5 < i3 && i4 == 2; i5++) {
                i4 = e.W(Character.getDirectionality(charSequence.charAt(i5)));
            }
            return i4;
        }

        private b() {
        }
    }

    static /* synthetic */ int W(int i) {
        switch (i) {
            case 0:
            case 14:
            case 15:
                return 1;
            case 1:
            case 2:
            case 16:
            case 17:
                return 0;
            default:
                return 2;
        }
    }

    static /* synthetic */ int X(int i) {
        switch (i) {
            case 0:
                return 1;
            case 1:
            case 2:
                return 0;
            default:
                return 2;
        }
    }
}
