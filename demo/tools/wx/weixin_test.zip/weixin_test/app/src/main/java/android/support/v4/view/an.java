package android.support.v4.view;

import android.view.View;

public class an implements am {
    public void p(View view) {
    }

    public void q(View view) {
    }

    public void ar(View view) {
    }
}
