package android.support.v4.view.a;

import android.os.Build.VERSION;
import android.view.accessibility.AccessibilityRecord;

public final class f {
    public static final c AM;
    public final Object AN;

    interface c {
        Object cv();

        void e(Object obj, int i);

        void f(Object obj, int i);

        void g(Object obj, int i);

        void g(Object obj, boolean z);

        void h(Object obj, int i);

        void i(Object obj, int i);

        void j(Object obj, int i);

        void k(Object obj, int i);
    }

    static class e implements c {
        e() {
        }

        public Object cv() {
            return null;
        }

        public void e(Object obj, int i) {
        }

        public void f(Object obj, int i) {
        }

        public void j(Object obj, int i) {
        }

        public void k(Object obj, int i) {
        }

        public void g(Object obj, int i) {
        }

        public void h(Object obj, int i) {
        }

        public void g(Object obj, boolean z) {
        }

        public void i(Object obj, int i) {
        }
    }

    static class a extends e {
        a() {
        }

        public final Object cv() {
            return AccessibilityRecord.obtain();
        }

        public final void e(Object obj, int i) {
            ((AccessibilityRecord) obj).setFromIndex(i);
        }

        public final void f(Object obj, int i) {
            ((AccessibilityRecord) obj).setItemCount(i);
        }

        public final void g(Object obj, int i) {
            ((AccessibilityRecord) obj).setScrollX(i);
        }

        public final void h(Object obj, int i) {
            ((AccessibilityRecord) obj).setScrollY(i);
        }

        public final void g(Object obj, boolean z) {
            ((AccessibilityRecord) obj).setScrollable(z);
        }

        public final void i(Object obj, int i) {
            ((AccessibilityRecord) obj).setToIndex(i);
        }
    }

    static class b extends a {
        b() {
        }

        public final void j(Object obj, int i) {
            ((AccessibilityRecord) obj).setMaxScrollX(i);
        }

        public final void k(Object obj, int i) {
            ((AccessibilityRecord) obj).setMaxScrollY(i);
        }
    }

    static class d extends b {
        d() {
        }
    }

    static {
        if (VERSION.SDK_INT >= 16) {
            AM = new d();
        } else if (VERSION.SDK_INT >= 15) {
            AM = new b();
        } else if (VERSION.SDK_INT >= 14) {
            AM = new a();
        } else {
            AM = new e();
        }
    }

    public f(Object obj) {
        this.AN = obj;
    }

    public static f cu() {
        return new f(AM.cv());
    }

    public final void setScrollable(boolean z) {
        AM.g(this.AN, z);
    }

    public final void setItemCount(int i) {
        AM.f(this.AN, i);
    }

    public final void setFromIndex(int i) {
        AM.e(this.AN, i);
    }

    public final void setToIndex(int i) {
        AM.i(this.AN, i);
    }

    public final int hashCode() {
        return this.AN == null ? 0 : this.AN.hashCode();
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        f fVar = (f) obj;
        if (this.AN == null) {
            if (fVar.AN != null) {
                return false;
            }
            return true;
        } else if (this.AN.equals(fVar.AN)) {
            return true;
        } else {
            return false;
        }
    }
}
