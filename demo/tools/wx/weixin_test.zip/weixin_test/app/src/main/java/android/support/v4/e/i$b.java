package android.support.v4.e;

public class i$b<T> implements i$a<T> {
    private final Object[] wD;
    private int wE;

    public i$b(int i) {
        if (i <= 0) {
            throw new IllegalArgumentException("The max pool size must be > 0");
        }
        this.wD = new Object[i];
    }

    public T bR() {
        if (this.wE <= 0) {
            return null;
        }
        int i = this.wE - 1;
        T t = this.wD[i];
        this.wD[i] = null;
        this.wE--;
        return t;
    }

    public boolean j(T t) {
        boolean z;
        for (int i = 0; i < this.wE; i++) {
            if (this.wD[i] == t) {
                z = true;
                break;
            }
        }
        z = false;
        if (z) {
            throw new IllegalStateException("Already in the pool!");
        } else if (this.wE >= this.wD.length) {
            return false;
        } else {
            this.wD[this.wE] = t;
            this.wE++;
            return true;
        }
    }
}
