package android.support.v4.view;

import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.view.View;

final class al {

    /* renamed from: android.support.v4.view.al$1 */
    static class AnonymousClass1 implements AnimatorUpdateListener {
        final /* synthetic */ ao Ad;
        final /* synthetic */ View val$view;

        AnonymousClass1(ao aoVar, View view) {
            this.Ad = aoVar;
            this.val$view = view;
        }

        public final void onAnimationUpdate(ValueAnimator valueAnimator) {
            this.Ad.cl();
        }
    }
}
