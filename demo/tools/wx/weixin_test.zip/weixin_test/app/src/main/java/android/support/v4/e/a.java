package android.support.v4.e;

import java.util.Collection;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class a<K, V> extends j<K, V> implements Map<K, V> {
    g<K, V> wm;

    public a(int i) {
        super(i);
    }

    private g<K, V> bL() {
        if (this.wm == null) {
            this.wm = new g<K, V>(this) {
                final /* synthetic */ a wn;

                {
                    this.wn = r1;
                }

                protected final int bM() {
                    return this.wn.ij;
                }

                protected final Object p(int i, int i2) {
                    return this.wn.wK[(i << 1) + i2];
                }

                protected final int h(Object obj) {
                    return this.wn.indexOfKey(obj);
                }

                protected final int i(Object obj) {
                    return this.wn.indexOfValue(obj);
                }

                protected final Map<K, V> bN() {
                    return this.wn;
                }

                protected final void b(K k, V v) {
                    this.wn.put(k, v);
                }

                protected final V b(int i, V v) {
                    return this.wn.setValueAt(i, v);
                }

                protected final void Y(int i) {
                    this.wn.removeAt(i);
                }

                protected final void bO() {
                    this.wn.clear();
                }
            };
        }
        return this.wm;
    }

    public void putAll(Map<? extends K, ? extends V> map) {
        int size = this.ij + map.size();
        if (this.wJ.length < size) {
            Object obj = this.wJ;
            Object obj2 = this.wK;
            super.ad(size);
            if (this.ij > 0) {
                System.arraycopy(obj, 0, this.wJ, 0, this.ij);
                System.arraycopy(obj2, 0, this.wK, 0, this.ij << 1);
            }
            j.a(obj, obj2, this.ij);
        }
        for (Entry entry : map.entrySet()) {
            put(entry.getKey(), entry.getValue());
        }
    }

    public Set<Entry<K, V>> entrySet() {
        g bL = bL();
        if (bL.wv == null) {
            bL.wv = new b(bL);
        }
        return bL.wv;
    }

    public Set<K> keySet() {
        g bL = bL();
        if (bL.ww == null) {
            bL.ww = new c(bL);
        }
        return bL.ww;
    }

    public Collection<V> values() {
        g bL = bL();
        if (bL.wx == null) {
            bL.wx = new e(bL);
        }
        return bL.wx;
    }
}
