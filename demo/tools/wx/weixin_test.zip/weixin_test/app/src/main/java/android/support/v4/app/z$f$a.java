package android.support.v4.app;

import android.app.PendingIntent;
import android.support.v4.app.ac.b;
import android.support.v4.app.aj.a;

public class z$f$a extends b {
    static final ac$b$a sP = new z$f$a$1();
    private final String[] sJ;
    private final ah sK;
    private final PendingIntent sL;
    private final PendingIntent sM;
    private final String[] sN;
    private final long sO;

    public final /* bridge */ /* synthetic */ a bv() {
        return this.sK;
    }

    public z$f$a(String[] strArr, ah ahVar, PendingIntent pendingIntent, PendingIntent pendingIntent2, String[] strArr2, long j) {
        this.sJ = strArr;
        this.sK = ahVar;
        this.sM = pendingIntent2;
        this.sL = pendingIntent;
        this.sN = strArr2;
        this.sO = j;
    }

    public final String[] getMessages() {
        return this.sJ;
    }

    public final PendingIntent getReplyPendingIntent() {
        return this.sL;
    }

    public final PendingIntent getReadPendingIntent() {
        return this.sM;
    }

    public final String[] getParticipants() {
        return this.sN;
    }

    public final long getLatestTimestamp() {
        return this.sO;
    }
}
