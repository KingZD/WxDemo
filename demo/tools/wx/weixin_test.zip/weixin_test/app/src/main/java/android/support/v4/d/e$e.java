package android.support.v4.d;

class e$e extends e$d {
    private final boolean wh;

    private e$e(e$c e_c, boolean z) {
        super(e_c);
        this.wh = z;
    }

    protected final boolean bI() {
        return this.wh;
    }
}
