package android.support.v4.app;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import java.util.ArrayList;

final class BackStackState implements Parcelable {
    public static final Creator<BackStackState> CREATOR = new Creator<BackStackState>() {
        public final /* synthetic */ Object createFromParcel(Parcel parcel) {
            return new BackStackState(parcel);
        }

        public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
            return new BackStackState[i];
        }
    };
    final int mIndex;
    final String mName;
    final int pB;
    final CharSequence pC;
    final int pD;
    final CharSequence pE;
    final ArrayList<String> pF;
    final ArrayList<String> pG;
    final int pw;
    final int px;
    final int[] qe;

    public BackStackState(e eVar) {
        int i = 0;
        for (a aVar = eVar.pp; aVar != null; aVar = aVar.pR) {
            if (aVar.pZ != null) {
                i += aVar.pZ.size();
            }
        }
        this.qe = new int[(i + (eVar.pr * 7))];
        if (eVar.py) {
            i = 0;
            for (a aVar2 = eVar.pp; aVar2 != null; aVar2 = aVar2.pR) {
                int i2 = i + 1;
                this.qe[i] = aVar2.pT;
                int i3 = i2 + 1;
                this.qe[i2] = aVar2.pU != null ? aVar2.pU.mIndex : -1;
                int i4 = i3 + 1;
                this.qe[i3] = aVar2.pV;
                i2 = i4 + 1;
                this.qe[i4] = aVar2.pW;
                i4 = i2 + 1;
                this.qe[i2] = aVar2.pX;
                i2 = i4 + 1;
                this.qe[i4] = aVar2.pY;
                if (aVar2.pZ != null) {
                    int size = aVar2.pZ.size();
                    i4 = i2 + 1;
                    this.qe[i2] = size;
                    i2 = 0;
                    while (i2 < size) {
                        i3 = i4 + 1;
                        this.qe[i4] = ((Fragment) aVar2.pZ.get(i2)).mIndex;
                        i2++;
                        i4 = i3;
                    }
                    i = i4;
                } else {
                    i = i2 + 1;
                    this.qe[i2] = 0;
                }
            }
            this.pw = eVar.pw;
            this.px = eVar.px;
            this.mName = eVar.mName;
            this.mIndex = eVar.mIndex;
            this.pB = eVar.pB;
            this.pC = eVar.pC;
            this.pD = eVar.pD;
            this.pE = eVar.pE;
            this.pF = eVar.pF;
            this.pG = eVar.pG;
            return;
        }
        throw new IllegalStateException("Not on back stack");
    }

    public BackStackState(Parcel parcel) {
        this.qe = parcel.createIntArray();
        this.pw = parcel.readInt();
        this.px = parcel.readInt();
        this.mName = parcel.readString();
        this.mIndex = parcel.readInt();
        this.pB = parcel.readInt();
        this.pC = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.pD = parcel.readInt();
        this.pE = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.pF = parcel.createStringArrayList();
        this.pG = parcel.createStringArrayList();
    }

    public final e a(n nVar) {
        e eVar = new e(nVar);
        int i = 0;
        int i2 = 0;
        while (i2 < this.qe.length) {
            a aVar = new a();
            int i3 = i2 + 1;
            aVar.pT = this.qe[i2];
            if (n.DEBUG) {
                new StringBuilder("Instantiate ").append(eVar).append(" op #").append(i).append(" base fragment #").append(this.qe[i3]);
            }
            int i4 = i3 + 1;
            i2 = this.qe[i3];
            if (i2 >= 0) {
                aVar.pU = (Fragment) nVar.qB.get(i2);
            } else {
                aVar.pU = null;
            }
            i3 = i4 + 1;
            aVar.pV = this.qe[i4];
            i4 = i3 + 1;
            aVar.pW = this.qe[i3];
            i3 = i4 + 1;
            aVar.pX = this.qe[i4];
            int i5 = i3 + 1;
            aVar.pY = this.qe[i3];
            i4 = i5 + 1;
            int i6 = this.qe[i5];
            if (i6 > 0) {
                aVar.pZ = new ArrayList(i6);
                i3 = 0;
                while (i3 < i6) {
                    if (n.DEBUG) {
                        new StringBuilder("Instantiate ").append(eVar).append(" set remove fragment #").append(this.qe[i4]);
                    }
                    i5 = i4 + 1;
                    aVar.pZ.add((Fragment) nVar.qB.get(this.qe[i4]));
                    i3++;
                    i4 = i5;
                }
            }
            eVar.ps = aVar.pV;
            eVar.pt = aVar.pW;
            eVar.pu = aVar.pX;
            eVar.pv = aVar.pY;
            eVar.a(aVar);
            i++;
            i2 = i4;
        }
        eVar.pw = this.pw;
        eVar.px = this.px;
        eVar.mName = this.mName;
        eVar.mIndex = this.mIndex;
        eVar.py = true;
        eVar.pB = this.pB;
        eVar.pC = this.pC;
        eVar.pD = this.pD;
        eVar.pE = this.pE;
        eVar.pF = this.pF;
        eVar.pG = this.pG;
        eVar.N(1);
        return eVar;
    }

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeIntArray(this.qe);
        parcel.writeInt(this.pw);
        parcel.writeInt(this.px);
        parcel.writeString(this.mName);
        parcel.writeInt(this.mIndex);
        parcel.writeInt(this.pB);
        TextUtils.writeToParcel(this.pC, parcel, 0);
        parcel.writeInt(this.pD);
        TextUtils.writeToParcel(this.pE, parcel, 0);
        parcel.writeStringList(this.pF);
        parcel.writeStringList(this.pG);
    }
}
