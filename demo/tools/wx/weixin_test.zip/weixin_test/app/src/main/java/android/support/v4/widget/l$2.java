package android.support.v4.widget;

import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;

class l$2 implements AnimationListener {
    final /* synthetic */ l$a CV;
    final /* synthetic */ l CW;

    l$2(l lVar, l$a l_a) {
        this.CW = lVar;
        this.CV = l_a;
    }

    public final void onAnimationStart(Animation animation) {
        l.a(this.CW, 0.0f);
    }

    public final void onAnimationEnd(Animation animation) {
    }

    public final void onAnimationRepeat(Animation animation) {
        this.CV.cJ();
        l$a l_a = this.CV;
        l_a.ar(l_a.cI());
        this.CV.C(this.CV.Da);
        if (this.CW.CU) {
            this.CW.CU = false;
            animation.setDuration(1332);
            this.CV.C(false);
            return;
        }
        l.a(this.CW, (l.a(this.CW) + 1.0f) % 5.0f);
    }
}
