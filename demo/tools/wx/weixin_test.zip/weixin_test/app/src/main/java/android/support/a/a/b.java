package android.support.a.a;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.animation.AnimatorSet;
import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.AnimatedVectorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.Callback;
import android.graphics.drawable.Drawable.ConstantState;
import android.os.Build.VERSION;
import android.util.AttributeSet;
import java.util.ArrayList;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;

@TargetApi(21)
public final class b extends e implements Animatable {
    private Context mContext;
    private a ml;
    private ArgbEvaluator mm;
    private final Callback mn;

    private static class a extends ConstantState {
        int mp;
        f mq;
        ArrayList<Animator> mr;
        android.support.v4.e.a<Animator, String> ms;

        public a(a aVar, Callback callback, Resources resources) {
        }

        public final Drawable newDrawable() {
            throw new IllegalStateException("No constant state support for SDK < 23.");
        }

        public final Drawable newDrawable(Resources resources) {
            throw new IllegalStateException("No constant state support for SDK < 23.");
        }

        public final int getChangingConfigurations() {
            return this.mp;
        }
    }

    private static class b extends ConstantState {
        private final ConstantState mt;

        public b(ConstantState constantState) {
            this.mt = constantState;
        }

        public final Drawable newDrawable() {
            Drawable bVar = new b();
            bVar.my = this.mt.newDrawable();
            bVar.my.setCallback(bVar.mn);
            return bVar;
        }

        public final Drawable newDrawable(Resources resources) {
            Drawable bVar = new b();
            bVar.my = this.mt.newDrawable(resources);
            bVar.my.setCallback(bVar.mn);
            return bVar;
        }

        public final Drawable newDrawable(Resources resources, Theme theme) {
            Drawable bVar = new b();
            bVar.my = this.mt.newDrawable(resources, theme);
            bVar.my.setCallback(bVar.mn);
            return bVar;
        }

        public final boolean canApplyTheme() {
            return this.mt.canApplyTheme();
        }

        public final int getChangingConfigurations() {
            return this.mt.getChangingConfigurations();
        }
    }

    public final /* bridge */ /* synthetic */ void clearColorFilter() {
        super.clearColorFilter();
    }

    public final /* bridge */ /* synthetic */ ColorFilter getColorFilter() {
        return super.getColorFilter();
    }

    public final /* bridge */ /* synthetic */ Drawable getCurrent() {
        return super.getCurrent();
    }

    public final /* bridge */ /* synthetic */ int getLayoutDirection() {
        return super.getLayoutDirection();
    }

    public final /* bridge */ /* synthetic */ int getMinimumHeight() {
        return super.getMinimumHeight();
    }

    public final /* bridge */ /* synthetic */ int getMinimumWidth() {
        return super.getMinimumWidth();
    }

    public final /* bridge */ /* synthetic */ boolean getPadding(Rect rect) {
        return super.getPadding(rect);
    }

    public final /* bridge */ /* synthetic */ int[] getState() {
        return super.getState();
    }

    public final /* bridge */ /* synthetic */ Region getTransparentRegion() {
        return super.getTransparentRegion();
    }

    public final /* bridge */ /* synthetic */ boolean isAutoMirrored() {
        return super.isAutoMirrored();
    }

    public final /* bridge */ /* synthetic */ void jumpToCurrentState() {
        super.jumpToCurrentState();
    }

    public final /* bridge */ /* synthetic */ void setAutoMirrored(boolean z) {
        super.setAutoMirrored(z);
    }

    public final /* bridge */ /* synthetic */ void setChangingConfigurations(int i) {
        super.setChangingConfigurations(i);
    }

    public final /* bridge */ /* synthetic */ void setColorFilter(int i, Mode mode) {
        super.setColorFilter(i, mode);
    }

    public final /* bridge */ /* synthetic */ void setFilterBitmap(boolean z) {
        super.setFilterBitmap(z);
    }

    public final /* bridge */ /* synthetic */ void setHotspot(float f, float f2) {
        super.setHotspot(f, f2);
    }

    public final /* bridge */ /* synthetic */ void setHotspotBounds(int i, int i2, int i3, int i4) {
        super.setHotspotBounds(i, i2, i3, i4);
    }

    public final /* bridge */ /* synthetic */ boolean setState(int[] iArr) {
        return super.setState(iArr);
    }

    private b() {
        this(null, (byte) 0);
    }

    private b(Context context) {
        this(context, (byte) 0);
    }

    private b(Context context, byte b) {
        this.mm = null;
        this.mn = new Callback(this) {
            final /* synthetic */ b mo;

            {
                this.mo = r1;
            }

            public final void invalidateDrawable(Drawable drawable) {
                this.mo.invalidateSelf();
            }

            public final void scheduleDrawable(Drawable drawable, Runnable runnable, long j) {
                this.mo.scheduleSelf(runnable, j);
            }

            public final void unscheduleDrawable(Drawable drawable, Runnable runnable) {
                this.mo.unscheduleSelf(runnable);
            }
        };
        this.mContext = context;
        this.ml = new a(null, this.mn, null);
    }

    public final Drawable mutate() {
        if (this.my != null) {
            this.my.mutate();
            return this;
        }
        throw new IllegalStateException("Mutate() is not supported for older platform");
    }

    public static b a(Context context, Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Theme theme) {
        b bVar = new b(context);
        bVar.inflate(resources, xmlPullParser, attributeSet, theme);
        return bVar;
    }

    public final ConstantState getConstantState() {
        if (this.my != null) {
            return new b(this.my.getConstantState());
        }
        return null;
    }

    public final int getChangingConfigurations() {
        if (this.my != null) {
            return this.my.getChangingConfigurations();
        }
        return super.getChangingConfigurations() | this.ml.mp;
    }

    public final void draw(Canvas canvas) {
        if (this.my != null) {
            this.my.draw(canvas);
            return;
        }
        this.ml.mq.draw(canvas);
        if (isStarted()) {
            invalidateSelf();
        }
    }

    protected final void onBoundsChange(Rect rect) {
        if (this.my != null) {
            this.my.setBounds(rect);
        } else {
            this.ml.mq.setBounds(rect);
        }
    }

    protected final boolean onStateChange(int[] iArr) {
        if (this.my != null) {
            return this.my.setState(iArr);
        }
        return this.ml.mq.setState(iArr);
    }

    protected final boolean onLevelChange(int i) {
        if (this.my != null) {
            return this.my.setLevel(i);
        }
        return this.ml.mq.setLevel(i);
    }

    public final int getAlpha() {
        if (this.my != null) {
            return android.support.v4.b.a.a.e(this.my);
        }
        return this.ml.mq.getAlpha();
    }

    public final void setAlpha(int i) {
        if (this.my != null) {
            this.my.setAlpha(i);
        } else {
            this.ml.mq.setAlpha(i);
        }
    }

    public final void setColorFilter(ColorFilter colorFilter) {
        if (this.my != null) {
            this.my.setColorFilter(colorFilter);
        } else {
            this.ml.mq.setColorFilter(colorFilter);
        }
    }

    public final void setTint(int i) {
        if (this.my != null) {
            android.support.v4.b.a.a.a(this.my, i);
        } else {
            this.ml.mq.setTint(i);
        }
    }

    public final void setTintList(ColorStateList colorStateList) {
        if (this.my != null) {
            android.support.v4.b.a.a.a(this.my, colorStateList);
        } else {
            this.ml.mq.setTintList(colorStateList);
        }
    }

    public final void setTintMode(Mode mode) {
        if (this.my != null) {
            android.support.v4.b.a.a.a(this.my, mode);
        } else {
            this.ml.mq.setTintMode(mode);
        }
    }

    public final boolean setVisible(boolean z, boolean z2) {
        if (this.my != null) {
            return this.my.setVisible(z, z2);
        }
        this.ml.mq.setVisible(z, z2);
        return super.setVisible(z, z2);
    }

    public final boolean isStateful() {
        if (this.my != null) {
            return this.my.isStateful();
        }
        return this.ml.mq.isStateful();
    }

    public final int getOpacity() {
        if (this.my != null) {
            return this.my.getOpacity();
        }
        return this.ml.mq.getOpacity();
    }

    public final int getIntrinsicWidth() {
        if (this.my != null) {
            return this.my.getIntrinsicWidth();
        }
        return this.ml.mq.getIntrinsicWidth();
    }

    public final int getIntrinsicHeight() {
        if (this.my != null) {
            return this.my.getIntrinsicHeight();
        }
        return this.ml.mq.getIntrinsicHeight();
    }

    public final void inflate(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Theme theme) {
        if (this.my != null) {
            android.support.v4.b.a.a.a(this.my, resources, xmlPullParser, attributeSet, theme);
            return;
        }
        int eventType = xmlPullParser.getEventType();
        while (eventType != 1) {
            if (eventType == 2) {
                String name = xmlPullParser.getName();
                TypedArray obtainAttributes;
                if ("animated-vector".equals(name)) {
                    int[] iArr = a.mj;
                    obtainAttributes = theme == null ? resources.obtainAttributes(attributeSet, iArr) : theme.obtainStyledAttributes(attributeSet, iArr, 0, 0);
                    int resourceId = obtainAttributes.getResourceId(0, 0);
                    if (resourceId != 0) {
                        f a = f.a(resources, resourceId, theme);
                        a.mE = false;
                        a.setCallback(this.mn);
                        if (this.ml.mq != null) {
                            this.ml.mq.setCallback(null);
                        }
                        this.ml.mq = a;
                    }
                    obtainAttributes.recycle();
                } else if ("target".equals(name)) {
                    obtainAttributes = resources.obtainAttributes(attributeSet, a.mk);
                    String string = obtainAttributes.getString(0);
                    int resourceId2 = obtainAttributes.getResourceId(1, 0);
                    if (resourceId2 != 0) {
                        if (this.mContext != null) {
                            Animator loadAnimator = AnimatorInflater.loadAnimator(this.mContext, resourceId2);
                            loadAnimator.setTarget(this.ml.mq.mA.nw.nv.get(string));
                            if (VERSION.SDK_INT < 21) {
                                b(loadAnimator);
                            }
                            if (this.ml.mr == null) {
                                this.ml.mr = new ArrayList();
                                this.ml.ms = new android.support.v4.e.a();
                            }
                            this.ml.mr.add(loadAnimator);
                            this.ml.ms.put(loadAnimator, string);
                        } else {
                            throw new IllegalStateException("Context can't be null when inflating animators");
                        }
                    }
                    obtainAttributes.recycle();
                } else {
                    continue;
                }
            }
            eventType = xmlPullParser.next();
        }
    }

    public final void inflate(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet) {
        inflate(resources, xmlPullParser, attributeSet, null);
    }

    public final void applyTheme(Theme theme) {
        if (this.my != null) {
            android.support.v4.b.a.a.a(this.my, theme);
        }
    }

    public final boolean canApplyTheme() {
        if (this.my != null) {
            return android.support.v4.b.a.a.f(this.my);
        }
        return false;
    }

    private void b(Animator animator) {
        if (animator instanceof AnimatorSet) {
            List childAnimations = ((AnimatorSet) animator).getChildAnimations();
            if (childAnimations != null) {
                for (int i = 0; i < childAnimations.size(); i++) {
                    b((Animator) childAnimations.get(i));
                }
            }
        }
        if (animator instanceof ObjectAnimator) {
            ObjectAnimator objectAnimator = (ObjectAnimator) animator;
            String propertyName = objectAnimator.getPropertyName();
            if ("fillColor".equals(propertyName) || "strokeColor".equals(propertyName)) {
                if (this.mm == null) {
                    this.mm = new ArgbEvaluator();
                }
                objectAnimator.setEvaluator(this.mm);
            }
        }
    }

    public final boolean isRunning() {
        if (this.my != null) {
            return ((AnimatedVectorDrawable) this.my).isRunning();
        }
        ArrayList arrayList = this.ml.mr;
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            if (((Animator) arrayList.get(i)).isRunning()) {
                return true;
            }
        }
        return false;
    }

    private boolean isStarted() {
        ArrayList arrayList = this.ml.mr;
        if (arrayList == null) {
            return false;
        }
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            if (((Animator) arrayList.get(i)).isRunning()) {
                return true;
            }
        }
        return false;
    }

    public final void start() {
        if (this.my != null) {
            ((AnimatedVectorDrawable) this.my).start();
        } else if (!isStarted()) {
            ArrayList arrayList = this.ml.mr;
            int size = arrayList.size();
            for (int i = 0; i < size; i++) {
                ((Animator) arrayList.get(i)).start();
            }
            invalidateSelf();
        }
    }

    public final void stop() {
        if (this.my != null) {
            ((AnimatedVectorDrawable) this.my).stop();
            return;
        }
        ArrayList arrayList = this.ml.mr;
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            ((Animator) arrayList.get(i)).end();
        }
    }
}
