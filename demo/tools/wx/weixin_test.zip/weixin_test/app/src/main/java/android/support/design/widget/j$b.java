package android.support.design.widget;

class j$b extends j$a {
    final /* synthetic */ j iD;

    private j$b(j jVar) {
        this.iD = jVar;
        super(jVar, (byte) 0);
    }

    protected final float al() {
        return this.iD.iM + this.iD.iN;
    }
}
