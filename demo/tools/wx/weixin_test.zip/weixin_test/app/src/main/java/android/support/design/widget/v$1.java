package android.support.design.widget;

class v$1 implements Runnable {
    final /* synthetic */ v lM;

    v$1(v vVar) {
        this.lM = vVar;
    }

    public final void run() {
        v.a(this.lM);
    }
}
