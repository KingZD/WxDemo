package android.support.design.widget;

import android.support.v4.view.t;
import android.view.View;

interface g {
    void a(View view, t tVar);
}
