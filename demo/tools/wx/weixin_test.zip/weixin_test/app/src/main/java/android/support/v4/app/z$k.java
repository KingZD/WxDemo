package android.support.v4.app;

import android.app.Notification;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.app.ac.b;
import android.support.v4.app.aj.a;
import android.support.v4.app.z.j;

class z$k extends j {
    z$k() {
    }

    public final Notification b(z$d z_d) {
        y ab_a = new ab$a(z_d.mContext, z_d.sG, z_d.si, z_d.sj, z_d.so, z_d.sm, z_d.sp, z_d.sk, z_d.sl, z_d.sn, z_d.su, z_d.sv, z_d.sw, z_d.sq, z_d.sr, z_d.mPriority, z_d.st, z_d.sB, z_d.sC, z_d.sH, z_d.mExtras, z_d.sD, z_d.sE, z_d.sF, z_d.sx, z_d.sy, z_d.sz);
        z.a(ab_a, z_d.sA);
        z.a(ab_a, z_d.ss);
        return ab_a.build();
    }

    public final Bundle a(b bVar) {
        String str = null;
        int i = 0;
        if (bVar == null) {
            return null;
        }
        Bundle bundle = new Bundle();
        if (bVar.getParticipants() != null && bVar.getParticipants().length > 1) {
            str = bVar.getParticipants()[0];
        }
        Parcelable[] parcelableArr = new Parcelable[bVar.getMessages().length];
        while (i < parcelableArr.length) {
            Bundle bundle2 = new Bundle();
            bundle2.putString("text", bVar.getMessages()[i]);
            bundle2.putString("author", str);
            parcelableArr[i] = bundle2;
            i++;
        }
        bundle.putParcelableArray("messages", parcelableArr);
        a bv = bVar.bv();
        if (bv != null) {
            bundle.putParcelable("remote_input", ab.a(bv));
        }
        bundle.putParcelable("on_reply", bVar.getReplyPendingIntent());
        bundle.putParcelable("on_read", bVar.getReadPendingIntent());
        bundle.putStringArray("participants", bVar.getParticipants());
        bundle.putLong("timestamp", bVar.getLatestTimestamp());
        return bundle;
    }
}
