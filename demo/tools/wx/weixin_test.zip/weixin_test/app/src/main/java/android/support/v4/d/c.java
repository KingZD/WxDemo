package android.support.v4.d;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Locale;

final class c {
    private static Method vU;
    private static Method vV;

    static {
        try {
            Class cls = Class.forName("libcore.icu.ICU");
            if (cls != null) {
                vV = cls.getMethod("getScript", new Class[]{String.class});
                vU = cls.getMethod("addLikelySubtags", new Class[]{String.class});
            }
        } catch (Exception e) {
            vV = null;
            vU = null;
        }
    }

    public static String a(Locale locale) {
        String b = b(locale);
        if (b != null) {
            return u(b);
        }
        return null;
    }

    private static String u(String str) {
        try {
            if (vV != null) {
                return (String) vV.invoke(null, new Object[]{str});
            }
        } catch (IllegalAccessException e) {
        } catch (InvocationTargetException e2) {
        }
        return null;
    }

    private static String b(Locale locale) {
        String locale2 = locale.toString();
        try {
            if (vU != null) {
                return (String) vU.invoke(null, new Object[]{locale2});
            }
        } catch (IllegalAccessException e) {
        } catch (InvocationTargetException e2) {
        }
        return locale2;
    }
}
