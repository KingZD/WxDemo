package android.support.design.widget;

import android.content.Context;
import android.graphics.Rect;
import android.support.v4.view.f;
import android.support.v4.view.z;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.MeasureSpec;
import java.util.List;

abstract class HeaderScrollingViewBehavior extends ViewOffsetBehavior<View> {
    private final Rect hx = new Rect();
    private final Rect hy = new Rect();
    int jc = 0;
    int jd;

    abstract View e(List<View> list);

    public HeaderScrollingViewBehavior(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public boolean a(CoordinatorLayout coordinatorLayout, View view, int i, int i2, int i3, int i4) {
        int i5 = view.getLayoutParams().height;
        if (i5 == -1 || i5 == -2) {
            View e = e(coordinatorLayout.n(view));
            if (e != null) {
                if (z.Z(e) && !z.Z(view)) {
                    z.a(view, true);
                    if (z.Z(view)) {
                        view.requestLayout();
                        return true;
                    }
                }
                if (z.ai(e)) {
                    int size = MeasureSpec.getSize(i3);
                    if (size == 0) {
                        size = coordinatorLayout.getHeight();
                    }
                    coordinatorLayout.a(view, i, i2, MeasureSpec.makeMeasureSpec(g(e) + (size - e.getMeasuredHeight()), i5 == -1 ? 1073741824 : Integer.MIN_VALUE), i4);
                    return true;
                }
            }
        }
        return false;
    }

    protected final void d(CoordinatorLayout coordinatorLayout, View view, int i) {
        View e = e(coordinatorLayout.n(view));
        if (e != null) {
            CoordinatorLayout$d coordinatorLayout$d = (CoordinatorLayout$d) view.getLayoutParams();
            Rect rect = this.hx;
            rect.set(coordinatorLayout.getPaddingLeft() + coordinatorLayout$d.leftMargin, e.getBottom() + coordinatorLayout$d.topMargin, (coordinatorLayout.getWidth() - coordinatorLayout.getPaddingRight()) - coordinatorLayout$d.rightMargin, ((coordinatorLayout.getHeight() + e.getBottom()) - coordinatorLayout.getPaddingBottom()) - coordinatorLayout$d.bottomMargin);
            Rect rect2 = this.hy;
            int i2 = coordinatorLayout$d.gravity;
            if (i2 == 0) {
                i2 = 8388659;
            }
            f.apply(i2, view.getMeasuredWidth(), view.getMeasuredHeight(), rect, rect2, i);
            i2 = o(e);
            view.layout(rect2.left, rect2.top - i2, rect2.right, rect2.bottom - i2);
            this.jc = rect2.top - e.getBottom();
            return;
        }
        super.d(coordinatorLayout, view, i);
        this.jc = 0;
    }

    float f(View view) {
        return 1.0f;
    }

    final int o(View view) {
        return this.jd == 0 ? 0 : n.e(Math.round(f(view) * ((float) this.jd)), 0, this.jd);
    }

    int g(View view) {
        return view.getMeasuredHeight();
    }
}
