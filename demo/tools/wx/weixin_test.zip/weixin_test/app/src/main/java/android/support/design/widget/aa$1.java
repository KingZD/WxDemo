package android.support.design.widget;

import android.os.Build.VERSION;

class aa$1 implements u$d {
    aa$1() {
    }

    public final u aJ() {
        return new u(VERSION.SDK_INT >= 12 ? new w() : new v());
    }
}
