package android.support.design.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.design.a$i;
import android.support.design.a.h;
import android.support.design.widget.CoordinatorLayout.b;
import android.support.v4.view.ap;
import android.support.v4.view.t;
import android.support.v4.view.z;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.BaseSavedState;
import android.view.View.MeasureSpec;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.animation.Interpolator;
import android.widget.LinearLayout;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

@b(Behavior.class)
public class AppBarLayout extends LinearLayout {
    private int eR = -1;
    private int eS = -1;
    private int eT = -1;
    boolean eU;
    float eV;
    private int eW = 0;
    private ap eX;
    final List<AppBarLayout$a> eY;

    public static class Behavior extends HeaderBehavior<AppBarLayout> {
        private int fa;
        private boolean fb;
        private boolean fc;
        private u fd;
        private int fe = -1;
        private boolean ff;
        private float fg;
        private WeakReference<View> fh;
        private AppBarLayout$Behavior$a fi;

        protected static class SavedState extends BaseSavedState {
            public static final Creator<SavedState> CREATOR = android.support.v4.os.b.a(new AppBarLayout$Behavior$SavedState$1());
            int fn;
            float fo;
            boolean fp;

            public SavedState(Parcel parcel) {
                super(parcel);
                this.fn = parcel.readInt();
                this.fo = parcel.readFloat();
                this.fp = parcel.readByte() != (byte) 0;
            }

            public SavedState(Parcelable parcelable) {
                super(parcelable);
            }

            public void writeToParcel(Parcel parcel, int i) {
                super.writeToParcel(parcel, i);
                parcel.writeInt(this.fn);
                parcel.writeFloat(this.fo);
                parcel.writeByte((byte) (this.fp ? 1 : 0));
            }
        }

        public final /* bridge */ /* synthetic */ int V() {
            return super.V();
        }

        final /* synthetic */ int a(CoordinatorLayout coordinatorLayout, View view, int i, int i2, int i3) {
            view = (AppBarLayout) view;
            int U = U();
            if (i2 == 0 || U < i2 || U > i3) {
                this.fa = 0;
                return 0;
            }
            int e = n.e(i, i2, i3);
            if (U == e) {
                return 0;
            }
            int abs;
            int i4;
            int height;
            if (view.eU) {
                abs = Math.abs(e);
                int childCount = view.getChildCount();
                i4 = 0;
                while (i4 < childCount) {
                    View childAt = view.getChildAt(i4);
                    AppBarLayout$LayoutParams appBarLayout$LayoutParams = (AppBarLayout$LayoutParams) childAt.getLayoutParams();
                    Interpolator interpolator = appBarLayout$LayoutParams.fr;
                    if (abs < childAt.getTop() || abs > childAt.getBottom()) {
                        i4++;
                    } else {
                        if (interpolator != null) {
                            i4 = appBarLayout$LayoutParams.fq;
                            if ((i4 & 1) != 0) {
                                height = (appBarLayout$LayoutParams.bottomMargin + (childAt.getHeight() + appBarLayout$LayoutParams.topMargin)) + 0;
                                if ((i4 & 2) != 0) {
                                    height -= z.T(childAt);
                                }
                            } else {
                                height = 0;
                            }
                            if (z.Z(childAt)) {
                                height -= view.T();
                            }
                            if (height > 0) {
                                i4 = abs - childAt.getTop();
                                height = Math.round(interpolator.getInterpolation(((float) i4) / ((float) height)) * ((float) height));
                                height = (height + childAt.getTop()) * Integer.signum(e);
                            }
                        }
                        height = e;
                    }
                }
                height = e;
            } else {
                height = e;
            }
            boolean q = super.q(height);
            i4 = U - e;
            this.fa = e - height;
            if (!q && view.eU) {
                abs = coordinatorLayout.hu.size();
                U = 0;
                e = 0;
                while (U < abs) {
                    View view2 = (View) coordinatorLayout.hu.get(U);
                    if (view2 == view) {
                        height = 1;
                    } else {
                        if (e != 0) {
                            CoordinatorLayout$d coordinatorLayout$d = (CoordinatorLayout$d) view2.getLayoutParams();
                            android.support.design.widget.CoordinatorLayout.Behavior behavior = coordinatorLayout$d.hO;
                            if (behavior != null && coordinatorLayout$d.c(coordinatorLayout, view2, view)) {
                                behavior.b(coordinatorLayout, view2, view);
                            }
                        }
                        height = e;
                    }
                    U++;
                    e = height;
                }
            }
            j(view);
            return i4;
        }

        public final /* synthetic */ void a(CoordinatorLayout coordinatorLayout, View view, Parcelable parcelable) {
            AppBarLayout appBarLayout = (AppBarLayout) view;
            if (parcelable instanceof SavedState) {
                SavedState savedState = (SavedState) parcelable;
                super.a(coordinatorLayout, appBarLayout, savedState.getSuperState());
                this.fe = savedState.fn;
                this.fg = savedState.fo;
                this.ff = savedState.fp;
                return;
            }
            super.a(coordinatorLayout, appBarLayout, parcelable);
            this.fe = -1;
        }

        public final /* synthetic */ void a(CoordinatorLayout coordinatorLayout, View view, View view2) {
            AppBarLayout appBarLayout = (AppBarLayout) view;
            if (!this.fc) {
                a(coordinatorLayout, appBarLayout);
            }
            this.fb = false;
            this.fc = false;
            this.fh = new WeakReference(view2);
        }

        public final /* synthetic */ void a(CoordinatorLayout coordinatorLayout, View view, View view2, int i, int[] iArr) {
            AppBarLayout appBarLayout = (AppBarLayout) view;
            if (i != 0 && !this.fb) {
                int i2;
                int b;
                if (i < 0) {
                    i2 = -appBarLayout.S();
                    b = i2 + AppBarLayout.b(appBarLayout);
                } else {
                    i2 = -appBarLayout.S();
                    b = 0;
                }
                iArr[1] = b(coordinatorLayout, appBarLayout, i, i2, b);
            }
        }

        public final /* synthetic */ boolean a(CoordinatorLayout coordinatorLayout, View view, float f, boolean z) {
            boolean z2 = true;
            AppBarLayout appBarLayout = (AppBarLayout) view;
            if (z) {
                int b;
                if (f < 0.0f) {
                    b = (-appBarLayout.S()) + AppBarLayout.b(appBarLayout);
                    if (U() < b) {
                        a(coordinatorLayout, appBarLayout, b);
                    }
                } else {
                    b = -appBarLayout.S();
                    if (U() > b) {
                        a(coordinatorLayout, appBarLayout, b);
                    }
                }
                z2 = false;
            } else {
                z2 = a(coordinatorLayout, appBarLayout, -appBarLayout.S(), -f);
            }
            this.fc = z2;
            return z2;
        }

        public final /* synthetic */ boolean a(CoordinatorLayout coordinatorLayout, View view, int i) {
            AppBarLayout appBarLayout = (AppBarLayout) view;
            boolean a = super.a(coordinatorLayout, appBarLayout, i);
            int e = appBarLayout.eW;
            if (e != 0) {
                int i2 = (e & 4) != 0 ? 1 : 0;
                if ((e & 2) != 0) {
                    e = -appBarLayout.S();
                    if (i2 != 0) {
                        a(coordinatorLayout, appBarLayout, e);
                    } else {
                        c(coordinatorLayout, appBarLayout, e);
                    }
                } else if ((e & 1) != 0) {
                    if (i2 != 0) {
                        a(coordinatorLayout, appBarLayout, 0);
                    } else {
                        c(coordinatorLayout, appBarLayout, 0);
                    }
                }
            } else if (this.fe >= 0) {
                View childAt = appBarLayout.getChildAt(this.fe);
                e = -childAt.getBottom();
                super.q(this.ff ? z.T(childAt) + e : Math.round(((float) childAt.getHeight()) * this.fg) + e);
            }
            appBarLayout.eW = 0;
            this.fe = -1;
            super.q(n.e(super.V(), -appBarLayout.S(), 0));
            j(appBarLayout);
            return a;
        }

        public final /* synthetic */ boolean a(CoordinatorLayout coordinatorLayout, View view, int i, int i2, int i3, int i4) {
            View view2 = (AppBarLayout) view;
            if (((CoordinatorLayout$d) view2.getLayoutParams()).height != -2) {
                return super.a(coordinatorLayout, view2, i, i2, i3, i4);
            }
            coordinatorLayout.a(view2, i, i2, MeasureSpec.makeMeasureSpec(0, 0), i4);
            return true;
        }

        public final /* synthetic */ boolean a(CoordinatorLayout coordinatorLayout, View view, View view2, int i) {
            AppBarLayout appBarLayout = (AppBarLayout) view;
            boolean z = (i & 2) != 0 && AppBarLayout.a(appBarLayout) && coordinatorLayout.getHeight() - view2.getHeight() <= appBarLayout.getHeight();
            if (z && this.fd != null) {
                this.fd.lD.cancel();
            }
            this.fh = null;
            return z;
        }

        final /* synthetic */ int b(View view) {
            return ((AppBarLayout) view).S();
        }

        public final /* synthetic */ Parcelable b(CoordinatorLayout coordinatorLayout, View view) {
            boolean z = false;
            AppBarLayout appBarLayout = (AppBarLayout) view;
            Parcelable b = super.b(coordinatorLayout, appBarLayout);
            int V = super.V();
            int childCount = appBarLayout.getChildCount();
            int i = 0;
            while (i < childCount) {
                View childAt = appBarLayout.getChildAt(i);
                int bottom = childAt.getBottom() + V;
                if (childAt.getTop() + V > 0 || bottom < 0) {
                    i++;
                } else {
                    SavedState savedState = new SavedState(b);
                    savedState.fn = i;
                    if (bottom == z.T(childAt)) {
                        z = true;
                    }
                    savedState.fp = z;
                    savedState.fo = ((float) bottom) / ((float) childAt.getHeight());
                    return savedState;
                }
            }
            return b;
        }

        public final /* synthetic */ void b(CoordinatorLayout coordinatorLayout, View view, int i) {
            AppBarLayout appBarLayout = (AppBarLayout) view;
            if (i < 0) {
                b(coordinatorLayout, appBarLayout, i, -AppBarLayout.d(appBarLayout), 0);
                this.fb = true;
                return;
            }
            this.fb = false;
        }

        final /* synthetic */ int c(View view) {
            return -AppBarLayout.d((AppBarLayout) view);
        }

        final /* synthetic */ boolean d(View view) {
            if (this.fi != null) {
                return this.fi.W();
            }
            if (this.fh != null) {
                View view2 = (View) this.fh.get();
                if (view2 == null || !view2.isShown() || z.h(view2, -1)) {
                    return false;
                }
            }
            return true;
        }

        public final /* bridge */ /* synthetic */ boolean q(int i) {
            return super.q(i);
        }

        public Behavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        private void a(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, int i) {
            int U = U();
            if (U != i) {
                if (this.fd == null) {
                    this.fd = aa.aJ();
                    this.fd.setInterpolator(a.eQ);
                    this.fd.a(new AppBarLayout$Behavior$1(this, coordinatorLayout, appBarLayout));
                } else {
                    this.fd.lD.cancel();
                }
                this.fd.setDuration(Math.round(((((float) Math.abs(U - i)) / coordinatorLayout.getResources().getDisplayMetrics().density) * 1000.0f) / 300.0f));
                this.fd.i(U, i);
                this.fd.lD.start();
            } else if (this.fd != null && this.fd.lD.isRunning()) {
                this.fd.lD.cancel();
            }
        }

        private void a(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout) {
            int i;
            View view;
            int U = U();
            int childCount = appBarLayout.getChildCount();
            for (i = 0; i < childCount; i++) {
                View childAt = appBarLayout.getChildAt(i);
                if (childAt.getTop() <= (-U) && childAt.getBottom() >= (-U)) {
                    view = childAt;
                    break;
                }
            }
            view = null;
            if (view != null) {
                AppBarLayout$LayoutParams appBarLayout$LayoutParams = (AppBarLayout$LayoutParams) view.getLayoutParams();
                if ((appBarLayout$LayoutParams.fq & 17) == 17) {
                    int T;
                    childCount = -view.getTop();
                    i = -view.getBottom();
                    if ((appBarLayout$LayoutParams.fq & 2) == 2) {
                        T = z.T(view) + i;
                    } else {
                        T = i;
                    }
                    if (U >= (T + childCount) / 2) {
                        T = childCount;
                    }
                    a(coordinatorLayout, appBarLayout, n.e(T, -appBarLayout.S(), 0));
                }
            }
        }

        private void j(AppBarLayout appBarLayout) {
            List h = appBarLayout.eY;
            int size = h.size();
            for (int i = 0; i < size; i++) {
                AppBarLayout$a appBarLayout$a = (AppBarLayout$a) h.get(i);
                if (appBarLayout$a != null) {
                    appBarLayout$a.a(appBarLayout, super.V());
                }
            }
        }

        final int U() {
            return super.V() + this.fa;
        }
    }

    protected /* synthetic */ LayoutParams generateDefaultLayoutParams() {
        return new AppBarLayout$LayoutParams();
    }

    /* renamed from: generateDefaultLayoutParams */
    protected /* synthetic */ LinearLayout.LayoutParams m1generateDefaultLayoutParams() {
        return new AppBarLayout$LayoutParams();
    }

    public /* synthetic */ LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return a(attributeSet);
    }

    protected /* synthetic */ LayoutParams generateLayoutParams(LayoutParams layoutParams) {
        return a(layoutParams);
    }

    /* renamed from: generateLayoutParams */
    public /* synthetic */ LinearLayout.LayoutParams m2generateLayoutParams(AttributeSet attributeSet) {
        return a(attributeSet);
    }

    /* renamed from: generateLayoutParams */
    protected /* synthetic */ LinearLayout.LayoutParams m3generateLayoutParams(LayoutParams layoutParams) {
        return a(layoutParams);
    }

    static /* synthetic */ ap a(AppBarLayout appBarLayout, ap apVar) {
        ap apVar2 = null;
        if (z.Z(appBarLayout)) {
            apVar2 = apVar;
        }
        if (apVar2 != appBarLayout.eX) {
            appBarLayout.eX = apVar2;
            appBarLayout.R();
        }
        return apVar;
    }

    static /* synthetic */ boolean a(AppBarLayout appBarLayout) {
        return appBarLayout.S() != 0;
    }

    static /* synthetic */ int b(AppBarLayout appBarLayout) {
        if (appBarLayout.eS != -1) {
            return appBarLayout.eS;
        }
        int i;
        int childCount = appBarLayout.getChildCount() - 1;
        int i2 = 0;
        while (childCount >= 0) {
            View childAt = appBarLayout.getChildAt(childCount);
            AppBarLayout$LayoutParams appBarLayout$LayoutParams = (AppBarLayout$LayoutParams) childAt.getLayoutParams();
            int measuredHeight = childAt.getMeasuredHeight();
            int i3 = appBarLayout$LayoutParams.fq;
            if ((i3 & 5) != 5) {
                if (i2 > 0) {
                    break;
                }
                i = i2;
            } else {
                i = (appBarLayout$LayoutParams.bottomMargin + appBarLayout$LayoutParams.topMargin) + i2;
                i = (i3 & 8) != 0 ? i + z.T(childAt) : (i3 & 2) != 0 ? i + (measuredHeight - z.T(childAt)) : i + measuredHeight;
            }
            childCount--;
            i2 = i;
        }
        i = Math.max(0, i2);
        appBarLayout.eS = i;
        return i;
    }

    static /* synthetic */ int d(AppBarLayout appBarLayout) {
        if (appBarLayout.eT != -1) {
            return appBarLayout.eT;
        }
        int i;
        int childCount = appBarLayout.getChildCount();
        int i2 = 0;
        for (int i3 = 0; i3 < childCount; i3++) {
            View childAt = appBarLayout.getChildAt(i3);
            AppBarLayout$LayoutParams appBarLayout$LayoutParams = (AppBarLayout$LayoutParams) childAt.getLayoutParams();
            int measuredHeight = childAt.getMeasuredHeight() + (appBarLayout$LayoutParams.topMargin + appBarLayout$LayoutParams.bottomMargin);
            i = appBarLayout$LayoutParams.fq;
            if ((i & 1) == 0) {
                break;
            }
            i2 += measuredHeight;
            if ((i & 2) != 0) {
                i = i2 - (z.T(childAt) + appBarLayout.T());
                break;
            }
        }
        i = i2;
        i = Math.max(0, i);
        appBarLayout.eT = i;
        return i;
    }

    public AppBarLayout(Context context, AttributeSet attributeSet) {
        int i = 1;
        int i2 = 0;
        super(context, attributeSet);
        setOrientation(1);
        t.p(context);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, a$i.cb, 0, h.bS);
        this.eV = (float) obtainStyledAttributes.getDimensionPixelSize(a$i.cd, 0);
        setBackgroundDrawable(obtainStyledAttributes.getDrawable(a$i.cc));
        if (obtainStyledAttributes.hasValue(a$i.ce)) {
            boolean z = obtainStyledAttributes.getBoolean(a$i.ce, false);
            boolean ai = z.ai(this);
            if (!z) {
                i = 2;
            }
            if (ai) {
                i2 = 4;
            }
            this.eW = i2 | i;
            requestLayout();
        }
        obtainStyledAttributes.recycle();
        aa.u(this);
        this.eY = new ArrayList();
        z.g(this, this.eV);
        z.b(this, new t(this) {
            final /* synthetic */ AppBarLayout eZ;

            {
                this.eZ = r1;
            }

            public final ap a(View view, ap apVar) {
                return AppBarLayout.a(this.eZ, apVar);
            }
        });
    }

    protected void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        R();
    }

    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        R();
        this.eU = false;
        int childCount = getChildCount();
        for (int i5 = 0; i5 < childCount; i5++) {
            if (((AppBarLayout$LayoutParams) getChildAt(i5).getLayoutParams()).fr != null) {
                this.eU = true;
                return;
            }
        }
    }

    private void R() {
        this.eR = -1;
        this.eS = -1;
        this.eT = -1;
    }

    public void setOrientation(int i) {
        if (i != 1) {
            throw new IllegalArgumentException("AppBarLayout is always vertical and does not support horizontal orientation");
        }
        super.setOrientation(i);
    }

    protected boolean checkLayoutParams(LayoutParams layoutParams) {
        return layoutParams instanceof AppBarLayout$LayoutParams;
    }

    private AppBarLayout$LayoutParams a(AttributeSet attributeSet) {
        return new AppBarLayout$LayoutParams(getContext(), attributeSet);
    }

    private static AppBarLayout$LayoutParams a(LayoutParams layoutParams) {
        if (layoutParams instanceof LinearLayout.LayoutParams) {
            return new AppBarLayout$LayoutParams((LinearLayout.LayoutParams) layoutParams);
        }
        if (layoutParams instanceof MarginLayoutParams) {
            return new AppBarLayout$LayoutParams((MarginLayoutParams) layoutParams);
        }
        return new AppBarLayout$LayoutParams(layoutParams);
    }

    public final int S() {
        if (this.eR != -1) {
            return this.eR;
        }
        int T;
        int childCount = getChildCount();
        int i = 0;
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            AppBarLayout$LayoutParams appBarLayout$LayoutParams = (AppBarLayout$LayoutParams) childAt.getLayoutParams();
            int measuredHeight = childAt.getMeasuredHeight();
            int i3 = appBarLayout$LayoutParams.fq;
            if ((i3 & 1) == 0) {
                break;
            }
            i += appBarLayout$LayoutParams.bottomMargin + (measuredHeight + appBarLayout$LayoutParams.topMargin);
            if ((i3 & 2) != 0) {
                T = i - z.T(childAt);
                break;
            }
        }
        T = i;
        T = Math.max(0, T - T());
        this.eR = T;
        return T;
    }

    final int T() {
        return this.eX != null ? this.eX.getSystemWindowInsetTop() : 0;
    }
}
