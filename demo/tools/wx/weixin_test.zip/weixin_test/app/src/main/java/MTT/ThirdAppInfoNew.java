package MTT;

public final class ThirdAppInfoNew implements Cloneable {
    public int iCoreType = 0;
    public long iPv = 0;
    public int localCoreVersion = 0;
    public String sAndroidID = "";
    public String sAppName = "";
    public String sAppSignature = "";
    public String sAppVersionName = "";
    public String sGuid = "";
    public String sImei = "";
    public String sImsi = "";
    public String sLc = "";
    public String sMac = "";
    public String sQua2 = "";
    public String sTime = "";
    public long sWifiConnectedTime = 0;
}
