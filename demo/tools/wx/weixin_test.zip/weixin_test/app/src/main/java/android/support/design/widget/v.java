package android.support.design.widget;

import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.Interpolator;

final class v extends u$e {
    private static final Handler jC = new Handler(Looper.getMainLooper());
    private final int[] lH = new int[2];
    private final float[] lI = new float[2];
    private u$e$a lJ;
    private u$e$b lK;
    private float lL;
    private int mDuration = 200;
    private Interpolator mInterpolator;
    private boolean mIsRunning;
    private final Runnable mRunnable = new v$1(this);
    private long mStartTime;

    v() {
    }

    static /* synthetic */ void a(v vVar) {
        if (vVar.mIsRunning) {
            float uptimeMillis = ((float) (SystemClock.uptimeMillis() - vVar.mStartTime)) / ((float) vVar.mDuration);
            if (vVar.mInterpolator != null) {
                uptimeMillis = vVar.mInterpolator.getInterpolation(uptimeMillis);
            }
            vVar.lL = uptimeMillis;
            if (vVar.lK != null) {
                vVar.lK.aI();
            }
            if (SystemClock.uptimeMillis() >= vVar.mStartTime + ((long) vVar.mDuration)) {
                vVar.mIsRunning = false;
                if (vVar.lJ != null) {
                    vVar.lJ.onAnimationEnd();
                }
            }
        }
        if (vVar.mIsRunning) {
            jC.postDelayed(vVar.mRunnable, 10);
        }
    }

    public final void start() {
        if (!this.mIsRunning) {
            if (this.mInterpolator == null) {
                this.mInterpolator = new AccelerateDecelerateInterpolator();
            }
            this.mStartTime = SystemClock.uptimeMillis();
            this.mIsRunning = true;
            jC.postDelayed(this.mRunnable, 10);
        }
    }

    public final boolean isRunning() {
        return this.mIsRunning;
    }

    public final void setInterpolator(Interpolator interpolator) {
        this.mInterpolator = interpolator;
    }

    public final void a(u$e$a u_e_a) {
        this.lJ = u_e_a;
    }

    public final void a(u$e$b u_e_b) {
        this.lK = u_e_b;
    }

    public final void i(int i, int i2) {
        this.lH[0] = i;
        this.lH[1] = i2;
    }

    public final int aK() {
        return a.a(this.lH[0], this.lH[1], this.lL);
    }

    public final void p(float f, float f2) {
        this.lI[0] = f;
        this.lI[1] = f2;
    }

    public final float aL() {
        return a.b(this.lI[0], this.lI[1], this.lL);
    }

    public final void setDuration(int i) {
        this.mDuration = i;
    }

    public final void cancel() {
        this.mIsRunning = false;
        jC.removeCallbacks(this.mRunnable);
    }

    public final float getAnimatedFraction() {
        return this.lL;
    }

    public final long getDuration() {
        return (long) this.mDuration;
    }
}
