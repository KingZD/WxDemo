package android.support.design.widget;

interface Snackbar$SnackbarLayout$a {
    void ay();
}
