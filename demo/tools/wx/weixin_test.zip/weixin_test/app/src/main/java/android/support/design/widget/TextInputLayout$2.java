package android.support.design.widget;

import android.support.v4.view.an;
import android.view.View;

class TextInputLayout$2 extends an {
    final /* synthetic */ TextInputLayout lz;

    TextInputLayout$2(TextInputLayout textInputLayout) {
        this.lz = textInputLayout;
    }

    public final void p(View view) {
        view.setVisibility(0);
    }
}
