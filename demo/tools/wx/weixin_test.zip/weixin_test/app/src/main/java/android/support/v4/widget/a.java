package android.support.v4.widget;

import android.content.res.Resources;
import android.os.SystemClock;
import android.support.v4.view.o;
import android.support.v4.view.z;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewConfiguration;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;

public abstract class a implements OnTouchListener {
    private static final int Bi = ViewConfiguration.getTapTimeout();
    private final a AT = new a();
    private final Interpolator AU = new AccelerateInterpolator();
    private float[] AV = new float[]{0.0f, 0.0f};
    private float[] AW = new float[]{Float.MAX_VALUE, Float.MAX_VALUE};
    private int AX;
    private int AY;
    private float[] AZ = new float[]{0.0f, 0.0f};
    private float[] Ba = new float[]{0.0f, 0.0f};
    private float[] Bb = new float[]{Float.MAX_VALUE, Float.MAX_VALUE};
    private boolean Bc;
    private boolean Bd;
    private boolean Be;
    private boolean Bf;
    private boolean Bg;
    private boolean Bh;
    private Runnable mRunnable;
    private final View oV;

    private static class a {
        int Bj;
        int Bk;
        float Bl;
        float Bm;
        long Bn = 0;
        int Bo = 0;
        int Bp = 0;
        long Bq = -1;
        float Br;
        int Bs;
        long mStartTime = Long.MIN_VALUE;

        final float j(long j) {
            if (j < this.mStartTime) {
                return 0.0f;
            }
            if (this.Bq < 0 || j < this.Bq) {
                return a.e(((float) (j - this.mStartTime)) / ((float) this.Bj), 0.0f, 1.0f) * 0.5f;
            }
            long j2 = j - this.Bq;
            return (a.e(((float) j2) / ((float) this.Bs), 0.0f, 1.0f) * this.Br) + (1.0f - this.Br);
        }
    }

    private class b implements Runnable {
        final /* synthetic */ a Bt;

        private b(a aVar) {
            this.Bt = aVar;
        }

        public final void run() {
            int i = 0;
            if (this.Bt.Bf) {
                a d;
                if (this.Bt.Bd) {
                    this.Bt.Bd = false;
                    d = this.Bt.AT;
                    d.mStartTime = AnimationUtils.currentAnimationTimeMillis();
                    d.Bq = -1;
                    d.Bn = d.mStartTime;
                    d.Br = 0.5f;
                    d.Bo = 0;
                    d.Bp = 0;
                }
                d = this.Bt.AT;
                if (d.Bq > 0 && AnimationUtils.currentAnimationTimeMillis() > d.Bq + ((long) d.Bs)) {
                    i = 1;
                }
                if (i == 0 && this.Bt.aw()) {
                    if (this.Bt.Be) {
                        this.Bt.Be = false;
                        a.i(this.Bt);
                    }
                    if (d.Bn == 0) {
                        throw new RuntimeException("Cannot compute scroll delta before calling start()");
                    }
                    long currentAnimationTimeMillis = AnimationUtils.currentAnimationTimeMillis();
                    float j = d.j(currentAnimationTimeMillis);
                    j = (j * 4.0f) + ((-4.0f * j) * j);
                    long j2 = currentAnimationTimeMillis - d.Bn;
                    d.Bn = currentAnimationTimeMillis;
                    d.Bo = (int) ((((float) j2) * j) * d.Bl);
                    d.Bp = (int) ((j * ((float) j2)) * d.Bm);
                    this.Bt.an(d.Bp);
                    z.a(this.Bt.oV, (Runnable) this);
                    return;
                }
                this.Bt.Bf = false;
            }
        }
    }

    public abstract void an(int i);

    public abstract boolean ao(int i);

    static /* synthetic */ void i(a aVar) {
        long uptimeMillis = SystemClock.uptimeMillis();
        MotionEvent obtain = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
        aVar.oV.onTouchEvent(obtain);
        obtain.recycle();
    }

    public a(View view) {
        this.oV = view;
        DisplayMetrics displayMetrics = Resources.getSystem().getDisplayMetrics();
        int i = (int) ((1575.0f * displayMetrics.density) + 0.5f);
        int i2 = (int) ((displayMetrics.density * 315.0f) + 0.5f);
        float f = (float) i;
        this.Bb[0] = f / 1000.0f;
        this.Bb[1] = f / 1000.0f;
        float f2 = (float) i2;
        this.Ba[0] = f2 / 1000.0f;
        this.Ba[1] = f2 / 1000.0f;
        this.AX = 1;
        this.AW[0] = Float.MAX_VALUE;
        this.AW[1] = Float.MAX_VALUE;
        this.AV[0] = 0.2f;
        this.AV[1] = 0.2f;
        this.AZ[0] = 0.001f;
        this.AZ[1] = 0.001f;
        this.AY = Bi;
        this.AT.Bj = 500;
        this.AT.Bk = 500;
    }

    public final a z(boolean z) {
        if (this.Bg && !z) {
            cw();
        }
        this.Bg = z;
        return this;
    }

    public boolean onTouch(View view, MotionEvent motionEvent) {
        if (!this.Bg) {
            return false;
        }
        switch (o.d(motionEvent)) {
            case 0:
                this.Be = true;
                this.Bc = false;
                break;
            case 1:
            case 3:
                cw();
                break;
            case 2:
                break;
        }
        float a = a(0, motionEvent.getX(), (float) view.getWidth(), (float) this.oV.getWidth());
        float a2 = a(1, motionEvent.getY(), (float) view.getHeight(), (float) this.oV.getHeight());
        a aVar = this.AT;
        aVar.Bl = a;
        aVar.Bm = a2;
        if (!this.Bf && aw()) {
            if (this.mRunnable == null) {
                this.mRunnable = new b();
            }
            this.Bf = true;
            this.Bd = true;
            if (this.Bc || this.AY <= 0) {
                this.mRunnable.run();
            } else {
                z.a(this.oV, this.mRunnable, (long) this.AY);
            }
            this.Bc = true;
        }
        if (this.Bh && this.Bf) {
            return true;
        }
        return false;
    }

    private boolean aw() {
        a aVar = this.AT;
        int abs = (int) (aVar.Bm / Math.abs(aVar.Bm));
        int abs2 = (int) (aVar.Bl / Math.abs(aVar.Bl));
        if (abs != 0 && ao(abs)) {
            return true;
        }
        if (abs2 != 0) {
        }
        return false;
    }

    private void cw() {
        if (this.Bd) {
            this.Bf = false;
            return;
        }
        a aVar = this.AT;
        long currentAnimationTimeMillis = AnimationUtils.currentAnimationTimeMillis();
        int i = (int) (currentAnimationTimeMillis - aVar.mStartTime);
        int i2 = aVar.Bk;
        if (i <= i2) {
            i2 = i < 0 ? 0 : i;
        }
        aVar.Bs = i2;
        aVar.Br = aVar.j(currentAnimationTimeMillis);
        aVar.Bq = currentAnimationTimeMillis;
    }

    private float a(int i, float f, float f2, float f3) {
        float f4;
        float f5;
        float f6;
        float e = e(this.AV[i] * f2, 0.0f, this.AW[i]);
        e = r(f2 - f, e) - r(f, e);
        if (e < 0.0f) {
            e = -this.AU.getInterpolation(-e);
        } else if (e > 0.0f) {
            e = this.AU.getInterpolation(e);
        } else {
            e = 0.0f;
            if (e == 0.0f) {
                return 0.0f;
            }
            f4 = this.AZ[i];
            f5 = this.Ba[i];
            f6 = this.Bb[i];
            f4 *= f3;
            if (e <= 0.0f) {
                return e(e * f4, f5, f6);
            }
            return -e((-e) * f4, f5, f6);
        }
        e = e(e, -1.0f, 1.0f);
        if (e == 0.0f) {
            return 0.0f;
        }
        f4 = this.AZ[i];
        f5 = this.Ba[i];
        f6 = this.Bb[i];
        f4 *= f3;
        if (e <= 0.0f) {
            return -e((-e) * f4, f5, f6);
        }
        return e(e * f4, f5, f6);
    }

    private float r(float f, float f2) {
        if (f2 == 0.0f) {
            return 0.0f;
        }
        switch (this.AX) {
            case 0:
            case 1:
                if (f >= f2) {
                    return 0.0f;
                }
                if (f >= 0.0f) {
                    return 1.0f - (f / f2);
                }
                if (this.Bf && this.AX == 1) {
                    return 1.0f;
                }
                return 0.0f;
            case 2:
                if (f < 0.0f) {
                    return f / (-f2);
                }
                return 0.0f;
            default:
                return 0.0f;
        }
    }

    private static float e(float f, float f2, float f3) {
        if (f > f3) {
            return f3;
        }
        if (f < f2) {
            return f2;
        }
        return f;
    }
}
