package android.support.v4.view.a;

import android.os.Bundle;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeProvider;
import java.util.List;

final class d {

    /* renamed from: android.support.v4.view.a.d$1 */
    static class AnonymousClass1 extends AccessibilityNodeProvider {
        final /* synthetic */ a AK;

        AnonymousClass1(a aVar) {
            this.AK = aVar;
        }

        public final AccessibilityNodeInfo createAccessibilityNodeInfo(int i) {
            this.AK.cs();
            return null;
        }

        public final List<AccessibilityNodeInfo> findAccessibilityNodeInfosByText(String str, int i) {
            return this.AK.cq();
        }

        public final boolean performAction(int i, int i2, Bundle bundle) {
            return this.AK.cp();
        }
    }

    interface a {
        boolean cp();

        List<Object> cq();

        Object cs();
    }
}
