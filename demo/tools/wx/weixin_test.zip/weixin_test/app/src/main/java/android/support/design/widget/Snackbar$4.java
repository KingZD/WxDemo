package android.support.design.widget;

class Snackbar$4 implements Snackbar$SnackbarLayout$a {
    final /* synthetic */ Snackbar jH;

    Snackbar$4(Snackbar snackbar) {
        this.jH = snackbar;
    }

    public final void ay() {
        if (q.aA().c(this.jH.jG)) {
            Snackbar.ax().post(new Runnable(this) {
                final /* synthetic */ Snackbar$4 jI;

                {
                    this.jI = r1;
                }

                public final void run() {
                    Snackbar.a(this.jI.jH, 3);
                }
            });
        }
    }
}
