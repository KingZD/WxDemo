package android.support.v4.app;

import android.support.v4.app.ac.a;

interface x {
    void a(a aVar);
}
