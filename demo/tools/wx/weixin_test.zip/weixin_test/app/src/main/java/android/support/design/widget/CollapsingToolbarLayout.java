package android.support.design.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.support.design.a$e;
import android.support.design.a$i;
import android.support.design.a.h;
import android.support.v4.b.a.a;
import android.support.v4.view.ap;
import android.support.v4.view.z;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.ViewParent;
import android.widget.FrameLayout;

public class CollapsingToolbarLayout extends FrameLayout {
    private ap eX;
    private boolean gR;
    private int gS;
    private Toolbar gT;
    private View gU;
    private View gV;
    private int gW;
    private int gX;
    private int gY;
    private int gZ;
    private final Rect ha;
    private final f hb;
    private boolean hc;
    private boolean hd;
    private Drawable he;
    private Drawable hf;
    int hg;
    boolean hh;
    u hi;
    private AppBarLayout$a hj;
    private int hk;

    static /* synthetic */ ap a(CollapsingToolbarLayout collapsingToolbarLayout, ap apVar) {
        if (collapsingToolbarLayout.eX != apVar) {
            collapsingToolbarLayout.eX = apVar;
            collapsingToolbarLayout.requestLayout();
        }
        return apVar.cm();
    }

    protected /* synthetic */ LayoutParams generateDefaultLayoutParams() {
        return ad();
    }

    /* renamed from: generateDefaultLayoutParams */
    protected /* synthetic */ FrameLayout.LayoutParams m4generateDefaultLayoutParams() {
        return ad();
    }

    protected /* synthetic */ LayoutParams generateLayoutParams(LayoutParams layoutParams) {
        return new CollapsingToolbarLayout$LayoutParams(layoutParams);
    }

    public CollapsingToolbarLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public CollapsingToolbarLayout(Context context, AttributeSet attributeSet, int i) {
        Drawable drawable = null;
        super(context, attributeSet, i);
        this.gR = true;
        this.ha = new Rect();
        t.p(context);
        this.hb = new f(this);
        this.hb.b(a.eQ);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, a$i.co, i, h.bT);
        this.hb.x(obtainStyledAttributes.getInt(a$i.cC, 8388691));
        this.hb.y(obtainStyledAttributes.getInt(a$i.cB, 8388627));
        int dimensionPixelSize = obtainStyledAttributes.getDimensionPixelSize(a$i.cq, 0);
        this.gZ = dimensionPixelSize;
        this.gY = dimensionPixelSize;
        this.gX = dimensionPixelSize;
        this.gW = dimensionPixelSize;
        if (obtainStyledAttributes.hasValue(a$i.cs)) {
            this.gW = obtainStyledAttributes.getDimensionPixelSize(a$i.cs, 0);
        }
        if (obtainStyledAttributes.hasValue(a$i.cu)) {
            this.gY = obtainStyledAttributes.getDimensionPixelSize(a$i.cu, 0);
        }
        if (obtainStyledAttributes.hasValue(a$i.ct)) {
            this.gX = obtainStyledAttributes.getDimensionPixelSize(a$i.ct, 0);
        }
        if (obtainStyledAttributes.hasValue(a$i.cv)) {
            this.gZ = obtainStyledAttributes.getDimensionPixelSize(a$i.cv, 0);
        }
        this.hc = obtainStyledAttributes.getBoolean(a$i.cD, true);
        this.hb.setText(obtainStyledAttributes.getText(a$i.cp));
        this.hb.A(h.bP);
        this.hb.z(h.TextAppearance_AppCompat_Widget_ActionBar_Title);
        if (obtainStyledAttributes.hasValue(a$i.cw)) {
            this.hb.A(obtainStyledAttributes.getResourceId(a$i.cw, 0));
        }
        if (obtainStyledAttributes.hasValue(a$i.cx)) {
            this.hb.z(obtainStyledAttributes.getResourceId(a$i.cx, 0));
        }
        Drawable drawable2 = obtainStyledAttributes.getDrawable(a$i.cy);
        if (this.he != drawable2) {
            if (this.he != null) {
                this.he.setCallback(null);
            }
            this.he = drawable2 != null ? drawable2.mutate() : null;
            if (this.he != null) {
                this.he.setBounds(0, 0, getWidth(), getHeight());
                this.he.setCallback(this);
                this.he.setAlpha(this.hg);
            }
            z.E(this);
        }
        drawable2 = obtainStyledAttributes.getDrawable(a$i.cz);
        if (this.hf != drawable2) {
            if (this.hf != null) {
                this.hf.setCallback(null);
            }
            if (drawable2 != null) {
                drawable = drawable2.mutate();
            }
            this.hf = drawable;
            if (this.hf != null) {
                boolean z;
                if (this.hf.isStateful()) {
                    this.hf.setState(getDrawableState());
                }
                a.b(this.hf, z.I(this));
                drawable = this.hf;
                if (getVisibility() == 0) {
                    z = true;
                } else {
                    z = false;
                }
                drawable.setVisible(z, false);
                this.hf.setCallback(this);
                this.hf.setAlpha(this.hg);
            }
            z.E(this);
        }
        this.gS = obtainStyledAttributes.getResourceId(a$i.cA, -1);
        obtainStyledAttributes.recycle();
        setWillNotDraw(false);
        z.b(this, new CollapsingToolbarLayout$1(this));
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        ViewParent parent = getParent();
        if (parent instanceof AppBarLayout) {
            if (this.hj == null) {
                this.hj = new CollapsingToolbarLayout$a(this, (byte) 0);
            }
            AppBarLayout appBarLayout = (AppBarLayout) parent;
            AppBarLayout$a appBarLayout$a = this.hj;
            if (!(appBarLayout$a == null || appBarLayout.eY.contains(appBarLayout$a))) {
                appBarLayout.eY.add(appBarLayout$a);
            }
        }
        z.Y(this);
    }

    protected void onDetachedFromWindow() {
        ViewParent parent = getParent();
        if (this.hj != null && (parent instanceof AppBarLayout)) {
            AppBarLayout appBarLayout = (AppBarLayout) parent;
            AppBarLayout$a appBarLayout$a = this.hj;
            if (appBarLayout$a != null) {
                appBarLayout.eY.remove(appBarLayout$a);
            }
        }
        super.onDetachedFromWindow();
    }

    public void draw(Canvas canvas) {
        super.draw(canvas);
        ac();
        if (this.gT == null && this.he != null && this.hg > 0) {
            this.he.mutate().setAlpha(this.hg);
            this.he.draw(canvas);
        }
        if (this.hc && this.hd) {
            this.hb.draw(canvas);
        }
        if (this.hf != null && this.hg > 0) {
            int systemWindowInsetTop = this.eX != null ? this.eX.getSystemWindowInsetTop() : 0;
            if (systemWindowInsetTop > 0) {
                this.hf.setBounds(0, -this.hk, getWidth(), systemWindowInsetTop - this.hk);
                this.hf.mutate().setAlpha(this.hg);
                this.hf.draw(canvas);
            }
        }
    }

    protected boolean drawChild(Canvas canvas, View view, long j) {
        ac();
        if (view == this.gT && this.he != null && this.hg > 0) {
            this.he.mutate().setAlpha(this.hg);
            this.he.draw(canvas);
        }
        return super.drawChild(canvas, view, j);
    }

    protected void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        if (this.he != null) {
            this.he.setBounds(0, 0, i, i2);
        }
    }

    final void ac() {
        if (this.gR) {
            View view;
            this.gT = null;
            this.gU = null;
            if (this.gS != -1) {
                this.gT = (Toolbar) findViewById(this.gS);
                if (this.gT != null) {
                    view = this.gT;
                    CollapsingToolbarLayout parent = view.getParent();
                    while (parent != this && parent != null) {
                        if (parent instanceof View) {
                            view = parent;
                        }
                        parent = parent.getParent();
                    }
                    this.gU = view;
                }
            }
            if (this.gT == null) {
                Toolbar toolbar;
                int childCount = getChildCount();
                for (int i = 0; i < childCount; i++) {
                    view = getChildAt(i);
                    if (view instanceof Toolbar) {
                        toolbar = (Toolbar) view;
                        break;
                    }
                }
                toolbar = null;
                this.gT = toolbar;
            }
            if (!(this.hc || this.gV == null)) {
                ViewParent parent2 = this.gV.getParent();
                if (parent2 instanceof ViewGroup) {
                    ((ViewGroup) parent2).removeView(this.gV);
                }
            }
            if (this.hc && this.gT != null) {
                if (this.gV == null) {
                    this.gV = new View(getContext());
                }
                if (this.gV.getParent() == null) {
                    this.gT.addView(this.gV, -1, -1);
                }
            }
            this.gR = false;
        }
    }

    protected void onMeasure(int i, int i2) {
        ac();
        super.onMeasure(i, i2);
    }

    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int i5;
        int i6 = 1;
        int i7 = 0;
        super.onLayout(z, i, i2, i3, i4);
        if (this.hc && this.gV != null) {
            boolean z2 = z.ak(this.gV) && this.gV.getVisibility() == 0;
            this.hd = z2;
            if (this.hd) {
                if (this.gU == null || this.gU == this) {
                    i5 = 0;
                } else {
                    i5 = ((CollapsingToolbarLayout$LayoutParams) this.gU.getLayoutParams()).bottomMargin;
                }
                x.a(this, this.gV, this.ha);
                this.hb.c(this.ha.left, (i4 - this.ha.height()) - i5, this.ha.right, i4 - i5);
                if (z.I(this) != 1) {
                    i6 = 0;
                }
                f fVar = this.hb;
                i5 = i6 != 0 ? this.gY : this.gW;
                int i8 = this.ha.bottom + this.gX;
                int i9 = i3 - i;
                if (i6 != 0) {
                    i6 = this.gW;
                } else {
                    i6 = this.gY;
                }
                fVar.b(i5, i8, i9 - i6, (i4 - i2) - this.gZ);
                this.hb.aa();
            }
        }
        i5 = getChildCount();
        while (i7 < i5) {
            View childAt = getChildAt(i7);
            if (!(this.eX == null || z.Z(childAt))) {
                int systemWindowInsetTop = this.eX.getSystemWindowInsetTop();
                if (childAt.getTop() < systemWindowInsetTop) {
                    z.j(childAt, systemWindowInsetTop);
                }
            }
            k(childAt).aM();
            i7++;
        }
        if (this.gT != null) {
            if (this.hc && TextUtils.isEmpty(this.hb.mText)) {
                this.hb.setText(this.gT.ZW);
            }
            if (this.gU == null || this.gU == this) {
                setMinimumHeight(j(this.gT));
            } else {
                setMinimumHeight(j(this.gU));
            }
        }
    }

    private static int j(View view) {
        LayoutParams layoutParams = view.getLayoutParams();
        if (!(layoutParams instanceof MarginLayoutParams)) {
            return view.getHeight();
        }
        MarginLayoutParams marginLayoutParams = (MarginLayoutParams) layoutParams;
        return marginLayoutParams.bottomMargin + (view.getHeight() + marginLayoutParams.topMargin);
    }

    private static z k(View view) {
        z zVar = (z) view.getTag(a$e.bD);
        if (zVar != null) {
            return zVar;
        }
        zVar = new z(view);
        view.setTag(a$e.bD, zVar);
        return zVar;
    }

    final void C(int i) {
        if (i != this.hg) {
            if (!(this.he == null || this.gT == null)) {
                z.E(this.gT);
            }
            this.hg = i;
            z.E(this);
        }
    }

    protected void drawableStateChanged() {
        super.drawableStateChanged();
        int[] drawableState = getDrawableState();
        int i = 0;
        Drawable drawable = this.hf;
        if (drawable != null && drawable.isStateful()) {
            i = drawable.setState(drawableState) | 0;
        }
        drawable = this.he;
        if (drawable != null && drawable.isStateful()) {
            i |= drawable.setState(drawableState);
        }
        if (i != 0) {
            invalidate();
        }
    }

    protected boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.he || drawable == this.hf;
    }

    public void setVisibility(int i) {
        super.setVisibility(i);
        boolean z = i == 0;
        if (!(this.hf == null || this.hf.isVisible() == z)) {
            this.hf.setVisible(z, false);
        }
        if (this.he != null && this.he.isVisible() != z) {
            this.he.setVisible(z, false);
        }
    }

    protected boolean checkLayoutParams(LayoutParams layoutParams) {
        return layoutParams instanceof CollapsingToolbarLayout$LayoutParams;
    }

    private CollapsingToolbarLayout$LayoutParams ad() {
        return new CollapsingToolbarLayout$LayoutParams(super.generateDefaultLayoutParams());
    }

    public FrameLayout.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new CollapsingToolbarLayout$LayoutParams(getContext(), attributeSet);
    }
}
