package android.support.b;

class a$e {
    public final long oL;
    public final long oM;

    private a$e(long j, long j2) {
        if (j2 == 0) {
            this.oL = 0;
            this.oM = 1;
            return;
        }
        this.oL = j;
        this.oM = j2;
    }

    public final String toString() {
        return this.oL + "/" + this.oM;
    }
}
