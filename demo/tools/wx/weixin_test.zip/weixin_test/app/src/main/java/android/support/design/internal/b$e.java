package android.support.design.internal;

import android.support.design.internal.b.d;

class b$e implements d {
    final int eF;
    final int eG;

    public b$e(int i, int i2) {
        this.eF = i;
        this.eG = i2;
    }
}
