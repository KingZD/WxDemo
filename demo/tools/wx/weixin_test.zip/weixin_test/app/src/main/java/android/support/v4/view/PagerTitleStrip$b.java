package android.support.v4.view;

import android.widget.TextView;

interface PagerTitleStrip$b {
    void b(TextView textView);
}
