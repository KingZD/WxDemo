package android.support.design.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;

class k$2 extends AnimatorListenerAdapter {
    final /* synthetic */ boolean iB;
    final /* synthetic */ l$a iC;
    final /* synthetic */ k iH;

    k$2(k kVar, boolean z, l$a l_a) {
        this.iH = kVar;
        this.iB = z;
        this.iC = l_a;
    }

    public final void onAnimationStart(Animator animator) {
        this.iH.iP.i(0, this.iB);
    }

    public final void onAnimationEnd(Animator animator) {
    }
}
