package android.support.v4.widget;

import android.graphics.drawable.Drawable;
import android.widget.CompoundButton;
import java.lang.reflect.Field;

final class d {
    private static Field BB;
    private static boolean BC;

    static Drawable a(CompoundButton compoundButton) {
        if (!BC) {
            try {
                Field declaredField = CompoundButton.class.getDeclaredField("mButtonDrawable");
                BB = declaredField;
                declaredField.setAccessible(true);
            } catch (NoSuchFieldException e) {
            }
            BC = true;
        }
        if (BB != null) {
            try {
                return (Drawable) BB.get(compoundButton);
            } catch (IllegalAccessException e2) {
                BB = null;
            }
        }
        return null;
    }
}
