package android.support.v4.app;

public abstract class q {
    public abstract q a(int i, Fragment fragment);

    public abstract q a(int i, Fragment fragment, String str);

    public abstract q a(Fragment fragment);

    public abstract q a(Fragment fragment, String str);

    public abstract q b(int i, Fragment fragment);

    public abstract q b(Fragment fragment);

    public abstract q c(Fragment fragment);

    public abstract int commit();

    public abstract int commitAllowingStateLoss();

    public abstract q d(Fragment fragment);

    public abstract q l(int i, int i2);

    public abstract q p(String str);
}
