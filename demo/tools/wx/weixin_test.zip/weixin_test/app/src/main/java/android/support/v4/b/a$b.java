package android.support.v4.b;

import android.graphics.Bitmap;

interface a$b {
    int e(Bitmap bitmap);
}
