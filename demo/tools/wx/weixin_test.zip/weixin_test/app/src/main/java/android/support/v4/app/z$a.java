package android.support.v4.app;

import android.app.PendingIntent;
import android.os.Bundle;
import android.support.v4.app.ac.a;

public class z$a extends a {
    public static final ac$a$a sd = new ac$a$a() {
    };
    public PendingIntent actionIntent;
    public int icon;
    private final Bundle mExtras;
    private final ah[] sc;
    public CharSequence title;

    public final /* bridge */ /* synthetic */ aj.a[] bu() {
        return this.sc;
    }

    public z$a(int i, CharSequence charSequence, PendingIntent pendingIntent) {
        this(i, charSequence, pendingIntent, new Bundle());
    }

    private z$a(int i, CharSequence charSequence, PendingIntent pendingIntent, Bundle bundle) {
        this.icon = i;
        this.title = z$d.d(charSequence);
        this.actionIntent = pendingIntent;
        this.mExtras = bundle;
        this.sc = null;
    }

    public final int getIcon() {
        return this.icon;
    }

    public final CharSequence getTitle() {
        return this.title;
    }

    public final PendingIntent bt() {
        return this.actionIntent;
    }

    public final Bundle getExtras() {
        return this.mExtras;
    }
}
