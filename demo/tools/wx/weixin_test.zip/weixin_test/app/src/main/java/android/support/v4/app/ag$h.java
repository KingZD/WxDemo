package android.support.v4.app;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.ResolveInfo;
import android.os.DeadObjectException;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Message;
import android.os.RemoteException;
import android.support.v4.app.ag.g;
import android.util.Log;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

class ag$h implements ServiceConnection, Callback {
    private final Context mContext;
    final Handler mHandler;
    private final HandlerThread mHandlerThread;
    private final Map<ComponentName, ag$h$a> to = new HashMap();
    private Set<String> tp = new HashSet();

    public ag$h(Context context) {
        this.mContext = context;
        this.mHandlerThread = new HandlerThread("NotificationManagerCompat");
        this.mHandlerThread.start();
        this.mHandler = new Handler(this.mHandlerThread.getLooper(), this);
    }

    public final boolean handleMessage(Message message) {
        ag$h$a ag_h_a;
        switch (message.what) {
            case 0:
                Iterator it;
                ag$i ag_i = (ag$i) message.obj;
                Set v = ag.v(this.mContext);
                if (!v.equals(this.tp)) {
                    this.tp = v;
                    List<ResolveInfo> queryIntentServices = this.mContext.getPackageManager().queryIntentServices(new Intent().setAction("android.support.BIND_NOTIFICATION_SIDE_CHANNEL"), 4);
                    Set<ComponentName> hashSet = new HashSet();
                    for (ResolveInfo resolveInfo : queryIntentServices) {
                        if (v.contains(resolveInfo.serviceInfo.packageName)) {
                            ComponentName componentName = new ComponentName(resolveInfo.serviceInfo.packageName, resolveInfo.serviceInfo.name);
                            if (resolveInfo.serviceInfo.permission != null) {
                                new StringBuilder("Permission present on component ").append(componentName).append(", not adding listener record.");
                            } else {
                                hashSet.add(componentName);
                            }
                        }
                    }
                    for (ComponentName componentName2 : hashSet) {
                        if (!this.to.containsKey(componentName2)) {
                            if (Log.isLoggable("NotifManCompat", 3)) {
                                new StringBuilder("Adding listener record for ").append(componentName2);
                            }
                            this.to.put(componentName2, new ag$h$a(componentName2));
                        }
                    }
                    it = this.to.entrySet().iterator();
                    while (it.hasNext()) {
                        Entry entry = (Entry) it.next();
                        if (!hashSet.contains(entry.getKey())) {
                            if (Log.isLoggable("NotifManCompat", 3)) {
                                new StringBuilder("Removing listener record for ").append(entry.getKey());
                            }
                            a((ag$h$a) entry.getValue());
                            it.remove();
                        }
                    }
                }
                for (ag$h$a ag_h_a2 : this.to.values()) {
                    ag_h_a2.tt.add(ag_i);
                    c(ag_h_a2);
                }
                return true;
            case 1:
                g gVar = (g) message.obj;
                ComponentName componentName3 = gVar.tm;
                IBinder iBinder = gVar.tn;
                ag_h_a = (ag$h$a) this.to.get(componentName3);
                if (ag_h_a != null) {
                    ag_h_a.tr = s$a.a(iBinder);
                    ag_h_a.retryCount = 0;
                    c(ag_h_a);
                }
                return true;
            case 2:
                ag_h_a = (ag$h$a) this.to.get((ComponentName) message.obj);
                if (ag_h_a != null) {
                    a(ag_h_a);
                }
                return true;
            case 3:
                ag_h_a = (ag$h$a) this.to.get((ComponentName) message.obj);
                if (ag_h_a != null) {
                    c(ag_h_a);
                }
                return true;
            default:
                return false;
        }
    }

    public final void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        if (Log.isLoggable("NotifManCompat", 3)) {
            new StringBuilder("Connected to service ").append(componentName);
        }
        this.mHandler.obtainMessage(1, new g(componentName, iBinder)).sendToTarget();
    }

    public final void onServiceDisconnected(ComponentName componentName) {
        if (Log.isLoggable("NotifManCompat", 3)) {
            new StringBuilder("Disconnected from service ").append(componentName);
        }
        this.mHandler.obtainMessage(2, componentName).sendToTarget();
    }

    private void a(ag$h$a ag_h_a) {
        if (ag_h_a.tq) {
            this.mContext.unbindService(this);
            ag_h_a.tq = false;
        }
        ag_h_a.tr = null;
    }

    private void b(ag$h$a ag_h_a) {
        if (!this.mHandler.hasMessages(3, ag_h_a.tm)) {
            ag_h_a.retryCount++;
            if (ag_h_a.retryCount > 6) {
                new StringBuilder("Giving up on delivering ").append(ag_h_a.tt.size()).append(" tasks to ").append(ag_h_a.tm).append(" after ").append(ag_h_a.retryCount).append(" retries");
                ag_h_a.tt.clear();
                return;
            }
            int i = (1 << (ag_h_a.retryCount - 1)) * 1000;
            if (Log.isLoggable("NotifManCompat", 3)) {
                new StringBuilder("Scheduling retry for ").append(i).append(" ms");
            }
            this.mHandler.sendMessageDelayed(this.mHandler.obtainMessage(3, ag_h_a.tm), (long) i);
        }
    }

    private void c(ag$h$a ag_h_a) {
        if (Log.isLoggable("NotifManCompat", 3)) {
            new StringBuilder("Processing component ").append(ag_h_a.tm).append(", ").append(ag_h_a.tt.size()).append(" queued tasks");
        }
        if (!ag_h_a.tt.isEmpty()) {
            boolean z;
            if (ag_h_a.tq) {
                z = true;
            } else {
                ag_h_a.tq = this.mContext.bindService(new Intent("android.support.BIND_NOTIFICATION_SIDE_CHANNEL").setComponent(ag_h_a.tm), this, ag.bw());
                if (ag_h_a.tq) {
                    ag_h_a.retryCount = 0;
                } else {
                    new StringBuilder("Unable to bind to listener ").append(ag_h_a.tm);
                    this.mContext.unbindService(this);
                }
                z = ag_h_a.tq;
            }
            if (!z || ag_h_a.tr == null) {
                b(ag_h_a);
                return;
            }
            while (true) {
                ag$i ag_i = (ag$i) ag_h_a.tt.peek();
                if (ag_i == null) {
                    break;
                }
                try {
                    if (Log.isLoggable("NotifManCompat", 3)) {
                        new StringBuilder("Sending task ").append(ag_i);
                    }
                    ag_i.a(ag_h_a.tr);
                    ag_h_a.tt.remove();
                } catch (DeadObjectException e) {
                    if (Log.isLoggable("NotifManCompat", 3)) {
                        new StringBuilder("Remote service has died: ").append(ag_h_a.tm);
                    }
                } catch (RemoteException e2) {
                    new StringBuilder("RemoteException communicating with ").append(ag_h_a.tm);
                }
            }
            if (!ag_h_a.tt.isEmpty()) {
                b(ag_h_a);
            }
        }
    }
}
