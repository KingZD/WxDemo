package android.support.design.widget;

import android.os.Build.VERSION;
import android.os.Handler.Callback;
import android.os.Message;
import android.support.design.a$a;
import android.support.design.widget.CoordinatorLayout.Behavior;
import android.support.design.widget.Snackbar.AnonymousClass5;
import android.support.v4.view.z;
import android.view.ViewGroup.LayoutParams;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

class Snackbar$1 implements Callback {
    Snackbar$1() {
    }

    public final boolean handleMessage(Message message) {
        Snackbar snackbar;
        switch (message.what) {
            case 0:
                snackbar = (Snackbar) message.obj;
                if (snackbar.jE.getParent() == null) {
                    LayoutParams layoutParams = snackbar.jE.getLayoutParams();
                    if (layoutParams instanceof CoordinatorLayout$d) {
                        Behavior snackbar$a = new Snackbar$a(snackbar);
                        snackbar$a.ke = s.c(0.0f, 0.1f, 1.0f);
                        snackbar$a.kf = s.c(0.0f, 0.6f, 1.0f);
                        snackbar$a.kc = 0;
                        snackbar$a.jZ = new Snackbar$3(snackbar);
                        ((CoordinatorLayout$d) layoutParams).a(snackbar$a);
                    }
                    snackbar.jD.addView(snackbar.jE);
                }
                snackbar.jE.jN = new Snackbar$4(snackbar);
                if (!z.ai(snackbar.jE)) {
                    snackbar.jE.jM = new AnonymousClass5(snackbar);
                } else if (snackbar.aw()) {
                    snackbar.at();
                } else {
                    snackbar.au();
                }
                return true;
            case 1:
                snackbar = (Snackbar) message.obj;
                int i = message.arg1;
                if (!snackbar.aw() || snackbar.jE.getVisibility() != 0) {
                    snackbar.av();
                } else if (VERSION.SDK_INT >= 14) {
                    z.U(snackbar.jE).u((float) snackbar.jE.getHeight()).c(a.eN).h(250).a(new Snackbar$8(snackbar, i)).start();
                } else {
                    Animation loadAnimation = AnimationUtils.loadAnimation(snackbar.jE.getContext(), a$a.bd);
                    loadAnimation.setInterpolator(a.eN);
                    loadAnimation.setDuration(250);
                    loadAnimation.setAnimationListener(new Snackbar$2(snackbar, i));
                    snackbar.jE.startAnimation(loadAnimation);
                }
                return true;
            default:
                return false;
        }
    }
}
