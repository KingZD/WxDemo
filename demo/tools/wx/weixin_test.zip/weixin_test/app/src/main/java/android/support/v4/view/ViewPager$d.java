package android.support.v4.view;

interface ViewPager$d {
    void b(u uVar, u uVar2);
}
