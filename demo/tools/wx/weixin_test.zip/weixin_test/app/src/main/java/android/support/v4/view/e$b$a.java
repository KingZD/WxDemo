package android.support.v4.view;

import android.os.Handler;
import android.os.Message;

class e$b$a extends Handler {
    final /* synthetic */ e$b xt;

    e$b$a(e$b e_b) {
        this.xt = e_b;
    }

    public final void handleMessage(Message message) {
        switch (message.what) {
            case 1:
                e$b.b(this.xt).onShowPress(e$b.a(this.xt));
                return;
            case 2:
                e$b.c(this.xt);
                return;
            case 3:
                if (e$b.d(this.xt) == null) {
                    return;
                }
                if (e$b.e(this.xt)) {
                    e$b.f(this.xt);
                    return;
                } else {
                    e$b.d(this.xt).onSingleTapConfirmed(e$b.a(this.xt));
                    return;
                }
            default:
                throw new RuntimeException("Unknown message " + message);
        }
    }
}
