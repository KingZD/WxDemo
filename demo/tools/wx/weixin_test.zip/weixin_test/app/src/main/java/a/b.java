package a;

public final class b extends RuntimeException {
    public b(Throwable th) {
        super(th);
    }
}
