package android.support.design.widget;

import android.view.View;
import java.util.Comparator;

class CoordinatorLayout$1 implements Comparator<View> {
    final /* synthetic */ CoordinatorLayout hN;

    CoordinatorLayout$1(CoordinatorLayout coordinatorLayout) {
        this.hN = coordinatorLayout;
    }

    public final /* synthetic */ int compare(Object obj, Object obj2) {
        View view = (View) obj;
        View view2 = (View) obj2;
        if (view != view2) {
            if (((CoordinatorLayout$d) view.getLayoutParams()).c(this.hN, view, view2)) {
                return 1;
            }
            if (((CoordinatorLayout$d) view2.getLayoutParams()).c(this.hN, view2, view)) {
                return -1;
            }
        }
        return 0;
    }
}
