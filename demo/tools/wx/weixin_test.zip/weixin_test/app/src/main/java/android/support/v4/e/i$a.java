package android.support.v4.e;

public interface i$a<T> {
    T bR();

    boolean j(T t);
}
