package android.support.v4.widget;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Path;
import android.graphics.Path.FillType;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.Callback;
import android.support.v4.view.b.b;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import com.tencent.smtt.sdk.WebView;
import java.util.ArrayList;

final class l extends Drawable implements Animatable {
    private static final Interpolator CN = new b();
    private static final Interpolator eM = new LinearInterpolator();
    private final int[] CO = new int[]{WebView.NIGHT_MODE_COLOR};
    final l$a CP;
    private View CQ;
    private float CR;
    private double CS;
    private double CT;
    boolean CU;
    private float fZ;
    private Animation mAnimation;
    private Resources mResources;
    private final Callback mn = new l$3(this);
    private final ArrayList<Animation> mr = new ArrayList();

    static /* synthetic */ void a(l lVar, float f, l$a l_a) {
        a(f, l_a);
        float floor = (float) (Math.floor((double) (l_a.Dg / 0.8f)) + 1.0d);
        float a = a(l_a);
        l_a.C((((l_a.Df - a) - l_a.De) * f) + l_a.De);
        l_a.D(l_a.Df);
        l_a.setRotation(((floor - l_a.Dg) * f) + l_a.Dg);
    }

    public l(Context context, View view) {
        this.CQ = view;
        this.mResources = context.getResources();
        this.CP = new l$a(this.mn);
        l$a l_a = this.CP;
        l_a.Dc = this.CO;
        l_a.ar(0);
        l$a l_a2 = this.CP;
        float f = this.mResources.getDisplayMetrics().density;
        this.CS = ((double) f) * 40.0d;
        this.CT = ((double) f) * 40.0d;
        float f2 = 2.5f * f;
        l_a2.mL = f2;
        l_a2.fO.setStrokeWidth(f2);
        l_a2.invalidateSelf();
        l_a2.Dk = 8.75d * ((double) f);
        l_a2.ar(0);
        f2 = 10.0f * f;
        f *= 5.0f;
        l_a2.Dl = (int) f2;
        l_a2.Dm = (int) f;
        f = (float) Math.min((int) this.CS, (int) this.CT);
        f = (l_a2.Dk <= 0.0d || f < 0.0f) ? (float) Math.ceil((double) (l_a2.mL / 2.0f)) : (float) (((double) (f / 2.0f)) - l_a2.Dk);
        l_a2.Db = f;
        l_a = this.CP;
        Animation l_1 = new l$1(this, l_a);
        l_1.setRepeatCount(-1);
        l_1.setRepeatMode(1);
        l_1.setInterpolator(eM);
        l_1.setAnimationListener(new l$2(this, l_a));
        this.mAnimation = l_1;
    }

    public final void B(boolean z) {
        this.CP.C(z);
    }

    public final void A(float f) {
        l$a l_a = this.CP;
        if (f != l_a.Dj) {
            l_a.Dj = f;
            l_a.invalidateSelf();
        }
    }

    public final void B(float f) {
        this.CP.C(0.0f);
        this.CP.D(f);
    }

    public final int getIntrinsicHeight() {
        return (int) this.CT;
    }

    public final int getIntrinsicWidth() {
        return (int) this.CS;
    }

    public final void draw(Canvas canvas) {
        Rect bounds = getBounds();
        int save = canvas.save();
        canvas.rotate(this.fZ, bounds.exactCenterX(), bounds.exactCenterY());
        l$a l_a = this.CP;
        RectF rectF = l_a.CX;
        rectF.set(bounds);
        rectF.inset(l_a.Db, l_a.Db);
        float f = 360.0f * (l_a.CZ + l_a.fZ);
        float f2 = ((l_a.Da + l_a.fZ) * 360.0f) - f;
        l_a.fO.setColor(l_a.ul);
        canvas.drawArc(rectF, f, f2, false, l_a.fO);
        if (l_a.Dh) {
            if (l_a.Di == null) {
                l_a.Di = new Path();
                l_a.Di.setFillType(FillType.EVEN_ODD);
            } else {
                l_a.Di.reset();
            }
            float f3 = ((float) (((int) l_a.Db) / 2)) * l_a.Dj;
            float cos = (float) ((l_a.Dk * Math.cos(0.0d)) + ((double) bounds.exactCenterX()));
            float sin = (float) ((l_a.Dk * Math.sin(0.0d)) + ((double) bounds.exactCenterY()));
            l_a.Di.moveTo(0.0f, 0.0f);
            l_a.Di.lineTo(((float) l_a.Dl) * l_a.Dj, 0.0f);
            l_a.Di.lineTo((((float) l_a.Dl) * l_a.Dj) / 2.0f, ((float) l_a.Dm) * l_a.Dj);
            l_a.Di.offset(cos - f3, sin);
            l_a.Di.close();
            l_a.CY.setColor(l_a.ul);
            canvas.rotate((f + f2) - 5.0f, bounds.exactCenterX(), bounds.exactCenterY());
            canvas.drawPath(l_a.Di, l_a.CY);
        }
        if (l_a.Dn < 255) {
            l_a.Do.setColor(l_a.Dp);
            l_a.Do.setAlpha(255 - l_a.Dn);
            canvas.drawCircle(bounds.exactCenterX(), bounds.exactCenterY(), (float) (bounds.width() / 2), l_a.Do);
        }
        canvas.restoreToCount(save);
    }

    public final void setAlpha(int i) {
        this.CP.Dn = i;
    }

    public final int getAlpha() {
        return this.CP.Dn;
    }

    public final void setColorFilter(ColorFilter colorFilter) {
        l$a l_a = this.CP;
        l_a.fO.setColorFilter(colorFilter);
        l_a.invalidateSelf();
    }

    final void setRotation(float f) {
        this.fZ = f;
        invalidateSelf();
    }

    public final int getOpacity() {
        return -3;
    }

    public final boolean isRunning() {
        ArrayList arrayList = this.mr;
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            Animation animation = (Animation) arrayList.get(i);
            if (animation.hasStarted() && !animation.hasEnded()) {
                return true;
            }
        }
        return false;
    }

    public final void start() {
        this.mAnimation.reset();
        this.CP.cJ();
        if (this.CP.Da != this.CP.CZ) {
            this.CU = true;
            this.mAnimation.setDuration(666);
            this.CQ.startAnimation(this.mAnimation);
            return;
        }
        this.CP.ar(0);
        this.CP.cK();
        this.mAnimation.setDuration(1332);
        this.CQ.startAnimation(this.mAnimation);
    }

    public final void stop() {
        this.CQ.clearAnimation();
        setRotation(0.0f);
        this.CP.C(false);
        this.CP.ar(0);
        this.CP.cK();
    }

    private static float a(l$a l_a) {
        return (float) Math.toRadians(((double) l_a.mL) / (6.283185307179586d * l_a.Dk));
    }

    private static void a(float f, l$a l_a) {
        if (f > 0.75f) {
            float f2 = (f - 0.75f) / 0.25f;
            int i = l_a.Dc[l_a.Dd];
            int i2 = l_a.Dc[l_a.cI()];
            i = Integer.valueOf(i).intValue();
            int i3 = (i >> 24) & 255;
            int i4 = (i >> 16) & 255;
            int i5 = (i >> 8) & 255;
            i &= 255;
            i2 = Integer.valueOf(i2).intValue();
            l_a.ul = (((int) (f2 * ((float) ((i2 & 255) - i)))) + i) | ((((i3 + ((int) (((float) (((i2 >> 24) & 255) - i3)) * f2))) << 24) | ((i4 + ((int) (((float) (((i2 >> 16) & 255) - i4)) * f2))) << 16)) | ((((int) (((float) (((i2 >> 8) & 255) - i5)) * f2)) + i5) << 8));
        }
    }
}
