package android.support.v4.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v4.app.z.e;
import android.widget.RemoteViews;
import java.util.ArrayList;

public class z$d {
    public Context mContext;
    Bundle mExtras;
    int mPriority;
    public ArrayList<z$a> sA = new ArrayList();
    public boolean sB = false;
    public String sC;
    int sD = 0;
    int sE = 0;
    Notification sF;
    public Notification sG = new Notification();
    public ArrayList<String> sH;
    public CharSequence si;
    public CharSequence sj;
    public PendingIntent sk;
    PendingIntent sl;
    RemoteViews sm;
    public Bitmap sn;
    public CharSequence so;
    public int sp;
    boolean sq = true;
    public boolean sr;
    public z$r ss;
    public CharSequence st;
    int su;
    int sv;
    boolean sw;
    String sx;
    boolean sy;
    String sz;

    public z$d(Context context) {
        this.mContext = context;
        this.sG.when = System.currentTimeMillis();
        this.sG.audioStreamType = -1;
        this.mPriority = 0;
        this.sH = new ArrayList();
    }

    public final z$d g(long j) {
        this.sG.when = j;
        return this;
    }

    public final z$d V(int i) {
        this.sG.icon = i;
        return this;
    }

    public final z$d a(CharSequence charSequence) {
        this.si = d(charSequence);
        return this;
    }

    public final z$d b(CharSequence charSequence) {
        this.sj = d(charSequence);
        return this;
    }

    public final z$d b(int i, int i2, boolean z) {
        this.su = i;
        this.sv = i2;
        this.sw = z;
        return this;
    }

    public final z$d c(CharSequence charSequence) {
        this.sG.tickerText = d(charSequence);
        return this;
    }

    public final z$d v(boolean z) {
        j(16, z);
        return this;
    }

    public final void j(int i, boolean z) {
        if (z) {
            Notification notification = this.sG;
            notification.flags |= i;
            return;
        }
        notification = this.sG;
        notification.flags &= i ^ -1;
    }

    public final z$d a(int i, CharSequence charSequence, PendingIntent pendingIntent) {
        this.sA.add(new z$a(i, charSequence, pendingIntent));
        return this;
    }

    @Deprecated
    public final Notification getNotification() {
        return build();
    }

    public final Notification build() {
        z$i bs = z.bs();
        e eVar = new e();
        return bs.b(this);
    }

    protected static CharSequence d(CharSequence charSequence) {
        if (charSequence != null && charSequence.length() > 5120) {
            return charSequence.subSequence(0, 5120);
        }
        return charSequence;
    }
}
