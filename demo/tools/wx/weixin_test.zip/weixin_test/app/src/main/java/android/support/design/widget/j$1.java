package android.support.design.widget;

class j$1 extends b {
    final /* synthetic */ boolean iB;
    final /* synthetic */ l$a iC;
    final /* synthetic */ j iD;

    j$1(j jVar, boolean z, l$a l_a) {
        this.iD = jVar;
        this.iB = z;
        this.iC = l_a;
    }
}
