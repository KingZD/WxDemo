package android.support.design.widget;

import android.support.design.widget.AppBarLayout.Behavior;

class AppBarLayout$Behavior$1 implements u$c {
    final /* synthetic */ CoordinatorLayout fj;
    final /* synthetic */ AppBarLayout fk;
    final /* synthetic */ Behavior fl;

    AppBarLayout$Behavior$1(Behavior behavior, CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout) {
        this.fl = behavior;
        this.fj = coordinatorLayout;
        this.fk = appBarLayout;
    }

    public final void a(u uVar) {
        this.fl.c(this.fj, this.fk, uVar.lD.aK());
    }
}
