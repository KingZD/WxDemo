package android.support.design.internal;

import android.support.v7.view.menu.h;
import android.view.View;
import android.view.View.OnClickListener;

class b$1 implements OnClickListener {
    final /* synthetic */ b eA;

    b$1(b bVar) {
        this.eA = bVar;
    }

    public final void onClick(View view) {
        NavigationMenuItemView navigationMenuItemView = (NavigationMenuItemView) view;
        this.eA.o(true);
        h hVar = navigationMenuItemView.en;
        boolean a = this.eA.es.a(hVar, this.eA, 0);
        if (hVar != null && hVar.isCheckable() && a) {
            this.eA.et.d(hVar);
        }
        this.eA.o(false);
        this.eA.n(false);
    }
}
