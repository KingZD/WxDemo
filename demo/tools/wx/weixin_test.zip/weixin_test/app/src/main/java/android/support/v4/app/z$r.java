package android.support.v4.app;

public abstract class z$r {
    CharSequence sT;
    CharSequence sU;
    boolean sV = false;
}
