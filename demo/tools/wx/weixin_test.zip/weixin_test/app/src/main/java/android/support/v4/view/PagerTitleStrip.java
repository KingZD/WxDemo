package android.support.v4.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.text.TextUtils.TruncateAt;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.TextView;
import com.tencent.mm.plugin.gif.MMGIFException;
import java.lang.ref.WeakReference;

public class PagerTitleStrip extends ViewGroup implements ViewPager$a {
    private static final int[] yo = new int[]{16842804, 16842901, 16842904, 16842927};
    private static final int[] yp = new int[]{16843660};
    private static final PagerTitleStrip$b ys;
    private int ut;
    ViewPager yd;
    TextView ye;
    TextView yf;
    TextView yg;
    private int yh = -1;
    private float yi = -1.0f;
    int yj;
    private boolean yk;
    private boolean yl;
    private final a ym = new a();
    private WeakReference<u> yn;
    private int yq;
    int yr;

    private class a extends DataSetObserver implements ViewPager$d, ViewPager$e {
        private int yt;
        final /* synthetic */ PagerTitleStrip yu;

        private a(PagerTitleStrip pagerTitleStrip) {
            this.yu = pagerTitleStrip;
        }

        public final void a(int i, float f, int i2) {
            if (f > 0.5f) {
                i++;
            }
            this.yu.a(i, f, false);
        }

        public final void af(int i) {
            float f = 0.0f;
            if (this.yt == 0) {
                this.yu.a(this.yu.yd.yQ, this.yu.yd.yP);
                if (this.yu.yi >= 0.0f) {
                    f = this.yu.yi;
                }
                this.yu.a(this.yu.yd.yQ, f, true);
            }
        }

        public final void ag(int i) {
            this.yt = i;
        }

        public final void b(u uVar, u uVar2) {
            this.yu.a(uVar, uVar2);
        }

        public final void onChanged() {
            float f = 0.0f;
            this.yu.a(this.yu.yd.yQ, this.yu.yd.yP);
            if (this.yu.yi >= 0.0f) {
                f = this.yu.yi;
            }
            this.yu.a(this.yu.yd.yQ, f, true);
        }
    }

    static {
        if (VERSION.SDK_INT >= 14) {
            ys = new PagerTitleStrip$d();
        } else {
            ys = new PagerTitleStrip$c();
        }
    }

    private static void b(TextView textView) {
        ys.b(textView);
    }

    public PagerTitleStrip(Context context, AttributeSet attributeSet) {
        boolean z = false;
        super(context, attributeSet);
        View textView = new TextView(context);
        this.ye = textView;
        addView(textView);
        textView = new TextView(context);
        this.yf = textView;
        addView(textView);
        textView = new TextView(context);
        this.yg = textView;
        addView(textView);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, yo);
        int resourceId = obtainStyledAttributes.getResourceId(0, 0);
        if (resourceId != 0) {
            this.ye.setTextAppearance(context, resourceId);
            this.yf.setTextAppearance(context, resourceId);
            this.yg.setTextAppearance(context, resourceId);
        }
        int dimensionPixelSize = obtainStyledAttributes.getDimensionPixelSize(1, 0);
        if (dimensionPixelSize != 0) {
            float f = (float) dimensionPixelSize;
            this.ye.setTextSize(0, f);
            this.yf.setTextSize(0, f);
            this.yg.setTextSize(0, f);
        }
        if (obtainStyledAttributes.hasValue(2)) {
            dimensionPixelSize = obtainStyledAttributes.getColor(2, 0);
            this.ye.setTextColor(dimensionPixelSize);
            this.yf.setTextColor(dimensionPixelSize);
            this.yg.setTextColor(dimensionPixelSize);
        }
        this.ut = obtainStyledAttributes.getInteger(3, 80);
        obtainStyledAttributes.recycle();
        this.yr = this.yf.getTextColors().getDefaultColor();
        this.yq = 153;
        int i = (this.yq << 24) | (this.yr & 16777215);
        this.ye.setTextColor(i);
        this.yg.setTextColor(i);
        this.ye.setEllipsize(TruncateAt.END);
        this.yf.setEllipsize(TruncateAt.END);
        this.yg.setEllipsize(TruncateAt.END);
        if (resourceId != 0) {
            obtainStyledAttributes = context.obtainStyledAttributes(resourceId, yp);
            z = obtainStyledAttributes.getBoolean(0, false);
            obtainStyledAttributes.recycle();
        }
        if (z) {
            b(this.ye);
            b(this.yf);
            b(this.yg);
        } else {
            this.ye.setSingleLine();
            this.yf.setSingleLine();
            this.yg.setSingleLine();
        }
        this.yj = (int) (context.getResources().getDisplayMetrics().density * 16.0f);
    }

    public void ae(int i) {
        this.yj = i;
        requestLayout();
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        ViewParent parent = getParent();
        if (parent instanceof ViewPager) {
            ViewPager viewPager = (ViewPager) parent;
            u uVar = viewPager.yP;
            viewPager.a(this.ym);
            viewPager.zC = this.ym;
            this.yd = viewPager;
            a(this.yn != null ? (u) this.yn.get() : null, uVar);
            return;
        }
        throw new IllegalStateException("PagerTitleStrip must be a direct child of a ViewPager.");
    }

    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (this.yd != null) {
            a(this.yd.yP, null);
            this.yd.a(null);
            this.yd.zC = null;
            this.yd = null;
        }
    }

    final void a(int i, u uVar) {
        CharSequence charSequence;
        CharSequence charSequence2 = null;
        int count = uVar != null ? uVar.getCount() : 0;
        this.yk = true;
        if (i <= 0 || uVar == null) {
            charSequence = null;
        } else {
            charSequence = uVar.bW();
        }
        this.ye.setText(charSequence);
        TextView textView = this.yf;
        if (uVar == null || i >= count) {
            charSequence = null;
        } else {
            charSequence = uVar.bW();
        }
        textView.setText(charSequence);
        if (i + 1 < count && uVar != null) {
            charSequence2 = uVar.bW();
        }
        this.yg.setText(charSequence2);
        count = MeasureSpec.makeMeasureSpec(Math.max(0, (int) (((float) ((getWidth() - getPaddingLeft()) - getPaddingRight())) * 0.8f)), Integer.MIN_VALUE);
        int makeMeasureSpec = MeasureSpec.makeMeasureSpec(Math.max(0, (getHeight() - getPaddingTop()) - getPaddingBottom()), Integer.MIN_VALUE);
        this.ye.measure(count, makeMeasureSpec);
        this.yf.measure(count, makeMeasureSpec);
        this.yg.measure(count, makeMeasureSpec);
        this.yh = i;
        if (!this.yl) {
            a(i, this.yi, false);
        }
        this.yk = false;
    }

    public void requestLayout() {
        if (!this.yk) {
            super.requestLayout();
        }
    }

    final void a(u uVar, u uVar2) {
        if (uVar != null) {
            uVar.unregisterDataSetObserver(this.ym);
            this.yn = null;
        }
        if (uVar2 != null) {
            uVar2.registerDataSetObserver(this.ym);
            this.yn = new WeakReference(uVar2);
        }
        if (this.yd != null) {
            this.yh = -1;
            this.yi = -1.0f;
            a(this.yd.yQ, uVar2);
            requestLayout();
        }
    }

    void a(int i, float f, boolean z) {
        if (i != this.yh) {
            a(i, this.yd.yP);
        } else if (!z && f == this.yi) {
            return;
        }
        this.yl = true;
        int measuredWidth = this.ye.getMeasuredWidth();
        int measuredWidth2 = this.yf.getMeasuredWidth();
        int measuredWidth3 = this.yg.getMeasuredWidth();
        int i2 = measuredWidth2 / 2;
        int width = getWidth();
        int height = getHeight();
        int paddingLeft = getPaddingLeft();
        int paddingRight = getPaddingRight();
        int paddingTop = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        int i3 = paddingRight + i2;
        int i4 = (width - (paddingLeft + i2)) - i3;
        float f2 = 0.5f + f;
        if (f2 > 1.0f) {
            f2 -= 1.0f;
        }
        i3 = ((width - i3) - ((int) (f2 * ((float) i4)))) - i2;
        i4 = i3 + measuredWidth2;
        int baseline = this.ye.getBaseline();
        measuredWidth2 = this.yf.getBaseline();
        i2 = this.yg.getBaseline();
        int max = Math.max(Math.max(baseline, measuredWidth2), i2);
        baseline = max - baseline;
        measuredWidth2 = max - measuredWidth2;
        max -= i2;
        int measuredHeight = this.yg.getMeasuredHeight() + max;
        i2 = Math.max(Math.max(this.ye.getMeasuredHeight() + baseline, this.yf.getMeasuredHeight() + measuredWidth2), measuredHeight);
        switch (this.ut & MMGIFException.D_GIF_ERR_IMAGE_DEFECT) {
            case 16:
                height = (((height - paddingTop) - paddingBottom) - i2) / 2;
                i2 = height + baseline;
                baseline = height + measuredWidth2;
                measuredWidth2 = height + max;
                break;
            case 80:
                height = (height - paddingBottom) - i2;
                i2 = height + baseline;
                baseline = height + measuredWidth2;
                measuredWidth2 = height + max;
                break;
            default:
                i2 = paddingTop + baseline;
                baseline = paddingTop + measuredWidth2;
                measuredWidth2 = paddingTop + max;
                break;
        }
        this.yf.layout(i3, baseline, i4, this.yf.getMeasuredHeight() + baseline);
        baseline = Math.min(paddingLeft, (i3 - this.yj) - measuredWidth);
        this.ye.layout(baseline, i2, measuredWidth + baseline, this.ye.getMeasuredHeight() + i2);
        baseline = Math.max((width - paddingRight) - measuredWidth3, this.yj + i4);
        this.yg.layout(baseline, measuredWidth2, baseline + measuredWidth3, this.yg.getMeasuredHeight() + measuredWidth2);
        this.yi = f;
        this.yl = false;
    }

    protected void onMeasure(int i, int i2) {
        if (MeasureSpec.getMode(i) != 1073741824) {
            throw new IllegalStateException("Must measure with an exact width");
        }
        int paddingTop = getPaddingTop() + getPaddingBottom();
        int childMeasureSpec = getChildMeasureSpec(i2, paddingTop, -2);
        int size = MeasureSpec.getSize(i);
        int childMeasureSpec2 = getChildMeasureSpec(i, (int) (((float) size) * 0.2f), -2);
        this.ye.measure(childMeasureSpec2, childMeasureSpec);
        this.yf.measure(childMeasureSpec2, childMeasureSpec);
        this.yg.measure(childMeasureSpec2, childMeasureSpec);
        if (MeasureSpec.getMode(i2) == 1073741824) {
            paddingTop = MeasureSpec.getSize(i2);
        } else {
            paddingTop = Math.max(getMinHeight(), paddingTop + this.yf.getMeasuredHeight());
        }
        setMeasuredDimension(size, z.resolveSizeAndState(paddingTop, i2, z.M(this.yf) << 16));
    }

    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        float f = 0.0f;
        if (this.yd != null) {
            if (this.yi >= 0.0f) {
                f = this.yi;
            }
            a(this.yh, f, true);
        }
    }

    int getMinHeight() {
        Drawable background = getBackground();
        if (background != null) {
            return background.getIntrinsicHeight();
        }
        return 0;
    }
}
