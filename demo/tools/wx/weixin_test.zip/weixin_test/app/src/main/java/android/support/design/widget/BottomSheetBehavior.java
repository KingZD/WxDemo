package android.support.design.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.design.a$i;
import android.support.design.widget.CoordinatorLayout.Behavior;
import android.support.v4.view.o;
import android.support.v4.view.p;
import android.support.v4.view.y;
import android.support.v4.view.z;
import android.support.v4.widget.u;
import android.support.v4.widget.u.a;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.View.BaseSavedState;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import java.lang.ref.WeakReference;

public class BottomSheetBehavior<V extends View> extends Behavior<V> {
    private boolean fA;
    private int fB;
    public WeakReference<V> fC;
    private WeakReference<View> fD;
    public BottomSheetBehavior$a fE;
    private VelocityTracker fF;
    private int fG;
    private int fH;
    private boolean fI;
    private final a fJ = new BottomSheetBehavior$1(this);
    private float fs;
    private int ft;
    public int fu;
    private int fv;
    public boolean fw;
    public u fx;
    private boolean fy;
    private int fz;
    public int mState = 4;

    protected static class SavedState extends BaseSavedState {
        public static final Creator<SavedState> CREATOR = new BottomSheetBehavior$SavedState$1();
        final int state;

        public SavedState(Parcel parcel) {
            super(parcel);
            this.state = parcel.readInt();
        }

        public SavedState(Parcelable parcelable, int i) {
            super(parcelable);
            this.state = i;
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.state);
        }
    }

    public BottomSheetBehavior(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, a$i.ci);
        r(obtainStyledAttributes.getDimensionPixelSize(a$i.cj, 0));
        this.fw = obtainStyledAttributes.getBoolean(a$i.ck, false);
        obtainStyledAttributes.recycle();
        this.fs = (float) ViewConfiguration.get(context).getScaledMaximumFlingVelocity();
    }

    public final Parcelable b(CoordinatorLayout coordinatorLayout, V v) {
        return new SavedState(super.b(coordinatorLayout, v), this.mState);
    }

    public final void a(CoordinatorLayout coordinatorLayout, V v, Parcelable parcelable) {
        SavedState savedState = (SavedState) parcelable;
        super.a(coordinatorLayout, v, savedState.getSuperState());
        if (savedState.state == 1 || savedState.state == 2) {
            this.mState = 4;
        } else {
            this.mState = savedState.state;
        }
    }

    public final boolean a(CoordinatorLayout coordinatorLayout, V v, int i) {
        if (!(this.mState == 1 || this.mState == 2)) {
            if (z.Z(coordinatorLayout) && !z.Z(v)) {
                z.a(v, true);
            }
            coordinatorLayout.e(v, i);
        }
        this.fB = coordinatorLayout.getHeight();
        this.fu = Math.max(0, this.fB - v.getHeight());
        this.fv = Math.max(this.fB - this.ft, this.fu);
        if (this.mState == 3) {
            z.j(v, this.fu);
        } else if (this.fw && this.mState == 5) {
            z.j(v, this.fB);
        } else if (this.mState == 4) {
            z.j(v, this.fv);
        }
        if (this.fx == null) {
            this.fx = u.a(coordinatorLayout, this.fJ);
        }
        this.fC = new WeakReference(v);
        this.fD = new WeakReference(h((View) v));
        return true;
    }

    public final boolean a(CoordinatorLayout coordinatorLayout, V v, MotionEvent motionEvent) {
        if (!v.isShown()) {
            return false;
        }
        int d = o.d(motionEvent);
        if (d == 0) {
            reset();
        }
        if (this.fF == null) {
            this.fF = VelocityTracker.obtain();
        }
        this.fF.addMovement(motionEvent);
        switch (d) {
            case 0:
                int x = (int) motionEvent.getX();
                this.fH = (int) motionEvent.getY();
                View view = (View) this.fD.get();
                if (view != null && coordinatorLayout.b(view, x, this.fH)) {
                    this.fG = motionEvent.getPointerId(motionEvent.getActionIndex());
                    this.fI = true;
                }
                boolean z = this.fG == -1 && !coordinatorLayout.b(v, x, this.fH);
                this.fy = z;
                break;
            case 1:
            case 3:
                this.fI = false;
                this.fG = -1;
                if (this.fy) {
                    this.fy = false;
                    return false;
                }
                break;
        }
        if (!this.fy && this.fx.j(motionEvent)) {
            return true;
        }
        view = (View) this.fD.get();
        if (d != 2 || view == null || this.fy || this.mState == 1 || coordinatorLayout.b(view, (int) motionEvent.getX(), (int) motionEvent.getY()) || Math.abs(((float) this.fH) - motionEvent.getY()) <= ((float) this.fx.iY)) {
            return false;
        }
        return true;
    }

    public final boolean b(CoordinatorLayout coordinatorLayout, V v, MotionEvent motionEvent) {
        if (!v.isShown()) {
            return false;
        }
        int d = o.d(motionEvent);
        if (this.mState == 1 && d == 0) {
            return true;
        }
        this.fx.k(motionEvent);
        if (d == 0) {
            reset();
        }
        if (this.fF == null) {
            this.fF = VelocityTracker.obtain();
        }
        this.fF.addMovement(motionEvent);
        if (d != 2 || this.fy || Math.abs(((float) this.fH) - motionEvent.getY()) <= ((float) this.fx.iY)) {
            return true;
        }
        this.fx.n(v, motionEvent.getPointerId(motionEvent.getActionIndex()));
        return true;
    }

    public final boolean a(CoordinatorLayout coordinatorLayout, V v, View view, int i) {
        this.fz = 0;
        this.fA = false;
        if ((i & 2) != 0) {
            return true;
        }
        return false;
    }

    public final void a(CoordinatorLayout coordinatorLayout, V v, View view, int i, int[] iArr) {
        if (view == ((View) this.fD.get())) {
            int top = v.getTop();
            int i2 = top - i;
            if (i > 0) {
                if (i2 < this.fu) {
                    iArr[1] = top - this.fu;
                    z.j(v, -iArr[1]);
                    s(3);
                } else {
                    iArr[1] = i;
                    z.j(v, -i);
                    s(1);
                }
            } else if (i < 0 && !z.h(view, -1)) {
                if (i2 <= this.fv || this.fw) {
                    iArr[1] = i;
                    z.j(v, -i);
                    s(1);
                } else {
                    iArr[1] = top - this.fv;
                    z.j(v, -iArr[1]);
                    s(4);
                }
            }
            t(v.getTop());
            this.fz = i;
            this.fA = true;
        }
    }

    public final void a(CoordinatorLayout coordinatorLayout, V v, View view) {
        int i = 3;
        if (v.getTop() == this.fu) {
            s(3);
        } else if (view == this.fD.get() && this.fA) {
            int i2;
            if (this.fz > 0) {
                i2 = this.fu;
            } else {
                if (this.fw) {
                    this.fF.computeCurrentVelocity(1000, this.fs);
                    if (a((View) v, y.b(this.fF, this.fG))) {
                        i2 = this.fB;
                        i = 5;
                    }
                }
                if (this.fz == 0) {
                    int top = v.getTop();
                    if (Math.abs(top - this.fu) < Math.abs(top - this.fv)) {
                        i2 = this.fu;
                    } else {
                        i2 = this.fv;
                        i = 4;
                    }
                } else {
                    i2 = this.fv;
                    i = 4;
                }
            }
            if (this.fx.e(v, v.getLeft(), i2)) {
                s(2);
                z.a(v, new BottomSheetBehavior$b(this, v, i));
            } else {
                s(i);
            }
            this.fA = false;
        }
    }

    public final boolean a(CoordinatorLayout coordinatorLayout, V v, View view, float f, float f2) {
        return view == this.fD.get() && (this.mState != 3 || super.a(coordinatorLayout, v, view, f, f2));
    }

    public final void r(int i) {
        this.ft = Math.max(0, i);
        this.fv = this.fB - i;
    }

    public final void s(int i) {
        if (this.mState != i) {
            this.mState = i;
            if (((View) this.fC.get()) != null && this.fE != null) {
                this.fE.v(i);
            }
        }
    }

    private void reset() {
        this.fG = -1;
        if (this.fF != null) {
            this.fF.recycle();
            this.fF = null;
        }
    }

    private boolean a(View view, float f) {
        if (view.getTop() >= this.fv && Math.abs((((float) view.getTop()) + (0.1f * f)) - ((float) this.fv)) / ((float) this.ft) > 0.5f) {
            return true;
        }
        return false;
    }

    private View h(View view) {
        if (view instanceof p) {
            return view;
        }
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            int childCount = viewGroup.getChildCount();
            for (int i = 0; i < childCount; i++) {
                View h = h(viewGroup.getChildAt(i));
                if (h != null) {
                    return h;
                }
            }
        }
        return null;
    }

    private void t(int i) {
        if (((View) this.fC.get()) != null && this.fE != null) {
            if (i > this.fv) {
                this.fE.g(((float) (this.fv - i)) / ((float) this.ft));
            } else {
                this.fE.g(((float) (this.fv - i)) / ((float) (this.fv - this.fu)));
            }
        }
    }

    public static <V extends View> BottomSheetBehavior<V> i(V v) {
        LayoutParams layoutParams = v.getLayoutParams();
        if (layoutParams instanceof CoordinatorLayout$d) {
            Behavior behavior = ((CoordinatorLayout$d) layoutParams).hO;
            if (behavior instanceof BottomSheetBehavior) {
                return (BottomSheetBehavior) behavior;
            }
            throw new IllegalArgumentException("The view is not associated with BottomSheetBehavior");
        }
        throw new IllegalArgumentException("The view is not a child of CoordinatorLayout");
    }
}
