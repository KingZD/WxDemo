package android.support.v4.app;

public interface z$g {
    z$d a(z$d z_d);
}
