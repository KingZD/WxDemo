package android.support.design.widget;

import java.lang.ref.WeakReference;

class q$b {
    int duration;
    final WeakReference<q$a> jS;

    final boolean f(q$a q_a) {
        return q_a != null && this.jS.get() == q_a;
    }
}
