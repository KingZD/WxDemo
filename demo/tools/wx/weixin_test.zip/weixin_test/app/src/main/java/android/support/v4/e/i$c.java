package android.support.v4.e;

public class i$c<T> extends i$b<T> {
    private final Object mLock = new Object();

    public i$c() {
        super(16);
    }

    public final T bR() {
        T bR;
        synchronized (this.mLock) {
            bR = super.bR();
        }
        return bR;
    }

    public final boolean j(T t) {
        boolean j;
        synchronized (this.mLock) {
            j = super.j(t);
        }
        return j;
    }
}
