package android.support.v4.media;

import android.os.Bundle;
import java.util.HashMap;
import java.util.List;

class MediaBrowserServiceCompat$b {
    final /* synthetic */ MediaBrowserServiceCompat uK;
    String uN;
    Bundle uO;
    MediaBrowserServiceCompat$d uP;
    MediaBrowserServiceCompat$a uQ;
    HashMap<String, List<Bundle>> uR;

    private MediaBrowserServiceCompat$b(MediaBrowserServiceCompat mediaBrowserServiceCompat) {
        this.uK = mediaBrowserServiceCompat;
        this.uR = new HashMap();
    }
}
