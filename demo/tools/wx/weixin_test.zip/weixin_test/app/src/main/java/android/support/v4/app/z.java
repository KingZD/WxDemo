package android.support.v4.app;

import android.app.Notification;
import android.app.Notification.Builder;
import android.app.PendingIntent;
import android.content.Context;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.v4.app.ac.b;
import android.widget.RemoteViews;
import java.util.ArrayList;
import java.util.Iterator;

public final class z {
    private static final z$i sa;

    protected static class e {
        protected e() {
        }
    }

    static class j extends z$q {
        j() {
        }

        public Notification b(z$d z_d) {
            y aa_a = new aa$a(z_d.mContext, z_d.sG, z_d.si, z_d.sj, z_d.so, z_d.sm, z_d.sp, z_d.sk, z_d.sl, z_d.sn, z_d.su, z_d.sv, z_d.sw, z_d.sq, z_d.sr, z_d.mPriority, z_d.st, z_d.sB, z_d.sH, z_d.mExtras, z_d.sx, z_d.sy, z_d.sz);
            z.a((x) aa_a, z_d.sA);
            z.a(aa_a, z_d.ss);
            return aa_a.build();
        }
    }

    static class l implements z$i {
        l() {
        }

        public Notification b(z$d z_d) {
            Notification notification = z_d.sG;
            notification.setLatestEventInfo(z_d.mContext, z_d.si, z_d.sj, z_d.sk);
            if (z_d.mPriority > 0) {
                notification.flags |= 128;
            }
            return notification;
        }

        public Bundle a(Notification notification) {
            return null;
        }

        public Bundle a(b bVar) {
            return null;
        }
    }

    static class n extends l {
        n() {
        }

        public final Notification b(z$d z_d) {
            Context context = z_d.mContext;
            Notification notification = z_d.sG;
            CharSequence charSequence = z_d.si;
            CharSequence charSequence2 = z_d.sj;
            CharSequence charSequence3 = z_d.so;
            RemoteViews remoteViews = z_d.sm;
            int i = z_d.sp;
            PendingIntent pendingIntent = z_d.sk;
            return new Builder(context).setWhen(notification.when).setSmallIcon(notification.icon, notification.iconLevel).setContent(notification.contentView).setTicker(notification.tickerText, remoteViews).setSound(notification.sound, notification.audioStreamType).setVibrate(notification.vibrate).setLights(notification.ledARGB, notification.ledOnMS, notification.ledOffMS).setOngoing((notification.flags & 2) != 0).setOnlyAlertOnce((notification.flags & 8) != 0).setAutoCancel((notification.flags & 16) != 0).setDefaults(notification.defaults).setContentTitle(charSequence).setContentText(charSequence2).setContentInfo(charSequence3).setContentIntent(pendingIntent).setDeleteIntent(notification.deleteIntent).setFullScreenIntent(z_d.sl, (notification.flags & 128) != 0).setLargeIcon(z_d.sn).setNumber(i).getNotification();
        }
    }

    static /* synthetic */ void a(x xVar, ArrayList arrayList) {
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            xVar.a((z$a) it.next());
        }
    }

    static /* synthetic */ void a(y yVar, z$r z_r) {
        if (z_r == null) {
            return;
        }
        if (z_r instanceof z$c) {
            z$c z_c = (z$c) z_r;
            ae.a(yVar, z_c.sT, z_c.sV, z_c.sU, z_c.sh);
        } else if (z_r instanceof z$h) {
            z$h z_h = (z$h) z_r;
            ae.a(yVar, z_h.sT, z_h.sV, z_h.sU, z_h.sS);
        } else if (z_r instanceof z$b) {
            z$b z_b = (z$b) z_r;
            ae.a(yVar, z_b.sT, z_b.sV, z_b.sU, z_b.se, z_b.sf, z_b.sg);
        }
    }

    static {
        if (VERSION.SDK_INT >= 21) {
            sa = new z$k();
        } else if (VERSION.SDK_INT >= 20) {
            sa = new j();
        } else if (VERSION.SDK_INT >= 19) {
            sa = new z$q();
        } else if (VERSION.SDK_INT >= 16) {
            sa = new z$p();
        } else if (VERSION.SDK_INT >= 14) {
            sa = new z$o();
        } else if (VERSION.SDK_INT >= 11) {
            sa = new n();
        } else if (VERSION.SDK_INT >= 9) {
            sa = new z$m();
        } else {
            sa = new l();
        }
    }

    public static Bundle a(Notification notification) {
        return sa.a(notification);
    }
}
