package android.support.v4.os;

import android.os.Parcel;
import android.os.Parcelable.ClassLoaderCreator;

final class d<T> implements ClassLoaderCreator<T> {
    private final c<T> vN;

    public d(c<T> cVar) {
        this.vN = cVar;
    }

    public final T createFromParcel(Parcel parcel) {
        return this.vN.createFromParcel(parcel, null);
    }

    public final T createFromParcel(Parcel parcel, ClassLoader classLoader) {
        return this.vN.createFromParcel(parcel, classLoader);
    }

    public final T[] newArray(int i) {
        return this.vN.newArray(i);
    }
}
