package android.support.v4.widget;

public interface SwipeRefreshLayout$a {
}
