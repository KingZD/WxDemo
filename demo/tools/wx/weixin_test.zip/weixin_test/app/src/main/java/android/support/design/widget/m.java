package android.support.design.widget;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.animation.StateListAnimator;
import android.annotation.TargetApi;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.RippleDrawable;
import android.support.v4.b.a.a;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;

@TargetApi(21)
final class m extends k {
    private InsetDrawable iT;
    private final Interpolator mInterpolator;

    m(VisibilityAwareImageButton visibilityAwareImageButton, p pVar) {
        super(visibilityAwareImageButton, pVar);
        this.mInterpolator = visibilityAwareImageButton.isInEditMode() ? null : AnimationUtils.loadInterpolator(this.iP.getContext(), 17563661);
    }

    final void a(ColorStateList colorStateList, Mode mode, int i, int i2) {
        Drawable layerDrawable;
        this.iI = a.h(aq());
        a.a(this.iI, colorStateList);
        if (mode != null) {
            a.a(this.iI, mode);
        }
        if (i2 > 0) {
            this.iK = a(i2, colorStateList);
            layerDrawable = new LayerDrawable(new Drawable[]{this.iK, this.iI});
        } else {
            this.iK = null;
            layerDrawable = this.iI;
        }
        this.iJ = new RippleDrawable(ColorStateList.valueOf(i), layerDrawable, null);
        this.iL = this.iJ;
        this.iQ.setBackgroundDrawable(this.iJ);
    }

    public final void l(float f) {
        this.iP.setElevation(f);
        if (this.iQ.aj()) {
            ao();
        }
    }

    final void m(float f) {
        StateListAnimator stateListAnimator = new StateListAnimator();
        stateListAnimator.addState(PRESSED_ENABLED_STATE_SET, a(ObjectAnimator.ofFloat(this.iP, "translationZ", new float[]{f})));
        stateListAnimator.addState(iO, a(ObjectAnimator.ofFloat(this.iP, "translationZ", new float[]{f})));
        stateListAnimator.addState(EMPTY_STATE_SET, a(ObjectAnimator.ofFloat(this.iP, "translationZ", new float[]{0.0f})));
        this.iP.setStateListAnimator(stateListAnimator);
        if (this.iQ.aj()) {
            ao();
        }
    }

    final void e(Rect rect) {
        if (this.iQ.aj()) {
            this.iT = new InsetDrawable(this.iJ, rect.left, rect.top, rect.right, rect.bottom);
            this.iQ.setBackgroundDrawable(this.iT);
            return;
        }
        this.iQ.setBackgroundDrawable(this.iJ);
    }

    final void c(int[] iArr) {
    }

    final void ak() {
    }

    final boolean am() {
        return false;
    }

    private Animator a(Animator animator) {
        animator.setInterpolator(this.mInterpolator);
        return animator;
    }

    final d ap() {
        return new e();
    }

    final void d(Rect rect) {
        if (this.iQ.aj()) {
            float ai = this.iQ.ai();
            float elevation = this.iP.getElevation() + this.iN;
            int ceil = (int) Math.ceil((double) o.d(elevation, ai, false));
            int ceil2 = (int) Math.ceil((double) o.c(elevation, ai, false));
            rect.set(ceil, ceil2, ceil, ceil2);
            return;
        }
        rect.set(0, 0, 0, 0);
    }
}
