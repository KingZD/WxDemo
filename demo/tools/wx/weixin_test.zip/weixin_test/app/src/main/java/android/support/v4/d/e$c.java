package android.support.v4.d;

interface e$c {
    int a(CharSequence charSequence, int i, int i2);
}
