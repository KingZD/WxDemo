package android.support.design.widget;

import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;

class r$1 implements AnimationListener {
    final /* synthetic */ r jX;

    r$1(r rVar) {
        this.jX = rVar;
    }

    public final void onAnimationEnd(Animation animation) {
        if (this.jX.jV == animation) {
            this.jX.jV = null;
        }
    }

    public final void onAnimationStart(Animation animation) {
    }

    public final void onAnimationRepeat(Animation animation) {
    }
}
