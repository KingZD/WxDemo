package android.support.v4.media;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class MediaBrowserCompat$MediaItem implements Parcelable {
    public static final Creator<MediaBrowserCompat$MediaItem> CREATOR = new MediaBrowserCompat$MediaItem$1();
    private final int uC;
    private final MediaDescriptionCompat uD;

    private MediaBrowserCompat$MediaItem(Parcel parcel) {
        this.uC = parcel.readInt();
        this.uD = (MediaDescriptionCompat) MediaDescriptionCompat.CREATOR.createFromParcel(parcel);
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.uC);
        this.uD.writeToParcel(parcel, i);
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder("MediaItem{");
        stringBuilder.append("mFlags=").append(this.uC);
        stringBuilder.append(", mDescription=").append(this.uD);
        stringBuilder.append('}');
        return stringBuilder.toString();
    }
}
