package android.support.v4.media;

import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;

class MediaBrowserServiceCompat$g$1 implements Runnable {
    final /* synthetic */ MediaBrowserServiceCompat$d uX;
    final /* synthetic */ String uY;
    final /* synthetic */ Bundle uZ;
    final /* synthetic */ int va;
    final /* synthetic */ MediaBrowserServiceCompat$g vb;

    MediaBrowserServiceCompat$g$1(MediaBrowserServiceCompat$g mediaBrowserServiceCompat$g, MediaBrowserServiceCompat$d mediaBrowserServiceCompat$d, String str, Bundle bundle, int i) {
        this.vb = mediaBrowserServiceCompat$g;
        this.uX = mediaBrowserServiceCompat$d;
        this.uY = str;
        this.uZ = bundle;
        this.va = i;
    }

    public final void run() {
        IBinder asBinder = this.uX.asBinder();
        MediaBrowserServiceCompat.b(this.vb.uK).remove(asBinder);
        MediaBrowserServiceCompat$b mediaBrowserServiceCompat$b = new MediaBrowserServiceCompat$b(this.vb.uK, (byte) 0);
        mediaBrowserServiceCompat$b.uN = this.uY;
        mediaBrowserServiceCompat$b.uO = this.uZ;
        mediaBrowserServiceCompat$b.uP = this.uX;
        mediaBrowserServiceCompat$b.uQ = this.vb.uK.bF();
        if (mediaBrowserServiceCompat$b.uQ == null) {
            new StringBuilder("No root for client ").append(this.uY).append(" from service ").append(getClass().getName());
            try {
                this.uX.bG();
                return;
            } catch (RemoteException e) {
                new StringBuilder("Calling onConnectFailed() failed. Ignoring. pkg=").append(this.uY);
                return;
            }
        }
        try {
            MediaBrowserServiceCompat.b(this.vb.uK).put(asBinder, mediaBrowserServiceCompat$b);
            if (this.vb.uK.uG != null) {
                this.uX.a(mediaBrowserServiceCompat$b.uQ.uM, this.vb.uK.uG, mediaBrowserServiceCompat$b.uQ.mExtras);
            }
        } catch (RemoteException e2) {
            new StringBuilder("Calling onConnect() failed. Dropping client. pkg=").append(this.uY);
            MediaBrowserServiceCompat.b(this.vb.uK).remove(asBinder);
        }
    }
}
