package android.support.design.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.support.design.a$d;
import android.support.design.a$i;
import android.support.design.a.h;
import android.support.v4.e.i$a;
import android.support.v4.e.i$b;
import android.support.v4.e.i$c;
import android.support.v4.view.z;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.widget.FrameLayout.LayoutParams;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import java.util.ArrayList;

public class TabLayout extends HorizontalScrollView {
    private static final i$a<TabLayout$b> kl = new i$c();
    private final int kA;
    private final int kB;
    private int kC;
    private int kD;
    private u kE;
    private final i$a<TabLayout$c> kF;
    private final ArrayList<TabLayout$b> km;
    private TabLayout$b kn;
    private final TabLayout$a ko;
    private int kp;
    private int kq;
    private int kr;
    private int ks;
    private int kt;
    private ColorStateList ku;
    private float kv;
    private float kw;
    private final int kx;
    private int ky;
    private final int kz;
    private int mMode;

    public TabLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public TabLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.km = new ArrayList();
        this.ky = Integer.MAX_VALUE;
        this.kF = new i$b(12);
        t.p(context);
        setHorizontalScrollBarEnabled(false);
        this.ko = new TabLayout$a(this, context);
        super.addView(this.ko, 0, new LayoutParams(-2, -1));
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, a$i.dA, i, h.bY);
        View view = this.ko;
        int dimensionPixelSize = obtainStyledAttributes.getDimensionPixelSize(a$i.dC, 0);
        if (view.kH != dimensionPixelSize) {
            view.kH = dimensionPixelSize;
            z.E(view);
        }
        view = this.ko;
        dimensionPixelSize = obtainStyledAttributes.getColor(a$i.dB, 0);
        if (view.kI.getColor() != dimensionPixelSize) {
            view.kI.setColor(dimensionPixelSize);
            z.E(view);
        }
        int dimensionPixelSize2 = obtainStyledAttributes.getDimensionPixelSize(a$i.dQ, 0);
        this.ks = dimensionPixelSize2;
        this.kr = dimensionPixelSize2;
        this.kq = dimensionPixelSize2;
        this.kp = dimensionPixelSize2;
        this.kp = obtainStyledAttributes.getDimensionPixelSize(a$i.dM, this.kp);
        this.kq = obtainStyledAttributes.getDimensionPixelSize(a$i.dN, this.kq);
        this.kr = obtainStyledAttributes.getDimensionPixelSize(a$i.dO, this.kr);
        this.ks = obtainStyledAttributes.getDimensionPixelSize(a$i.dP, this.ks);
        this.kt = obtainStyledAttributes.getResourceId(a$i.dJ, h.bQ);
        TypedArray obtainStyledAttributes2 = context.obtainStyledAttributes(this.kt, a$i.TextAppearance);
        try {
            this.kv = (float) obtainStyledAttributes2.getDimensionPixelSize(a$i.TextAppearance_android_textSize, 0);
            this.ku = obtainStyledAttributes2.getColorStateList(a$i.TextAppearance_android_textColor);
            if (obtainStyledAttributes.hasValue(a$i.dK)) {
                this.ku = obtainStyledAttributes.getColorStateList(a$i.dK);
            }
            if (obtainStyledAttributes.hasValue(a$i.dL)) {
                dimensionPixelSize2 = obtainStyledAttributes.getColor(a$i.dL, 0);
                dimensionPixelSize = this.ku.getDefaultColor();
                r4 = new int[2][];
                int[] iArr = new int[]{SELECTED_STATE_SET, dimensionPixelSize2};
                r4[1] = EMPTY_STATE_SET;
                iArr[1] = dimensionPixelSize;
                this.ku = new ColorStateList(r4, iArr);
            }
            this.kz = obtainStyledAttributes.getDimensionPixelSize(a$i.dH, -1);
            this.kA = obtainStyledAttributes.getDimensionPixelSize(a$i.dI, -1);
            this.kx = obtainStyledAttributes.getResourceId(a$i.dE, 0);
            this.kC = obtainStyledAttributes.getDimensionPixelSize(a$i.dD, 0);
            this.mMode = obtainStyledAttributes.getInt(a$i.dF, 1);
            this.kD = obtainStyledAttributes.getInt(a$i.dG, 0);
            obtainStyledAttributes.recycle();
            Resources resources = getResources();
            this.kw = (float) resources.getDimensionPixelSize(a$d.bw);
            this.kB = resources.getDimensionPixelSize(a$d.bv);
            z.c(this.ko, this.mMode == 0 ? Math.max(0, this.kC - this.kp) : 0, 0, 0, 0);
            switch (this.mMode) {
                case 0:
                    this.ko.setGravity(8388611);
                    break;
                case 1:
                    this.ko.setGravity(1);
                    break;
            }
            r(true);
        } finally {
            obtainStyledAttributes2.recycle();
        }
    }

    private void I(int i) {
        int round = Math.round(((float) i) + 0.0f);
        if (round >= 0 && round < this.ko.getChildCount()) {
            TabLayout$a tabLayout$a = this.ko;
            if (tabLayout$a.kN != null && tabLayout$a.kN.lD.isRunning()) {
                tabLayout$a.kN.lD.cancel();
            }
            tabLayout$a.kJ = i;
            tabLayout$a.kK = 0.0f;
            tabLayout$a.aD();
            if (this.kE != null && this.kE.lD.isRunning()) {
                this.kE.lD.cancel();
            }
            scrollTo(b(i, 0.0f), 0);
            L(round);
        }
    }

    public boolean shouldDelayChildPressedState() {
        return Math.max(0, ((this.ko.getWidth() - getWidth()) - getPaddingLeft()) - getPaddingRight()) > 0;
    }

    private void a(TabLayout$b tabLayout$b, int i) {
        tabLayout$b.mPosition = i;
        this.km.add(i, tabLayout$b);
        int size = this.km.size();
        for (int i2 = i + 1; i2 < size; i2++) {
            ((TabLayout$b) this.km.get(i2)).mPosition = i2;
        }
    }

    public void addView(View view) {
        t(view);
    }

    public void addView(View view, int i) {
        t(view);
    }

    public void addView(View view, ViewGroup.LayoutParams layoutParams) {
        t(view);
    }

    public void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        t(view);
    }

    private void t(View view) {
        if (view instanceof TabItem) {
            TabLayout$b tabLayout$b;
            TabItem tabItem = (TabItem) view;
            TabLayout$b tabLayout$b2 = (TabLayout$b) kl.bR();
            if (tabLayout$b2 == null) {
                tabLayout$b = new TabLayout$b((byte) 0);
            } else {
                tabLayout$b = tabLayout$b2;
            }
            tabLayout$b.kW = this;
            TabLayout$c tabLayout$c = this.kF != null ? (TabLayout$c) this.kF.bR() : null;
            if (tabLayout$c == null) {
                tabLayout$c = new TabLayout$c(this, getContext());
            }
            TabLayout$c.a(tabLayout$c, tabLayout$b);
            tabLayout$c.setFocusable(true);
            tabLayout$c.setMinimumWidth(aC());
            tabLayout$b.kX = tabLayout$c;
            if (tabItem.mText != null) {
                tabLayout$b.mText = tabItem.mText;
                tabLayout$b.aF();
            }
            if (tabItem.kj != null) {
                tabLayout$b.kj = tabItem.kj;
                tabLayout$b.aF();
            }
            if (tabItem.kk != 0) {
                tabLayout$b.kV = LayoutInflater.from(tabLayout$b.kX.getContext()).inflate(tabItem.kk, tabLayout$b.kX, false);
                tabLayout$b.aF();
            }
            boolean isEmpty = this.km.isEmpty();
            if (tabLayout$b.kW != this) {
                throw new IllegalArgumentException("Tab belongs to a different TabLayout.");
            }
            View view2 = tabLayout$b.kX;
            TabLayout$a tabLayout$a = this.ko;
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -1);
            a(layoutParams);
            tabLayout$a.addView(view2, layoutParams);
            if (isEmpty) {
                view2.setSelected(true);
            }
            a(tabLayout$b, this.km.size());
            if (isEmpty) {
                tabLayout$b.select();
                return;
            }
            return;
        }
        throw new IllegalArgumentException("Only TabItem instances can be added to TabLayout");
    }

    private void a(LinearLayout.LayoutParams layoutParams) {
        if (this.mMode == 1 && this.kD == 0) {
            layoutParams.width = 0;
            layoutParams.weight = 1.0f;
            return;
        }
        layoutParams.width = -2;
        layoutParams.weight = 0.0f;
    }

    private int J(int i) {
        return Math.round(getResources().getDisplayMetrics().density * ((float) i));
    }

    protected void onMeasure(int i, int i2) {
        int i3;
        int i4 = 1;
        int size = this.km.size();
        for (int i5 = 0; i5 < size; i5++) {
            TabLayout$b tabLayout$b = (TabLayout$b) this.km.get(i5);
            if (tabLayout$b != null && tabLayout$b.kj != null && !TextUtils.isEmpty(tabLayout$b.mText)) {
                i3 = 1;
                break;
            }
        }
        i3 = 0;
        i3 = (J(i3 != 0 ? 72 : 48) + getPaddingTop()) + getPaddingBottom();
        switch (MeasureSpec.getMode(i2)) {
            case Integer.MIN_VALUE:
                i2 = MeasureSpec.makeMeasureSpec(Math.min(i3, MeasureSpec.getSize(i2)), 1073741824);
                break;
            case 0:
                i2 = MeasureSpec.makeMeasureSpec(i3, 1073741824);
                break;
        }
        i3 = MeasureSpec.getSize(i);
        if (MeasureSpec.getMode(i) != 0) {
            if (this.kA > 0) {
                i3 = this.kA;
            } else {
                i3 -= J(56);
            }
            this.ky = i3;
        }
        super.onMeasure(i, i2);
        if (getChildCount() == 1) {
            View childAt = getChildAt(0);
            switch (this.mMode) {
                case 0:
                    if (childAt.getMeasuredWidth() >= getMeasuredWidth()) {
                        i3 = 0;
                        break;
                    } else {
                        i3 = 1;
                        break;
                    }
                case 1:
                    if (childAt.getMeasuredWidth() == getMeasuredWidth()) {
                        i4 = 0;
                    }
                    i3 = i4;
                    break;
                default:
                    i3 = 0;
                    break;
            }
            if (i3 != 0) {
                childAt.measure(MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824), getChildMeasureSpec(i2, getPaddingTop() + getPaddingBottom(), childAt.getLayoutParams().height));
            }
        }
    }

    private void K(int i) {
        Object obj = null;
        if (i != -1) {
            if (getWindowToken() != null && z.ai(this)) {
                int i2;
                TabLayout$a tabLayout$a = this.ko;
                int childCount = tabLayout$a.getChildCount();
                for (i2 = 0; i2 < childCount; i2++) {
                    if (tabLayout$a.getChildAt(i2).getWidth() <= 0) {
                        obj = 1;
                        break;
                    }
                }
                if (obj == null) {
                    int scrollX = getScrollX();
                    i2 = b(i, 0.0f);
                    if (scrollX != i2) {
                        if (this.kE == null) {
                            this.kE = aa.aJ();
                            this.kE.setInterpolator(a.eN);
                            this.kE.setDuration(300);
                            this.kE.a(new TabLayout$1(this));
                        }
                        this.kE.i(scrollX, i2);
                        this.kE.lD.start();
                    }
                    this.ko.h(i, 300);
                    return;
                }
            }
            I(i);
        }
    }

    private void L(int i) {
        int childCount = this.ko.getChildCount();
        if (i < childCount && !this.ko.getChildAt(i).isSelected()) {
            for (int i2 = 0; i2 < childCount; i2++) {
                boolean z;
                View childAt = this.ko.getChildAt(i2);
                if (i2 == i) {
                    z = true;
                } else {
                    z = false;
                }
                childAt.setSelected(z);
            }
        }
    }

    final void a(TabLayout$b tabLayout$b) {
        if (this.kn != tabLayout$b) {
            int i = tabLayout$b != null ? tabLayout$b.mPosition : -1;
            if (i != -1) {
                L(i);
            }
            if ((this.kn == null || this.kn.mPosition == -1) && i != -1) {
                I(i);
            } else {
                K(i);
            }
            this.kn = tabLayout$b;
        } else if (this.kn != null) {
            K(tabLayout$b.mPosition);
        }
    }

    private int b(int i, float f) {
        int i2 = 0;
        if (this.mMode != 0) {
            return 0;
        }
        int width;
        View childAt = this.ko.getChildAt(i);
        View childAt2 = i + 1 < this.ko.getChildCount() ? this.ko.getChildAt(i + 1) : null;
        if (childAt != null) {
            width = childAt.getWidth();
        } else {
            width = 0;
        }
        if (childAt2 != null) {
            i2 = childAt2.getWidth();
        }
        return ((((int) ((((float) (i2 + width)) * 0.0f) * 0.5f)) + childAt.getLeft()) + (childAt.getWidth() / 2)) - (getWidth() / 2);
    }

    private void r(boolean z) {
        for (int i = 0; i < this.ko.getChildCount(); i++) {
            View childAt = this.ko.getChildAt(i);
            childAt.setMinimumWidth(aC());
            a((LinearLayout.LayoutParams) childAt.getLayoutParams());
            if (z) {
                childAt.requestLayout();
            }
        }
    }

    private int aC() {
        if (this.kz != -1) {
            return this.kz;
        }
        return this.mMode == 0 ? this.kB : 0;
    }

    public LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return generateDefaultLayoutParams();
    }
}
