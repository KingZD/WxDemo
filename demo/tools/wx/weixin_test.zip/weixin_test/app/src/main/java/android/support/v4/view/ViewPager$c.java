package android.support.v4.view;

import android.os.Bundle;
import android.support.v4.view.a.a;
import android.support.v4.view.a.b;
import android.support.v4.view.a.f;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;

class ViewPager$c extends a {
    final /* synthetic */ ViewPager zI;

    ViewPager$c(ViewPager viewPager) {
        this.zI = viewPager;
    }

    public final void onInitializeAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(view, accessibilityEvent);
        accessibilityEvent.setClassName(ViewPager.class.getName());
        f a = a.a(accessibilityEvent);
        a.setScrollable(ck());
        if (accessibilityEvent.getEventType() == 4096 && ViewPager.b(this.zI) != null) {
            a.setItemCount(ViewPager.b(this.zI).getCount());
            a.setFromIndex(ViewPager.c(this.zI));
            a.setToIndex(ViewPager.c(this.zI));
        }
    }

    public final void a(View view, b bVar) {
        super.a(view, bVar);
        bVar.setClassName(ViewPager.class.getName());
        bVar.setScrollable(ck());
        if (this.zI.canScrollHorizontally(1)) {
            bVar.addAction(4096);
        }
        if (this.zI.canScrollHorizontally(-1)) {
            bVar.addAction(8192);
        }
    }

    public final boolean performAccessibilityAction(View view, int i, Bundle bundle) {
        if (super.performAccessibilityAction(view, i, bundle)) {
            return true;
        }
        switch (i) {
            case 4096:
                if (!this.zI.canScrollHorizontally(1)) {
                    return false;
                }
                this.zI.ai(ViewPager.c(this.zI) + 1);
                return true;
            case 8192:
                if (!this.zI.canScrollHorizontally(-1)) {
                    return false;
                }
                this.zI.ai(ViewPager.c(this.zI) - 1);
                return true;
            default:
                return false;
        }
    }

    private boolean ck() {
        return ViewPager.b(this.zI) != null && ViewPager.b(this.zI).getCount() > 1;
    }
}
