package android.support.v4.d;

abstract class e$d implements d {
    private final e$c wg;

    protected abstract boolean bI();

    public e$d(e$c e_c) {
        this.wg = e_c;
    }

    public final boolean a(CharSequence charSequence, int i) {
        if (charSequence == null || i < 0 || charSequence.length() - i < 0) {
            throw new IllegalArgumentException();
        } else if (this.wg == null) {
            return bI();
        } else {
            switch (this.wg.a(charSequence, 0, i)) {
                case 0:
                    return true;
                case 1:
                    return false;
                default:
                    return bI();
            }
        }
    }
}
