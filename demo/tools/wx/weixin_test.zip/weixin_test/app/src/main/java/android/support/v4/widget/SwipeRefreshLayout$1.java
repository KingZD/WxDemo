package android.support.v4.widget;

import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;

class SwipeRefreshLayout$1 implements AnimationListener {
    final /* synthetic */ SwipeRefreshLayout EX;

    SwipeRefreshLayout$1(SwipeRefreshLayout swipeRefreshLayout) {
        this.EX = swipeRefreshLayout;
    }

    public final void onAnimationStart(Animation animation) {
    }

    public final void onAnimationRepeat(Animation animation) {
    }

    public final void onAnimationEnd(Animation animation) {
        if (SwipeRefreshLayout.a(this.EX)) {
            SwipeRefreshLayout.b(this.EX).setAlpha(255);
            SwipeRefreshLayout.b(this.EX).start();
            if (SwipeRefreshLayout.c(this.EX) && SwipeRefreshLayout.d(this.EX) != null) {
                SwipeRefreshLayout.d(this.EX);
            }
            SwipeRefreshLayout.a(this.EX, SwipeRefreshLayout.e(this.EX).getTop());
            return;
        }
        SwipeRefreshLayout.f(this.EX);
    }
}
