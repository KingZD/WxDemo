package android.support.design.widget;

import android.os.Build.VERSION;
import android.os.Handler;
import android.os.Looper;
import android.support.design.a$a;
import android.support.v4.view.z;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

public final class Snackbar {
    private static final Handler jC = new Handler(Looper.getMainLooper(), new Snackbar$1());
    final ViewGroup jD;
    final Snackbar$SnackbarLayout jE;
    private final AccessibilityManager jF;
    final q$a jG;

    static /* synthetic */ void a(Snackbar snackbar) {
        q aA = q.aA();
        q$a q_a = snackbar.jG;
        synchronized (aA.mLock) {
            if (aA.d(q_a)) {
                aA.a(aA.jP);
            } else if (aA.e(q_a)) {
                aA.a(aA.jQ);
            }
        }
    }

    final void at() {
        if (VERSION.SDK_INT >= 14) {
            z.c(this.jE, (float) this.jE.getHeight());
            z.U(this.jE).u(0.0f).c(a.eN).h(250).a(new Snackbar$6(this)).start();
            return;
        }
        Animation loadAnimation = AnimationUtils.loadAnimation(this.jE.getContext(), a$a.bc);
        loadAnimation.setInterpolator(a.eN);
        loadAnimation.setDuration(250);
        loadAnimation.setAnimationListener(new Snackbar$7(this));
        this.jE.startAnimation(loadAnimation);
    }

    final void au() {
        q aA = q.aA();
        q$a q_a = this.jG;
        synchronized (aA.mLock) {
            if (aA.d(q_a)) {
                aA.b(aA.jP);
            }
        }
    }

    final void av() {
        q aA = q.aA();
        q$a q_a = this.jG;
        synchronized (aA.mLock) {
            if (aA.d(q_a)) {
                aA.jP = null;
                if (!(aA.jQ == null || aA.jQ == null)) {
                    aA.jP = aA.jQ;
                    aA.jQ = null;
                    if (((q$a) aA.jP.jS.get()) == null) {
                        aA.jP = null;
                    }
                }
            }
        }
        ViewParent parent = this.jE.getParent();
        if (parent instanceof ViewGroup) {
            ((ViewGroup) parent).removeView(this.jE);
        }
    }

    final boolean aw() {
        return !this.jF.isEnabled();
    }
}
