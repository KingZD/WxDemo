package android.support.v4.e;

public final class e<E> implements Cloneable {
    public static final Object wr = new Object();
    public int ij;
    public boolean ws;
    public long[] wt;
    public Object[] wu;

    public final /* synthetic */ Object clone() {
        return bQ();
    }

    public e() {
        this((byte) 0);
    }

    private e(byte b) {
        this.ws = false;
        int aa = b.aa(10);
        this.wt = new long[aa];
        this.wu = new Object[aa];
        this.ij = 0;
    }

    private e<E> bQ() {
        try {
            e<E> eVar = (e) super.clone();
            try {
                eVar.wt = (long[]) this.wt.clone();
                eVar.wu = (Object[]) this.wu.clone();
                return eVar;
            } catch (CloneNotSupportedException e) {
                return eVar;
            }
        } catch (CloneNotSupportedException e2) {
            return null;
        }
    }

    public final E get(long j) {
        int a = b.a(this.wt, this.ij, j);
        return (a < 0 || this.wu[a] == wr) ? null : this.wu[a];
    }

    private void gc() {
        int i = this.ij;
        long[] jArr = this.wt;
        Object[] objArr = this.wu;
        int i2 = 0;
        for (int i3 = 0; i3 < i; i3++) {
            Object obj = objArr[i3];
            if (obj != wr) {
                if (i3 != i2) {
                    jArr[i2] = jArr[i3];
                    objArr[i2] = obj;
                    objArr[i3] = null;
                }
                i2++;
            }
        }
        this.ws = false;
        this.ij = i2;
    }

    public final void put(long j, E e) {
        int a = b.a(this.wt, this.ij, j);
        if (a >= 0) {
            this.wu[a] = e;
            return;
        }
        a ^= -1;
        if (a >= this.ij || this.wu[a] != wr) {
            if (this.ws && this.ij >= this.wt.length) {
                gc();
                a = b.a(this.wt, this.ij, j) ^ -1;
            }
            if (this.ij >= this.wt.length) {
                int aa = b.aa(this.ij + 1);
                Object obj = new long[aa];
                Object obj2 = new Object[aa];
                System.arraycopy(this.wt, 0, obj, 0, this.wt.length);
                System.arraycopy(this.wu, 0, obj2, 0, this.wu.length);
                this.wt = obj;
                this.wu = obj2;
            }
            if (this.ij - a != 0) {
                System.arraycopy(this.wt, a, this.wt, a + 1, this.ij - a);
                System.arraycopy(this.wu, a, this.wu, a + 1, this.ij - a);
            }
            this.wt[a] = j;
            this.wu[a] = e;
            this.ij++;
            return;
        }
        this.wt[a] = j;
        this.wu[a] = e;
    }

    public final int size() {
        if (this.ws) {
            gc();
        }
        return this.ij;
    }

    private long keyAt(int i) {
        if (this.ws) {
            gc();
        }
        return this.wt[i];
    }

    public final E valueAt(int i) {
        if (this.ws) {
            gc();
        }
        return this.wu[i];
    }

    public final String toString() {
        if (size() <= 0) {
            return "{}";
        }
        StringBuilder stringBuilder = new StringBuilder(this.ij * 28);
        stringBuilder.append('{');
        for (int i = 0; i < this.ij; i++) {
            if (i > 0) {
                stringBuilder.append(", ");
            }
            stringBuilder.append(keyAt(i));
            stringBuilder.append('=');
            e valueAt = valueAt(i);
            if (valueAt != this) {
                stringBuilder.append(valueAt);
            } else {
                stringBuilder.append("(this Map)");
            }
        }
        stringBuilder.append('}');
        return stringBuilder.toString();
    }
}
