package android.support.v4.app;

import android.graphics.Rect;
import android.transition.Transition;
import android.transition.Transition.EpicenterCallback;
import android.transition.TransitionSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver.OnPreDrawListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

final class r {

    /* renamed from: android.support.v4.app.r$2 */
    static class AnonymousClass2 implements OnPreDrawListener {
        final /* synthetic */ b rA;
        final /* synthetic */ Map rB;
        final /* synthetic */ Map rC;
        final /* synthetic */ ArrayList rD;
        final /* synthetic */ View rx;
        final /* synthetic */ Transition ry;
        final /* synthetic */ View rz;

        AnonymousClass2(View view, Transition transition, View view2, b bVar, Map map, Map map2, ArrayList arrayList) {
            this.rx = view;
            this.ry = transition;
            this.rz = view2;
            this.rA = bVar;
            this.rB = map;
            this.rC = map2;
            this.rD = arrayList;
        }

        public final boolean onPreDraw() {
            this.rx.getViewTreeObserver().removeOnPreDrawListener(this);
            if (this.ry != null) {
                this.ry.removeTarget(this.rz);
            }
            View view = this.rA.getView();
            if (view != null) {
                if (!this.rB.isEmpty()) {
                    r.a(this.rC, view);
                    this.rC.keySet().retainAll(this.rB.values());
                    for (Entry entry : this.rB.entrySet()) {
                        View view2 = (View) this.rC.get((String) entry.getValue());
                        if (view2 != null) {
                            view2.setTransitionName((String) entry.getKey());
                        }
                    }
                }
                if (this.ry != null) {
                    r.a(this.rD, view);
                    this.rD.removeAll(this.rC.values());
                    this.rD.add(this.rz);
                    r.b(this.ry, this.rD);
                }
            }
            return true;
        }
    }

    /* renamed from: android.support.v4.app.r$3 */
    static class AnonymousClass3 extends EpicenterCallback {
        private Rect rE;
        final /* synthetic */ a rF;

        AnonymousClass3(a aVar) {
            this.rF = aVar;
        }

        public final Rect onGetEpicenter(Transition transition) {
            if (this.rE == null && this.rF.rL != null) {
                this.rE = r.x(this.rF.rL);
            }
            return this.rE;
        }
    }

    /* renamed from: android.support.v4.app.r$4 */
    static class AnonymousClass4 implements OnPreDrawListener {
        final /* synthetic */ View pJ;
        final /* synthetic */ ArrayList pL;
        final /* synthetic */ Map rC;
        final /* synthetic */ ArrayList rD;
        final /* synthetic */ Transition rG;
        final /* synthetic */ ArrayList rH;
        final /* synthetic */ Transition rI;
        final /* synthetic */ ArrayList rJ;
        final /* synthetic */ Transition rK;
        final /* synthetic */ Transition ry;
        final /* synthetic */ View rz;

        AnonymousClass4(View view, Transition transition, ArrayList arrayList, Transition transition2, ArrayList arrayList2, Transition transition3, ArrayList arrayList3, Map map, ArrayList arrayList4, Transition transition4, View view2) {
            this.pJ = view;
            this.ry = transition;
            this.rD = arrayList;
            this.rG = transition2;
            this.rH = arrayList2;
            this.rI = transition3;
            this.pL = arrayList3;
            this.rC = map;
            this.rJ = arrayList4;
            this.rK = transition4;
            this.rz = view2;
        }

        public final boolean onPreDraw() {
            this.pJ.getViewTreeObserver().removeOnPreDrawListener(this);
            if (this.ry != null) {
                r.a(this.ry, this.rD);
            }
            if (this.rG != null) {
                r.a(this.rG, this.rH);
            }
            if (this.rI != null) {
                r.a(this.rI, this.pL);
            }
            for (Entry entry : this.rC.entrySet()) {
                ((View) entry.getValue()).setTransitionName((String) entry.getKey());
            }
            int size = this.rJ.size();
            for (int i = 0; i < size; i++) {
                this.rK.excludeTarget((View) this.rJ.get(i), false);
            }
            this.rK.excludeTarget(this.rz, false);
            return true;
        }
    }

    public static class a {
        public View rL;
    }

    public interface b {
        View getView();
    }

    public static Object f(Object obj) {
        if (obj != null) {
            return ((Transition) obj).clone();
        }
        return obj;
    }

    public static void a(Object obj, View view, boolean z) {
        ((Transition) obj).excludeTarget(view, z);
    }

    public static void a(Object obj, View view) {
        Transition transition = (Transition) obj;
        final Rect x = x(view);
        transition.setEpicenterCallback(new EpicenterCallback() {
            public final Rect onGetEpicenter(Transition transition) {
                return x;
            }
        });
    }

    public static void a(Object obj, View view, Map<String, View> map, ArrayList<View> arrayList) {
        TransitionSet transitionSet = (TransitionSet) obj;
        arrayList.clear();
        arrayList.addAll(map.values());
        List targets = transitionSet.getTargets();
        targets.clear();
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            View view2 = (View) arrayList.get(i);
            int size2 = targets.size();
            if (!a(targets, view2, size2)) {
                targets.add(view2);
                for (int i2 = size2; i2 < targets.size(); i2++) {
                    view2 = (View) targets.get(i2);
                    if (view2 instanceof ViewGroup) {
                        ViewGroup viewGroup = (ViewGroup) view2;
                        int childCount = viewGroup.getChildCount();
                        for (int i3 = 0; i3 < childCount; i3++) {
                            View childAt = viewGroup.getChildAt(i3);
                            if (!a(targets, childAt, size2)) {
                                targets.add(childAt);
                            }
                        }
                    }
                }
            }
        }
        arrayList.add(view);
        b(transitionSet, arrayList);
    }

    private static boolean a(List<View> list, View view, int i) {
        for (int i2 = 0; i2 < i; i2++) {
            if (list.get(i2) == view) {
                return true;
            }
        }
        return false;
    }

    static Rect x(View view) {
        Rect rect = new Rect();
        int[] iArr = new int[2];
        view.getLocationOnScreen(iArr);
        rect.set(iArr[0], iArr[1], iArr[0] + view.getWidth(), iArr[1] + view.getHeight());
        return rect;
    }

    static void a(ArrayList<View> arrayList, View view) {
        if (view.getVisibility() != 0) {
            return;
        }
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            if (viewGroup.isTransitionGroup()) {
                arrayList.add(viewGroup);
                return;
            }
            int childCount = viewGroup.getChildCount();
            for (int i = 0; i < childCount; i++) {
                a((ArrayList) arrayList, viewGroup.getChildAt(i));
            }
            return;
        }
        arrayList.add(view);
    }

    public static void a(Map<String, View> map, View view) {
        if (view.getVisibility() == 0) {
            String transitionName = view.getTransitionName();
            if (transitionName != null) {
                map.put(transitionName, view);
            }
            if (view instanceof ViewGroup) {
                ViewGroup viewGroup = (ViewGroup) view;
                int childCount = viewGroup.getChildCount();
                for (int i = 0; i < childCount; i++) {
                    a((Map) map, viewGroup.getChildAt(i));
                }
            }
        }
    }

    public static void a(Object obj, ArrayList<View> arrayList) {
        Transition transition = (Transition) obj;
        int transitionCount;
        if (transition instanceof TransitionSet) {
            TransitionSet transitionSet = (TransitionSet) transition;
            transitionCount = transitionSet.getTransitionCount();
            for (int i = 0; i < transitionCount; i++) {
                a(transitionSet.getTransitionAt(i), (ArrayList) arrayList);
            }
        } else if (!a(transition)) {
            List targets = transition.getTargets();
            if (targets != null && targets.size() == arrayList.size() && targets.containsAll(arrayList)) {
                for (transitionCount = arrayList.size() - 1; transitionCount >= 0; transitionCount--) {
                    transition.removeTarget((View) arrayList.get(transitionCount));
                }
            }
        }
    }

    public static void b(Object obj, ArrayList<View> arrayList) {
        int i = 0;
        Transition transition = (Transition) obj;
        int transitionCount;
        if (transition instanceof TransitionSet) {
            TransitionSet transitionSet = (TransitionSet) transition;
            transitionCount = transitionSet.getTransitionCount();
            while (i < transitionCount) {
                b(transitionSet.getTransitionAt(i), arrayList);
                i++;
            }
        } else if (!a(transition) && g(transition.getTargets())) {
            int size = arrayList.size();
            for (transitionCount = 0; transitionCount < size; transitionCount++) {
                transition.addTarget((View) arrayList.get(transitionCount));
            }
        }
    }

    private static boolean a(Transition transition) {
        return (g(transition.getTargetIds()) && g(transition.getTargetNames()) && g(transition.getTargetTypes())) ? false : true;
    }

    private static boolean g(List list) {
        return list == null || list.isEmpty();
    }
}
