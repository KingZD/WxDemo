package android.support.design.internal;

import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.design.internal.b.d;
import android.support.design.internal.b.g;
import android.support.design.internal.b.i;
import android.support.v7.view.menu.h;
import android.support.v7.widget.RecyclerView$t;
import android.support.v7.widget.RecyclerView.a;
import android.util.SparseArray;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Iterator;

class b$b extends a<b$j> {
    final /* synthetic */ b eA;
    final ArrayList<d> eB = new ArrayList();
    private h eC;
    private ColorDrawable eD;
    boolean eE;

    public final /* synthetic */ RecyclerView$t a(ViewGroup viewGroup, int i) {
        switch (i) {
            case 0:
                return new g(this.eA.mLayoutInflater, viewGroup, this.eA.mOnClickListener);
            case 1:
                return new i(this.eA.mLayoutInflater, viewGroup);
            case 2:
                return new b.h(this.eA.mLayoutInflater, viewGroup);
            case 3:
                return new b$a(this.eA.eq);
            default:
                return null;
        }
    }

    public final /* synthetic */ void a(RecyclerView$t recyclerView$t) {
        b$j b_j = (b$j) recyclerView$t;
        if (b_j instanceof g) {
            NavigationMenuItemView navigationMenuItemView = (NavigationMenuItemView) b_j.We;
            if (navigationMenuItemView.em != null) {
                navigationMenuItemView.em.removeAllViews();
            }
            navigationMenuItemView.el.setCompoundDrawables(null, null, null, null);
        }
    }

    public final /* synthetic */ void a(RecyclerView$t recyclerView$t, int i) {
        b$j b_j = (b$j) recyclerView$t;
        switch (getItemViewType(i)) {
            case 0:
                NavigationMenuItemView navigationMenuItemView = (NavigationMenuItemView) b_j.We;
                navigationMenuItemView.eo = this.eA.eo;
                if (navigationMenuItemView.en != null) {
                    navigationMenuItemView.setIcon(navigationMenuItemView.en.getIcon());
                }
                if (this.eA.ev) {
                    navigationMenuItemView.el.setTextAppearance(navigationMenuItemView.getContext(), this.eA.eu);
                }
                if (this.eA.ew != null) {
                    navigationMenuItemView.el.setTextColor(this.eA.ew);
                }
                navigationMenuItemView.setBackgroundDrawable(this.eA.ex != null ? this.eA.ex.getConstantState().newDrawable() : null);
                navigationMenuItemView.a(((b$f) this.eB.get(i)).eH);
                return;
            case 1:
                ((TextView) b_j.We).setText(((b$f) this.eB.get(i)).eH.getTitle());
                return;
            case 2:
                b$e b_e = (b$e) this.eB.get(i);
                b_j.We.setPadding(0, b_e.eF, 0, b_e.eG);
                return;
            default:
                return;
        }
    }

    public b$b(b bVar) {
        this.eA = bVar;
        P();
    }

    public final long getItemId(int i) {
        return (long) i;
    }

    public final int getItemCount() {
        return this.eB.size();
    }

    public final int getItemViewType(int i) {
        d dVar = (d) this.eB.get(i);
        if (dVar instanceof b$e) {
            return 2;
        }
        if (dVar instanceof b$c) {
            return 3;
        }
        if (!(dVar instanceof b$f)) {
            throw new RuntimeException("Unknown item type.");
        } else if (((b$f) dVar).eH.hasSubMenu()) {
            return 1;
        } else {
            return 0;
        }
    }

    final void P() {
        if (!this.eE) {
            this.eE = true;
            this.eB.clear();
            this.eB.add(new b$c((byte) 0));
            int i = -1;
            int i2 = 0;
            Object obj = null;
            int size = this.eA.es.dL().size();
            int i3 = 0;
            while (i3 < size) {
                Object obj2;
                int i4;
                int i5;
                h hVar = (h) this.eA.es.dL().get(i3);
                if (hVar.isChecked()) {
                    d(hVar);
                }
                if (hVar.isCheckable()) {
                    hVar.L(false);
                }
                int i6;
                if (hVar.hasSubMenu()) {
                    SubMenu subMenu = hVar.getSubMenu();
                    if (subMenu.hasVisibleItems()) {
                        if (i3 != 0) {
                            this.eB.add(new b$e(this.eA.ez, 0));
                        }
                        this.eB.add(new b$f(hVar, (byte) 0));
                        Object obj3 = null;
                        int size2 = this.eB.size();
                        int size3 = subMenu.size();
                        for (i6 = 0; i6 < size3; i6++) {
                            h hVar2 = (h) subMenu.getItem(i6);
                            if (hVar2.isVisible()) {
                                if (obj3 == null && hVar2.getIcon() != null) {
                                    obj3 = 1;
                                }
                                if (hVar2.isCheckable()) {
                                    hVar2.L(false);
                                }
                                if (hVar.isChecked()) {
                                    d(hVar);
                                }
                                this.eB.add(new b$f(hVar2, (byte) 0));
                            }
                        }
                        if (obj3 != null) {
                            f(size2, this.eB.size());
                        }
                    }
                    obj2 = obj;
                    i4 = i2;
                    i5 = i;
                } else {
                    Object obj4;
                    i6 = hVar.getGroupId();
                    if (i6 != i) {
                        i2 = this.eB.size();
                        obj = hVar.getIcon() != null ? 1 : null;
                        if (i3 != 0) {
                            i2++;
                            this.eB.add(new b$e(this.eA.ez, this.eA.ez));
                            obj4 = obj;
                            i5 = i2;
                        }
                        obj4 = obj;
                        i5 = i2;
                    } else {
                        if (obj == null && hVar.getIcon() != null) {
                            obj = 1;
                            f(i2, this.eB.size());
                        }
                        obj4 = obj;
                        i5 = i2;
                    }
                    if (obj4 != null && hVar.getIcon() == null) {
                        hVar.setIcon(17170445);
                    }
                    this.eB.add(new b$f(hVar, (byte) 0));
                    obj2 = obj4;
                    i4 = i5;
                    i5 = i6;
                }
                i3++;
                i2 = i4;
                i = i5;
                obj = obj2;
            }
            this.eE = false;
        }
    }

    private void f(int i, int i2) {
        while (i < i2) {
            MenuItem menuItem = ((b$f) this.eB.get(i)).eH;
            if (menuItem.getIcon() == null) {
                if (this.eD == null) {
                    this.eD = new ColorDrawable(0);
                }
                menuItem.setIcon(this.eD);
            }
            i++;
        }
    }

    public final void d(h hVar) {
        if (this.eC != hVar && hVar.isCheckable()) {
            if (this.eC != null) {
                this.eC.setChecked(false);
            }
            this.eC = hVar;
            hVar.setChecked(true);
        }
    }

    public final Bundle Q() {
        Bundle bundle = new Bundle();
        if (this.eC != null) {
            bundle.putInt("android:menu:checked", this.eC.getItemId());
        }
        SparseArray sparseArray = new SparseArray();
        Iterator it = this.eB.iterator();
        while (it.hasNext()) {
            d dVar = (d) it.next();
            if (dVar instanceof b$f) {
                h hVar = ((b$f) dVar).eH;
                View actionView = hVar != null ? hVar.getActionView() : null;
                if (actionView != null) {
                    SparseArray parcelableSparseArray = new ParcelableSparseArray();
                    actionView.saveHierarchyState(parcelableSparseArray);
                    sparseArray.put(hVar.getItemId(), parcelableSparseArray);
                }
            }
        }
        bundle.putSparseParcelableArray("android:menu:action_views", sparseArray);
        return bundle;
    }
}
