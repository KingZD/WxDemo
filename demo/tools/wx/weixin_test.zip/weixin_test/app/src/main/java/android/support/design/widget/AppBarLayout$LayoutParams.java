package android.support.design.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.support.design.a$i;
import android.util.AttributeSet;
import android.view.ViewGroup;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import android.widget.LinearLayout.LayoutParams;

public class AppBarLayout$LayoutParams extends LayoutParams {
    int fq = 1;
    Interpolator fr;

    public AppBarLayout$LayoutParams(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, a$i.cf);
        this.fq = obtainStyledAttributes.getInt(a$i.cg, 0);
        if (obtainStyledAttributes.hasValue(a$i.ch)) {
            this.fr = AnimationUtils.loadInterpolator(context, obtainStyledAttributes.getResourceId(a$i.ch, 0));
        }
        obtainStyledAttributes.recycle();
    }

    public AppBarLayout$LayoutParams() {
        super(-1, -2);
    }

    public AppBarLayout$LayoutParams(ViewGroup.LayoutParams layoutParams) {
        super(layoutParams);
    }

    public AppBarLayout$LayoutParams(MarginLayoutParams marginLayoutParams) {
        super(marginLayoutParams);
    }

    public AppBarLayout$LayoutParams(LayoutParams layoutParams) {
        super(layoutParams);
    }
}
