package a;

class a$a {
    private a$a() {
    }
}
