package android.support.v4.widget;

interface h {
    void l(Object obj, boolean z);
}
