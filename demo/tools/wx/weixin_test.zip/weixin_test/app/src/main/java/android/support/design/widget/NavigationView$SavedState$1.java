package android.support.design.widget;

import android.os.Parcel;
import android.support.design.widget.NavigationView.SavedState;
import android.support.v4.os.c;

class NavigationView$SavedState$1 implements c<SavedState> {
    NavigationView$SavedState$1() {
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
        return new SavedState(parcel, classLoader);
    }

    public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
        return new SavedState[i];
    }
}
