package android.support.design.widget;

import android.graphics.drawable.Drawable;
import android.view.View;

public final class TabLayout$b {
    CharSequence kU;
    View kV;
    TabLayout kW;
    TabLayout$c kX;
    Drawable kj;
    int mPosition;
    CharSequence mText;

    private TabLayout$b() {
        this.mPosition = -1;
    }

    public final void select() {
        if (this.kW == null) {
            throw new IllegalArgumentException("Tab not attached to a TabLayout");
        }
        this.kW.a(this);
    }

    final void aF() {
        if (this.kX != null) {
            this.kX.update();
        }
    }
}
