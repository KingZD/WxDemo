package android.support.v4.view;

import android.widget.TextView;

class PagerTitleStrip$d implements PagerTitleStrip$b {
    PagerTitleStrip$d() {
    }

    public final void b(TextView textView) {
        textView.setTransformationMethod(new v$a(textView.getContext()));
    }
}
