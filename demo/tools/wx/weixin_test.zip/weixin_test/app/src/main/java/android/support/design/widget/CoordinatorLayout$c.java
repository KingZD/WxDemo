package android.support.design.widget;

import android.view.View;
import android.view.ViewGroup.OnHierarchyChangeListener;

class CoordinatorLayout$c implements OnHierarchyChangeListener {
    final /* synthetic */ CoordinatorLayout hN;

    private CoordinatorLayout$c(CoordinatorLayout coordinatorLayout) {
        this.hN = coordinatorLayout;
    }

    public final void onChildViewAdded(View view, View view2) {
        if (CoordinatorLayout.a(this.hN) != null) {
            CoordinatorLayout.a(this.hN).onChildViewAdded(view, view2);
        }
    }

    public final void onChildViewRemoved(View view, View view2) {
        CoordinatorLayout coordinatorLayout = this.hN;
        int size = coordinatorLayout.hu.size();
        int i = 0;
        Object obj = null;
        while (i < size) {
            Object obj2;
            View view3 = (View) coordinatorLayout.hu.get(i);
            if (view3 == view2) {
                obj2 = 1;
            } else {
                if (obj != null) {
                    view3.getLayoutParams();
                }
                obj2 = obj;
            }
            i++;
            obj = obj2;
        }
        if (CoordinatorLayout.a(this.hN) != null) {
            CoordinatorLayout.a(this.hN).onChildViewRemoved(view, view2);
        }
    }
}
