package android.support.design.widget;

import android.graphics.drawable.Drawable.ConstantState;
import android.graphics.drawable.DrawableContainer;
import android.graphics.drawable.DrawableContainer.DrawableContainerState;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

final class i {
    private static Method ia;
    private static boolean ib;
    private static Field ic;
    private static boolean ie;

    static boolean a(DrawableContainer drawableContainer, ConstantState constantState) {
        if (!ib) {
            try {
                Method declaredMethod = DrawableContainer.class.getDeclaredMethod("setConstantState", new Class[]{DrawableContainerState.class});
                ia = declaredMethod;
                declaredMethod.setAccessible(true);
            } catch (NoSuchMethodException e) {
            }
            ib = true;
        }
        if (ia != null) {
            try {
                ia.invoke(drawableContainer, new Object[]{constantState});
                return true;
            } catch (Exception e2) {
            }
        }
        return false;
    }

    static boolean b(DrawableContainer drawableContainer, ConstantState constantState) {
        if (!ie) {
            try {
                Field declaredField = DrawableContainer.class.getDeclaredField("mDrawableContainerStateField");
                ic = declaredField;
                declaredField.setAccessible(true);
            } catch (NoSuchFieldException e) {
            }
            ie = true;
        }
        if (ic != null) {
            try {
                ic.set(drawableContainer, constantState);
                return true;
            } catch (Exception e2) {
            }
        }
        return false;
    }
}
