package android.support.design.widget;

import android.os.Handler.Callback;
import android.os.Message;

class q$1 implements Callback {
    final /* synthetic */ q jR;

    q$1(q qVar) {
        this.jR = qVar;
    }

    public final boolean handleMessage(Message message) {
        switch (message.what) {
            case 0:
                q qVar = this.jR;
                q$b q_b = (q$b) message.obj;
                synchronized (qVar.mLock) {
                    if (qVar.jP == q_b || qVar.jQ == q_b) {
                        qVar.a(q_b);
                    }
                }
                return true;
            default:
                return false;
        }
    }
}
