package android.support.design.widget;

public abstract class AppBarLayout$Behavior$a {
    public abstract boolean W();
}
