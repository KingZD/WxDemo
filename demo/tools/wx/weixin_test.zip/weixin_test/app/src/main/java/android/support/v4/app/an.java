package android.support.v4.app;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build.VERSION;
import java.util.ArrayList;
import java.util.Iterator;

public final class an implements Iterable<Intent> {
    private static final b tC;
    public final ArrayList<Intent> tD = new ArrayList();
    public final Context tE;

    public interface a {
        Intent getSupportParentActivityIntent();
    }

    interface b {
    }

    static class c implements b {
        c() {
        }
    }

    static class d implements b {
        d() {
        }
    }

    static {
        if (VERSION.SDK_INT >= 11) {
            tC = new d();
        } else {
            tC = new c();
        }
    }

    private an(Context context) {
        this.tE = context;
    }

    public static an w(Context context) {
        return new an(context);
    }

    public final an a(ComponentName componentName) {
        int size = this.tD.size();
        try {
            Intent a = v.a(this.tE, componentName);
            while (a != null) {
                this.tD.add(size, a);
                a = v.a(this.tE, a.getComponent());
            }
            return this;
        } catch (Throwable e) {
            throw new IllegalArgumentException(e);
        }
    }

    public final Iterator<Intent> iterator() {
        return this.tD.iterator();
    }
}
