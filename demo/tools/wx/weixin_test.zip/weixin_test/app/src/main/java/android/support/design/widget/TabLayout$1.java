package android.support.design.widget;

class TabLayout$1 implements u$c {
    final /* synthetic */ TabLayout kG;

    TabLayout$1(TabLayout tabLayout) {
        this.kG = tabLayout;
    }

    public final void a(u uVar) {
        this.kG.scrollTo(uVar.lD.aK(), 0);
    }
}
