package android.support.design.widget;

public interface AppBarLayout$a {
    void a(AppBarLayout appBarLayout, int i);
}
