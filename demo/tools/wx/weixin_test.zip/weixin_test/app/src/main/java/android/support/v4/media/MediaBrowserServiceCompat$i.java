package android.support.v4.media;

class MediaBrowserServiceCompat$i extends MediaBrowserServiceCompat$h {
}
