package android.support.design.internal;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.design.a$d;
import android.support.design.a$f;
import android.support.v7.view.menu.f;
import android.support.v7.view.menu.l;
import android.support.v7.view.menu.l.a;
import android.support.v7.view.menu.p;
import android.support.v7.widget.RecyclerView;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import java.util.Iterator;

public final class b implements l {
    ColorStateList eo;
    public NavigationMenuView ep;
    public LinearLayout eq;
    private a er;
    f es;
    public b$b et;
    int eu;
    boolean ev;
    ColorStateList ew;
    Drawable ex;
    public int ey;
    int ez;
    public int mId;
    public LayoutInflater mLayoutInflater;
    final OnClickListener mOnClickListener = new b$1(this);

    private interface d {
    }

    private static class g extends b$j {
        public g(LayoutInflater layoutInflater, ViewGroup viewGroup, OnClickListener onClickListener) {
            super(layoutInflater.inflate(a$f.bI, viewGroup, false));
            this.We.setOnClickListener(onClickListener);
        }
    }

    private static class h extends b$j {
        public h(LayoutInflater layoutInflater, ViewGroup viewGroup) {
            super(layoutInflater.inflate(a$f.bK, viewGroup, false));
        }
    }

    private static class i extends b$j {
        public i(LayoutInflater layoutInflater, ViewGroup viewGroup) {
            super(layoutInflater.inflate(a$f.bL, viewGroup, false));
        }
    }

    public final void a(Context context, f fVar) {
        this.mLayoutInflater = LayoutInflater.from(context);
        this.es = fVar;
        this.ez = context.getResources().getDimensionPixelOffset(a$d.br);
    }

    public final void n(boolean z) {
        if (this.et != null) {
            RecyclerView.a aVar = this.et;
            aVar.P();
            aVar.Vb.notifyChanged();
        }
    }

    public final boolean a(p pVar) {
        return false;
    }

    public final void a(f fVar, boolean z) {
        if (this.er != null) {
            this.er.a(fVar, z);
        }
    }

    public final boolean O() {
        return false;
    }

    public final boolean b(android.support.v7.view.menu.h hVar) {
        return false;
    }

    public final boolean c(android.support.v7.view.menu.h hVar) {
        return false;
    }

    public final int getId() {
        return this.mId;
    }

    public final Parcelable onSaveInstanceState() {
        Parcelable bundle = new Bundle();
        if (this.ep != null) {
            SparseArray sparseArray = new SparseArray();
            this.ep.saveHierarchyState(sparseArray);
            bundle.putSparseParcelableArray("android:menu:list", sparseArray);
        }
        if (this.et != null) {
            bundle.putBundle("android:menu:adapter", this.et.Q());
        }
        return bundle;
    }

    public final void onRestoreInstanceState(Parcelable parcelable) {
        Bundle bundle = (Bundle) parcelable;
        SparseArray sparseParcelableArray = bundle.getSparseParcelableArray("android:menu:list");
        if (sparseParcelableArray != null) {
            this.ep.restoreHierarchyState(sparseParcelableArray);
        }
        Bundle bundle2 = bundle.getBundle("android:menu:adapter");
        if (bundle2 != null) {
            d dVar;
            b$b b_b = this.et;
            int i = bundle2.getInt("android:menu:checked", 0);
            if (i != 0) {
                b_b.eE = true;
                Iterator it = b_b.eB.iterator();
                while (it.hasNext()) {
                    dVar = (d) it.next();
                    if (dVar instanceof b$f) {
                        android.support.v7.view.menu.h hVar = ((b$f) dVar).eH;
                        if (hVar != null && hVar.getItemId() == i) {
                            b_b.d(hVar);
                            break;
                        }
                    }
                }
                b_b.eE = false;
                b_b.P();
            }
            SparseArray sparseParcelableArray2 = bundle2.getSparseParcelableArray("android:menu:action_views");
            Iterator it2 = b_b.eB.iterator();
            while (it2.hasNext()) {
                dVar = (d) it2.next();
                if (dVar instanceof b$f) {
                    android.support.v7.view.menu.h hVar2 = ((b$f) dVar).eH;
                    View actionView = hVar2 != null ? hVar2.getActionView() : null;
                    if (actionView != null) {
                        actionView.restoreHierarchyState((SparseArray) sparseParcelableArray2.get(hVar2.getItemId()));
                    }
                }
            }
        }
    }

    public final void a(ColorStateList colorStateList) {
        this.eo = colorStateList;
        n(false);
    }

    public final void b(ColorStateList colorStateList) {
        this.ew = colorStateList;
        n(false);
    }

    public final void p(int i) {
        this.eu = i;
        this.ev = true;
        n(false);
    }

    public final void a(Drawable drawable) {
        this.ex = drawable;
        n(false);
    }

    public final void o(boolean z) {
        if (this.et != null) {
            this.et.eE = z;
        }
    }
}
