package android.support.design.widget;

import android.graphics.Rect;
import android.os.Build.VERSION;
import android.support.design.widget.CoordinatorLayout.Behavior;
import android.support.v4.view.z;
import android.view.View;
import java.util.List;

public class FloatingActionButton$a extends Behavior<FloatingActionButton> {
    private static final boolean iq = (VERSION.SDK_INT >= 11);
    private Rect ha;
    private u ir;
    private float is;

    public final /* synthetic */ boolean a(CoordinatorLayout coordinatorLayout, View view, int i) {
        int i2;
        int i3 = 0;
        FloatingActionButton floatingActionButton = (FloatingActionButton) view;
        List n = coordinatorLayout.n(floatingActionButton);
        int size = n.size();
        for (i2 = 0; i2 < size; i2++) {
            View view2 = (View) n.get(i2);
            if ((view2 instanceof AppBarLayout) && a(coordinatorLayout, (AppBarLayout) view2, floatingActionButton)) {
                break;
            }
        }
        coordinatorLayout.e(floatingActionButton, i);
        Rect c = FloatingActionButton.c(floatingActionButton);
        if (c != null && c.centerX() > 0 && c.centerY() > 0) {
            CoordinatorLayout$d coordinatorLayout$d = (CoordinatorLayout$d) floatingActionButton.getLayoutParams();
            i2 = floatingActionButton.getRight() >= coordinatorLayout.getWidth() - coordinatorLayout$d.rightMargin ? c.right : floatingActionButton.getLeft() <= coordinatorLayout$d.leftMargin ? -c.left : 0;
            if (floatingActionButton.getBottom() >= coordinatorLayout.getBottom() - coordinatorLayout$d.bottomMargin) {
                i3 = c.bottom;
            } else if (floatingActionButton.getTop() <= coordinatorLayout$d.topMargin) {
                i3 = -c.top;
            }
            floatingActionButton.offsetTopAndBottom(i3);
            floatingActionButton.offsetLeftAndRight(i2);
        }
        return true;
    }

    public final /* synthetic */ boolean b(CoordinatorLayout coordinatorLayout, View view, View view2) {
        FloatingActionButton floatingActionButton = (FloatingActionButton) view;
        if (view2 instanceof Snackbar$SnackbarLayout) {
            float min;
            float f = 0.0f;
            List n = coordinatorLayout.n(floatingActionButton);
            int size = n.size();
            int i = 0;
            while (i < size) {
                View view3 = (View) n.get(i);
                if (view3 instanceof Snackbar$SnackbarLayout) {
                    boolean z;
                    if (floatingActionButton.getVisibility() == 0 && view3.getVisibility() == 0) {
                        Rect rect = coordinatorLayout.hx;
                        coordinatorLayout.a(floatingActionButton, floatingActionButton.getParent() != coordinatorLayout, rect);
                        Rect rect2 = coordinatorLayout.hy;
                        coordinatorLayout.a(view3, view3.getParent() != coordinatorLayout, rect2);
                        z = rect.left <= rect2.right && rect.top <= rect2.bottom && rect.right >= rect2.left && rect.bottom >= rect2.top;
                    } else {
                        z = false;
                    }
                    if (z) {
                        min = Math.min(f, z.R(view3) - ((float) view3.getHeight()));
                        i++;
                        f = min;
                    }
                }
                min = f;
                i++;
                f = min;
            }
            if (this.is != f) {
                min = z.R(floatingActionButton);
                if (this.ir != null && this.ir.lD.isRunning()) {
                    this.ir.lD.cancel();
                }
                if (!floatingActionButton.isShown() || Math.abs(min - f) <= ((float) floatingActionButton.getHeight()) * 0.667f) {
                    z.c(floatingActionButton, f);
                } else {
                    if (this.ir == null) {
                        this.ir = aa.aJ();
                        this.ir.setInterpolator(a.eN);
                        this.ir.a(new FloatingActionButton$a$1(this, floatingActionButton));
                    }
                    this.ir.p(min, f);
                    this.ir.lD.start();
                }
                this.is = f;
            }
        } else if (view2 instanceof AppBarLayout) {
            a(coordinatorLayout, (AppBarLayout) view2, floatingActionButton);
        }
        return false;
    }

    public final /* bridge */ /* synthetic */ boolean e(View view) {
        return iq && (view instanceof Snackbar$SnackbarLayout);
    }

    private boolean a(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, FloatingActionButton floatingActionButton) {
        int i = 0;
        if (((CoordinatorLayout$d) floatingActionButton.getLayoutParams()).hR != appBarLayout.getId()) {
            return false;
        }
        if (floatingActionButton.me != 0) {
            return false;
        }
        if (this.ha == null) {
            this.ha = new Rect();
        }
        Rect rect = this.ha;
        x.a(coordinatorLayout, appBarLayout, rect);
        int i2 = rect.bottom;
        int T = appBarLayout.T();
        int T2 = z.T(appBarLayout);
        if (T2 != 0) {
            i = (T2 * 2) + T;
        } else {
            T2 = appBarLayout.getChildCount();
            if (T2 > 0) {
                i = (z.T(appBarLayout.getChildAt(T2 - 1)) * 2) + T;
            }
        }
        if (i2 <= i) {
            FloatingActionButton.a(floatingActionButton);
        } else {
            FloatingActionButton.b(floatingActionButton);
        }
        return true;
    }
}
