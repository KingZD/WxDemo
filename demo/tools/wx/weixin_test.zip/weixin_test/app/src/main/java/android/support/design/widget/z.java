package android.support.design.widget;

import android.view.View;

final class z {
    private int lY;
    private int lZ;
    private final View mView;
    int ma;
    int mb;

    public z(View view) {
        this.mView = view;
    }

    public final void aM() {
        this.lY = this.mView.getTop();
        this.lZ = this.mView.getLeft();
        aN();
    }

    final void aN() {
        android.support.v4.view.z.j(this.mView, this.ma - (this.mView.getTop() - this.lY));
        android.support.v4.view.z.k(this.mView, this.mb - (this.mView.getLeft() - this.lZ));
    }

    public final boolean q(int i) {
        if (this.ma == i) {
            return false;
        }
        this.ma = i;
        aN();
        return true;
    }
}
