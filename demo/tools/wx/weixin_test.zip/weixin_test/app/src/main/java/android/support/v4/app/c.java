package android.support.v4.app;

final class c {

    public interface a {
        void validateRequestPermissionsRequestCode(int i);
    }
}
