package android.support.v4.e;

public final class k<E> implements Cloneable {
    private static final Object wr = new Object();
    private int ij;
    private int[] wL;
    private boolean ws;
    private Object[] wu;

    public final /* synthetic */ Object clone() {
        return bT();
    }

    public k() {
        this(10);
    }

    public k(int i) {
        this.ws = false;
        if (i == 0) {
            this.wL = b.wo;
            this.wu = b.wq;
        } else {
            int Z = b.Z(i);
            this.wL = new int[Z];
            this.wu = new Object[Z];
        }
        this.ij = 0;
    }

    private k<E> bT() {
        try {
            k<E> kVar = (k) super.clone();
            try {
                kVar.wL = (int[]) this.wL.clone();
                kVar.wu = (Object[]) this.wu.clone();
                return kVar;
            } catch (CloneNotSupportedException e) {
                return kVar;
            }
        } catch (CloneNotSupportedException e2) {
            return null;
        }
    }

    public final E get(int i) {
        int a = b.a(this.wL, this.ij, i);
        return (a < 0 || this.wu[a] == wr) ? null : this.wu[a];
    }

    public final void remove(int i) {
        int a = b.a(this.wL, this.ij, i);
        if (a >= 0 && this.wu[a] != wr) {
            this.wu[a] = wr;
            this.ws = true;
        }
    }

    public final void removeAt(int i) {
        if (this.wu[i] != wr) {
            this.wu[i] = wr;
            this.ws = true;
        }
    }

    private void gc() {
        int i = this.ij;
        int[] iArr = this.wL;
        Object[] objArr = this.wu;
        int i2 = 0;
        for (int i3 = 0; i3 < i; i3++) {
            Object obj = objArr[i3];
            if (obj != wr) {
                if (i3 != i2) {
                    iArr[i2] = iArr[i3];
                    objArr[i2] = obj;
                    objArr[i3] = null;
                }
                i2++;
            }
        }
        this.ws = false;
        this.ij = i2;
    }

    public final void put(int i, E e) {
        int a = b.a(this.wL, this.ij, i);
        if (a >= 0) {
            this.wu[a] = e;
            return;
        }
        a ^= -1;
        if (a >= this.ij || this.wu[a] != wr) {
            if (this.ws && this.ij >= this.wL.length) {
                gc();
                a = b.a(this.wL, this.ij, i) ^ -1;
            }
            if (this.ij >= this.wL.length) {
                int Z = b.Z(this.ij + 1);
                Object obj = new int[Z];
                Object obj2 = new Object[Z];
                System.arraycopy(this.wL, 0, obj, 0, this.wL.length);
                System.arraycopy(this.wu, 0, obj2, 0, this.wu.length);
                this.wL = obj;
                this.wu = obj2;
            }
            if (this.ij - a != 0) {
                System.arraycopy(this.wL, a, this.wL, a + 1, this.ij - a);
                System.arraycopy(this.wu, a, this.wu, a + 1, this.ij - a);
            }
            this.wL[a] = i;
            this.wu[a] = e;
            this.ij++;
            return;
        }
        this.wL[a] = i;
        this.wu[a] = e;
    }

    public final int size() {
        if (this.ws) {
            gc();
        }
        return this.ij;
    }

    public final int keyAt(int i) {
        if (this.ws) {
            gc();
        }
        return this.wL[i];
    }

    public final E valueAt(int i) {
        if (this.ws) {
            gc();
        }
        return this.wu[i];
    }

    public final int indexOfKey(int i) {
        if (this.ws) {
            gc();
        }
        return b.a(this.wL, this.ij, i);
    }

    public final void clear() {
        int i = this.ij;
        Object[] objArr = this.wu;
        for (int i2 = 0; i2 < i; i2++) {
            objArr[i2] = null;
        }
        this.ij = 0;
        this.ws = false;
    }

    public final String toString() {
        if (size() <= 0) {
            return "{}";
        }
        StringBuilder stringBuilder = new StringBuilder(this.ij * 28);
        stringBuilder.append('{');
        for (int i = 0; i < this.ij; i++) {
            if (i > 0) {
                stringBuilder.append(", ");
            }
            stringBuilder.append(keyAt(i));
            stringBuilder.append('=');
            k valueAt = valueAt(i);
            if (valueAt != this) {
                stringBuilder.append(valueAt);
            } else {
                stringBuilder.append("(this Map)");
            }
        }
        stringBuilder.append('}');
        return stringBuilder.toString();
    }
}
