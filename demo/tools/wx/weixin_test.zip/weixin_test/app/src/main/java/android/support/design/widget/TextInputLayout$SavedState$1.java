package android.support.design.widget;

import android.os.Parcel;
import android.os.Parcelable.Creator;

class TextInputLayout$SavedState$1 implements Creator<TextInputLayout$SavedState> {
    TextInputLayout$SavedState$1() {
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        return new TextInputLayout$SavedState(parcel);
    }

    public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
        return new TextInputLayout$SavedState[i];
    }
}
