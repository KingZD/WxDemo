package android.support.v4.app;

import android.content.Intent;
import android.os.Bundle;

interface ah$b {
    Bundle getResultsFromIntent(Intent intent);
}
