package android.support.design.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.design.a$b;
import android.support.design.a$f;
import android.support.design.a$i;
import android.support.design.a.h;
import android.support.design.internal.NavigationMenuView;
import android.support.design.internal.ScrimInsetsFrameLayout;
import android.support.design.internal.b;
import android.support.design.internal.b$b;
import android.support.v4.view.z;
import android.support.v7.view.g;
import android.support.v7.view.menu.f;
import android.support.v7.view.menu.l;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.util.TypedValue;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View.BaseSavedState;
import android.view.View.MeasureSpec;
import android.widget.LinearLayout;
import java.lang.ref.WeakReference;
import java.util.Iterator;

public class NavigationView extends ScrimInsetsFrameLayout {
    private static final int[] ej = new int[]{16842912};
    private static final int[] je = new int[]{-16842910};
    private final android.support.design.internal.a jf;
    private final b jg;
    private a jh;
    private int ji;
    private MenuInflater jj;

    public static class SavedState extends BaseSavedState {
        public static final Creator<SavedState> CREATOR = android.support.v4.os.b.a(new NavigationView$SavedState$1());
        public Bundle jl;

        public SavedState(Parcel parcel, ClassLoader classLoader) {
            super(parcel);
            this.jl = parcel.readBundle(classLoader);
        }

        public SavedState(Parcelable parcelable) {
            super(parcelable);
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeBundle(this.jl);
        }
    }

    public interface a {
        boolean as();
    }

    public NavigationView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public NavigationView(Context context, AttributeSet attributeSet, int i) {
        ColorStateList colorStateList;
        int resourceId;
        boolean z;
        super(context, attributeSet, i);
        this.jg = new b();
        t.p(context);
        this.jf = new android.support.design.internal.a(context);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, a$i.db, i, h.bW);
        setBackgroundDrawable(obtainStyledAttributes.getDrawable(a$i.dc));
        if (obtainStyledAttributes.hasValue(a$i.dg)) {
            z.g(this, (float) obtainStyledAttributes.getDimensionPixelSize(a$i.dg, 0));
        }
        z.a(this, obtainStyledAttributes.getBoolean(a$i.dd, false));
        this.ji = obtainStyledAttributes.getDimensionPixelSize(a$i.de, 0);
        if (obtainStyledAttributes.hasValue(a$i.di)) {
            colorStateList = obtainStyledAttributes.getColorStateList(a$i.di);
        } else {
            colorStateList = G(16842808);
        }
        if (obtainStyledAttributes.hasValue(a$i.dl)) {
            resourceId = obtainStyledAttributes.getResourceId(a$i.dl, 0);
            z = true;
        } else {
            resourceId = 0;
            z = false;
        }
        ColorStateList colorStateList2 = null;
        if (obtainStyledAttributes.hasValue(a$i.dj)) {
            colorStateList2 = obtainStyledAttributes.getColorStateList(a$i.dj);
        }
        if (!z && r5 == null) {
            colorStateList2 = G(16842806);
        }
        Drawable drawable = obtainStyledAttributes.getDrawable(a$i.dk);
        this.jf.a(new android.support.v7.view.menu.f.a(this) {
            final /* synthetic */ NavigationView jk;

            {
                this.jk = r1;
            }

            public final boolean a(f fVar, MenuItem menuItem) {
                return this.jk.jh != null && this.jk.jh.as();
            }

            public final void b(f fVar) {
            }
        });
        this.jg.mId = 1;
        this.jg.a(context, this.jf);
        this.jg.a(colorStateList);
        if (z) {
            this.jg.p(resourceId);
        }
        this.jg.b(colorStateList2);
        this.jg.a(drawable);
        this.jf.a(this.jg);
        b bVar = this.jg;
        if (bVar.ep == null) {
            bVar.ep = (NavigationMenuView) bVar.mLayoutInflater.inflate(a$f.bM, this, false);
            if (bVar.et == null) {
                bVar.et = new b$b(bVar);
            }
            bVar.eq = (LinearLayout) bVar.mLayoutInflater.inflate(a$f.bJ, bVar.ep, false);
            bVar.ep.a(bVar.et);
        }
        addView(bVar.ep);
        if (obtainStyledAttributes.hasValue(a$i.dh)) {
            int resourceId2 = obtainStyledAttributes.getResourceId(a$i.dh, 0);
            this.jg.o(true);
            if (this.jj == null) {
                this.jj = new g(getContext());
            }
            this.jj.inflate(resourceId2, this.jf);
            this.jg.o(false);
            this.jg.n(false);
        }
        if (obtainStyledAttributes.hasValue(a$i.dm)) {
            resourceId2 = obtainStyledAttributes.getResourceId(a$i.dm, 0);
            bVar = this.jg;
            bVar.eq.addView(bVar.mLayoutInflater.inflate(resourceId2, bVar.eq, false));
            bVar.ep.setPadding(0, 0, 0, bVar.ep.getPaddingBottom());
        }
        obtainStyledAttributes.recycle();
    }

    protected Parcelable onSaveInstanceState() {
        Parcelable savedState = new SavedState(super.onSaveInstanceState());
        savedState.jl = new Bundle();
        this.jf.dispatchSaveInstanceState(savedState.jl);
        return savedState;
    }

    protected void onRestoreInstanceState(Parcelable parcelable) {
        if (parcelable instanceof SavedState) {
            SavedState savedState = (SavedState) parcelable;
            super.onRestoreInstanceState(savedState.getSuperState());
            f fVar = this.jf;
            SparseArray sparseParcelableArray = savedState.jl.getSparseParcelableArray("android:menu:presenters");
            if (sparseParcelableArray != null && !fVar.LH.isEmpty()) {
                Iterator it = fVar.LH.iterator();
                while (it.hasNext()) {
                    WeakReference weakReference = (WeakReference) it.next();
                    l lVar = (l) weakReference.get();
                    if (lVar == null) {
                        fVar.LH.remove(weakReference);
                    } else {
                        int id = lVar.getId();
                        if (id > 0) {
                            Parcelable parcelable2 = (Parcelable) sparseParcelableArray.get(id);
                            if (parcelable2 != null) {
                                lVar.onRestoreInstanceState(parcelable2);
                            }
                        }
                    }
                }
                return;
            }
            return;
        }
        super.onRestoreInstanceState(parcelable);
    }

    protected void onMeasure(int i, int i2) {
        switch (MeasureSpec.getMode(i)) {
            case Integer.MIN_VALUE:
                i = MeasureSpec.makeMeasureSpec(Math.min(MeasureSpec.getSize(i), this.ji), 1073741824);
                break;
            case 0:
                i = MeasureSpec.makeMeasureSpec(this.ji, 1073741824);
                break;
        }
        super.onMeasure(i, i2);
    }

    protected final void c(Rect rect) {
        b bVar = this.jg;
        int i = rect.top;
        if (bVar.ey != i) {
            bVar.ey = i;
            if (bVar.eq.getChildCount() == 0) {
                bVar.ep.setPadding(0, bVar.ey, 0, bVar.ep.getPaddingBottom());
            }
        }
    }

    private ColorStateList G(int i) {
        TypedValue typedValue = new TypedValue();
        if (!getContext().getTheme().resolveAttribute(i, typedValue, true)) {
            return null;
        }
        ColorStateList colorStateList = getResources().getColorStateList(typedValue.resourceId);
        if (!getContext().getTheme().resolveAttribute(a$b.colorPrimary, typedValue, true)) {
            return null;
        }
        int i2 = typedValue.data;
        int defaultColor = colorStateList.getDefaultColor();
        return new ColorStateList(new int[][]{je, ej, EMPTY_STATE_SET}, new int[]{colorStateList.getColorForState(je, defaultColor), i2, defaultColor});
    }
}
