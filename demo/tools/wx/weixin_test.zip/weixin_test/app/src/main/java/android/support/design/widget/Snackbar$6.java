package android.support.design.widget;

import android.support.v4.view.an;
import android.support.v4.view.z;
import android.view.View;

class Snackbar$6 extends an {
    final /* synthetic */ Snackbar jH;

    Snackbar$6(Snackbar snackbar) {
        this.jH = snackbar;
    }

    public final void p(View view) {
        Snackbar$SnackbarLayout c = Snackbar.c(this.jH);
        z.d(c.jJ, 0.0f);
        z.U(c.jJ).s(1.0f).h(180).i(70).start();
        if (c.jK.getVisibility() == 0) {
            z.d(c.jK, 0.0f);
            z.U(c.jK).s(1.0f).h(180).i(70).start();
        }
    }

    public final void q(View view) {
        Snackbar.f(this.jH);
    }
}
